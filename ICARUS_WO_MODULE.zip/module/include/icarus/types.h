#pragma once
#include <complex>
#include <cstddef>

namespace icarus {

using Real = double;
using Complex = std::complex<double>;

enum class Status : int {
    OK = 0,
    InvalidInput = 1,
    InvalidLaunch = 2,
    NegativeEpsImag = 3,
    NoValidCellEvent = 4,
    MaxCellCrossings = 5,
    WoEventLimit = 6,
    WoProfileCapacity = 7,
    WoBadEntranceEps = 8,
    WoSolverFailure = 9,
    WoRescalingFailure = 10,
    GrazingWo = 11,
    NonfiniteValue = 12,
    WoDisabledRequired = 13,
    WoConservationFailure = 14
};

constexpr double pi = 3.141592653589793238462643383279502884;
constexpr double two_pi = 2.0 * pi;
constexpr double root_tol = 1.0e-12;
constexpr double face_tol = 1.0e-10;
constexpr double accel_tol = 1.0e-14;
constexpr double grad_min = 1.0e-30;
constexpr double gradient_direction_threshold = 1.0e-10;
constexpr double negative_imag_tol = 1.0e-14;
constexpr double eps_real_min = 1.0e-300;
constexpr double eps_switch_floor = 1.0e-12;
constexpr double eikonal_rel_warn = 1.0e-8;
constexpr double max_phase = -28.0;
constexpr double epsilon_las = 1.0e-15;
constexpr double wo_raw_warn_tol = 1.0e-6;
constexpr double wo_raw_fail_tol = 1.0e-3;
constexpr double wo_final_fail_tol = 1.0e-3;
constexpr double wo_bounds_tol = 1.0e-10;
constexpr double direction_floor = 1.0e-300;

inline std::size_t flatten(std::size_t ir, std::size_t iz, std::size_t nz) {
    return ir * nz + iz;
}

inline int status_value(Status status) {
    return static_cast<int>(status);
}

} // namespace icarus
