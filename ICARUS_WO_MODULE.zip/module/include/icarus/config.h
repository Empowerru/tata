#pragma once
#include <cstddef>
#include <string>
#include <variant>
#include <vector>

namespace icarus {

enum class RaySamplingMode { EqualPower, EqualRadius };
enum class LaunchSpotMode { DiffractionEstimate, Explicit };

struct RaySamplingConfig {
    std::size_t number_of_rays = 128;
    RaySamplingMode mode = RaySamplingMode::EqualPower;
    double omitted_power_fraction = 1e-10;
};

struct ParallelGaussianConfig { double launch_spot_d4sigma_m = 0.0; };

struct FocusedGaussianConfig {
    double focus_z_m = 0.0;
    double focus_spot_d4sigma_m = 0.0;
    LaunchSpotMode launch_spot_mode = LaunchSpotMode::DiffractionEstimate;
    double explicit_launch_spot_d4sigma_m = 0.0;
};

using BeamGeometryConfig = std::variant<ParallelGaussianConfig, FocusedGaussianConfig>;

struct GaussianPulseConfig { double center_time_s = 0.0; double sigma_s = 0.0; };
struct TriangularPulseConfig { double start_time_s = 0.0; double peak_time_s = 0.0; double end_time_s = 0.0; };
struct TabulatedPulseConfig { std::string file_path; double time_shift_s = 0.0; double time_scale_to_s = 1.0; };
using PulseShapeConfig = std::variant<GaussianPulseConfig, TriangularPulseConfig, TabulatedPulseConfig>;

struct LaserConfig {
    std::string name;
    double wavelength_m = 0.0;
    double total_energy_j = 0.0;
    double p_polarization_fraction = 0.5;
    double tail_energy_fraction_per_side = 1e-4;
    RaySamplingConfig sampling;
    BeamGeometryConfig geometry;
    PulseShapeConfig pulse;
};

enum class WoExitMode { LegacyVacuum, MatchLastLayer };

struct TransportConfig {
    bool basko_rescaling_enabled = true;
    WoExitMode wo_exit_mode = WoExitMode::MatchLastLayer;
    double wo_switch_offset = 0.05;
    double alpha_gw = 0.8;
    double beta_gw = 1.0;
    int max_wo_events_per_ray = 1;
    double min_relative_power = 0.0;
    int max_cell_crossings = 100000;
    double max_unresolved_power_fraction = 0.01;
};

struct ParallelConfig {
    bool enabled = false;
    int number_of_threads = 0;
};

struct LaserDiagnosticsConfig {
    bool enabled = false;
    std::string output_directory = "laser_diagnostics";
    double write_interval_s = 1e-9;
    std::size_t theta_bins = 180;
};

struct RTConfig {
    std::vector<LaserConfig> lasers;
    TransportConfig transport;
    ParallelConfig parallel;
    LaserDiagnosticsConfig laser_diagnostics;
    bool write_partial_source_on_non_ok = false;
    double max_unresolved_power_fraction_for_partial_source = 0.01;
};

} // namespace icarus
