#pragma once
#include "icarus/config.h"
#include <vector>

namespace icarus {

struct PulseProfile {
    PulseShapeConfig config;
    std::vector<double> table_t;
    std::vector<double> table_p;
    std::vector<double> table_cumulative;
    double table_integral = 0.0;
    double t_on = 0.0, t_off = 0.0, tail_fraction = 0.0;

    bool initialize(const PulseShapeConfig& cfg, double q = 0.0);
    double step_energy_fraction(double t0, double dt) const;
    double full_step_energy_fraction(double t0, double dt) const;
private:
    bool initialize_profile(const PulseShapeConfig& cfg);
    double quantile(double f) const;
};

} // namespace icarus
