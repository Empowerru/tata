#pragma once
#include "icarus/grid_rz.h"
#include "icarus/types.h"

namespace icarus {

enum FaceMask { FaceNone = 0, FaceRMin = 1, FaceRMax = 2, FaceZMin = 4, FaceZMax = 8 };

struct CellEvent {
    Status status = Status::OK;
    double tau = 0.0;
    int face_mask = FaceNone;
    double r = 0.0;
    double z = 0.0;
    double vr = 0.0;
    double vz = 0.0;
};

int opposite_face_mask(int face);
int positive_quadratic_roots(double a, double b, double c, double roots[2], double root_tolerance = root_tol, double acceleration_tolerance = accel_tol, double discriminant_tolerance = 1.0e-14);
bool face_crossing_is_outward(int face, double vr, double vz, double grad_r, double grad_z, double vtol, double atol);
CellEvent next_go_cell_event(const GridRZ& grid, std::size_t ir, std::size_t iz, double r, double z, double vr, double vz, double grad_r, double grad_z, int entry_face_mask);
int locate_cell_with_direction(const GridRZ& grid, double r, double z, double ur, double uz, std::size_t& ir, std::size_t& iz);
double reconstruct_eps_real(const GridRZ& grid, const Complex* eps, const double* grad_r, const double* grad_z, std::size_t ir, std::size_t iz, double r, double z);
void parabolic_position(double r, double z, double vr, double vz, double gr, double gz, double tau, double& out_r, double& out_z);
void parabolic_velocity(double vr, double vz, double gr, double gz, double tau, double& out_vr, double& out_vz);
void advance_cell_after_event(const GridRZ& grid, std::size_t ir, std::size_t iz, int face_mask, int& out_ir, int& out_iz, bool& axis);

} // namespace icarus
