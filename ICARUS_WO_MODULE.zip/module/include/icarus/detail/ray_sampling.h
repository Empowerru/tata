#pragma once
#include "icarus/config.h"
#include "icarus/grid_rz.h"
#include "icarus/detail/ray_bundle.h"

namespace icarus {

bool sample_ray_bundle(const GridRZ& grid, const LaserConfig& laser, RayBundle& bundle);

} // namespace icarus
