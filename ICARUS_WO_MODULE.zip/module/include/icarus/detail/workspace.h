#pragma once
#include "icarus/diagnostics.h"
#include "icarus/types.h"
#include "icarus/laser_diagnostics.h"
#include <vector>

namespace icarus {

struct TransportThreadWorkspace {
    std::vector<double> cell_power;
    Diagnostics diagnostics;
    AngularPower angular;
    std::vector<double> work_float;
    std::vector<Complex> work_complex;
    std::vector<int> work_int;
};

struct TransportWorkspace {
    std::vector<double> cell_power;
    std::vector<double> work_float;
    std::vector<Complex> work_complex;
    std::vector<int> work_int;
    std::vector<TransportThreadWorkspace> thread_workspace;
};

} // namespace icarus
