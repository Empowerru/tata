#pragma once
#include "icarus/types.h"

namespace icarus {

enum RescaleResultIndex {
    RescaleResultT = 0,
    RescaleResultA = 1,
    RescaleResultAccuracy = 2,
    RescaleResultASec = 3,
    RescaleResultAOsc = 4,
    NumRescaleResult = 5
};

Status basko_rescale_absorption_inplace(
    std::size_t layers,
    const double* q_sec,
    const double* q_osc,
    double reflected,
    double transmitted_raw,
    double* q_rescaled,
    double* result);

} // namespace icarus
