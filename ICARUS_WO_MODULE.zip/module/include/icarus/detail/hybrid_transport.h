#pragma once
#include "icarus/config.h"
#include "icarus/diagnostics.h"
#include "icarus/grid_rz.h"
#include "icarus/material_fields.h"
#include "icarus/detail/ray_bundle.h"
#include "icarus/types.h"
#include "icarus/detail/workspace.h"
#include <vector>

namespace icarus {

enum class TransportTraceEventKind {
    Launch,
    GoSegmentEnd,
    WoSwitch,
    WoComplete,
    ReflectedGo,
    Escape,
    Failure,
    FaceCoupling,
    Terminal
};

struct TransportTraceEvent {
    TransportTraceEventKind kind = TransportTraceEventKind::Launch;
    std::size_t ray_index = 0;
    std::size_t ir = 0;
    std::size_t iz = 0;
    double r = 0.0;
    double z = 0.0;
    double direction_r = 0.0;
    double direction_z = 0.0;
    double power_w = 0.0;
    double eps_reconstructed = 0.0;
    double eps_center = 0.0;
    double normal_r = 0.0;
    double normal_z = 0.0;
    double mu = 0.0;
    double wo_path_length = 0.0;
    int wo_events = 0;
    Status status = Status::OK;
    double criterion = 0.0;
    double transport_grad_r = 0.0, transport_grad_z = 0.0;
    double geometric_grad_r = 0.0, geometric_grad_z = 0.0;
    double canonical_speed_squared = 0.0;
    double eps_minus = 0.0, eps_plus = 0.0;
    double eps_wo_first_real = 0.0, eps_wo_first_imag = 0.0;
    double segment_distance = 0.0;
    bool processed_event_suppressed = false;
    int normal_source = 0; // 0 absent, 1 transport gradient, 2 explicit interface
    bool exact_interface_profile = false;
    std::size_t wo_layer_count = 0;
    double power_s_w = 0, power_p_w = 0;
};

using TransportTraceCallback = void (*)(
    const TransportTraceEvent& event,
    void* user_data);

struct TransportTraceObserver {
    TransportTraceCallback callback = nullptr;
    void* user_data = nullptr;
    AngularPower* angular = nullptr;
};

struct RayTransportOutcome {
    int status = status_value(Status::OK);
    int wo_events = 0;
    double absorbed_go_w = 0.0;
    double absorbed_wo_w = 0.0;
    double escaped_go_w = 0.0;
    double escaped_wo_w = 0.0;
    double unresolved_w = 0.0;
    double cutoff_w = 0.0;
};

std::size_t max_wo_layers_for_mesh(std::size_t nr, std::size_t nz);
std::size_t required_float_workspace(std::size_t nr, std::size_t nz);
std::size_t required_complex_workspace(std::size_t nr, std::size_t nz);
std::size_t required_int_workspace(std::size_t nr, std::size_t nz);

Status trace_laser_batch_rz_inplace(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* grad_eps_r,
    const double* grad_eps_z,
    const double* ray_r0,
    const double* ray_z0,
    const double* ray_ur0,
    const double* ray_uz0,
    const double* ray_power0,
    const double* ray_p_fraction,
    std::size_t n_rays,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    int* ray_status,
    int* ray_wo_events,
    double* ray_unresolved_power,
    double* ray_cutoff_power,
    bool reset_diagnostics);

Status trace_laser_batch_rz_inplace_debug(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* grad_eps_r,
    const double* grad_eps_z,
    const double* ray_r0,
    const double* ray_z0,
    const double* ray_ur0,
    const double* ray_uz0,
    const double* ray_power0,
    const double* ray_p_fraction,
    std::size_t n_rays,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    RayTransportOutcome* ray_outcomes,
    const TransportTraceObserver* observer,
    bool reset_diagnostics);

Status trace_laser_batch_rz(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    double* ray_z0,
    double* ray_power,
    double* ray_p_fraction,
    int* ray_status,
    int* ray_wo_events,
    double* ray_unresolved_power,
    double* ray_cutoff_power,
    bool reset_diagnostics);

Status trace_laser_bundle_rz_production(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    const ParallelConfig& parallel,
    std::vector<TransportThreadWorkspace>* thread_workspace,
    AngularPower* angular = nullptr);

Status trace_laser_bundle_rz_unchecked(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    const ParallelConfig& parallel,
    std::vector<TransportThreadWorkspace>* thread_workspace,
    AngularPower* angular = nullptr);

} // namespace icarus
