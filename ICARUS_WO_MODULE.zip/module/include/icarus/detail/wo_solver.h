#pragma once
#include "icarus/types.h"

namespace icarus {

enum WoResultIndex {
    WoResultR = 0,
    WoResultTRaw = 1,
    WoResultASec = 2,
    WoResultAOsc = 3,
    WoResultARaw = 4,
    WoResultAccuracyRaw = 5,
    WoResultECutoff = 6,
    WoResultTruncated = 7,
    NumWoResult = 8
};

std::size_t required_wo_complex_workspace(std::size_t layers);

Status laser_absorption_components_inplace(
    std::size_t layers,
    const double* bounds,
    const Complex* eps,
    int polarization,
    double theta,
    double wavelength_m,
    double* q_sec,
    double* q_osc,
    double* result,
    Complex* work_complex,
    std::size_t work_complex_size);

} // namespace icarus
