#pragma once
#include <vector>

namespace icarus {

struct RayBundle {
    std::vector<double> launch_r;
    std::vector<double> focus_r;
    std::vector<double> dimensionless_radius;
    std::vector<double> direction_r;
    std::vector<double> direction_z;
    std::vector<double> power_weight;
    double captured_power_fraction = 0.0;
    double aperture_uninjected_power_fraction = 0.0;
    double launch_z = 0.0;
    double focus_z_m = 0.0;
    double focus_spot_d4sigma_m = 0.0;
};

} // namespace icarus
