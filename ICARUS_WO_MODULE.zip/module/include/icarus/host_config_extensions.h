#pragma once
#include "icarus/config.h"
#include <type_traits>
#include <utility>

namespace icarus {
// Old host configuration types keep working with documented defaults.
// Hosts exposing the new members use the same names and SI units as RTConfig.
template<class T,class=void> struct HasTailFraction : std::false_type {};
template<class T> struct HasTailFraction<T,std::void_t<decltype(std::declval<T>().tail_energy_fraction_per_side)>> : std::true_type {};
template<class T,class=void> struct HasLaserDiagnostics : std::false_type {};
template<class T> struct HasLaserDiagnostics<T,std::void_t<decltype(std::declval<T>().laser_diagnostics)>> : std::true_type {};
template<class T> void copy_laser_extensions(const T& host,LaserConfig& laser) {
    if constexpr(HasTailFraction<T>::value) laser.tail_energy_fraction_per_side=host.tail_energy_fraction_per_side;
}
template<class T> void copy_diagnostic_extensions(const T& host,RTConfig& cfg) {
    if constexpr(HasLaserDiagnostics<T>::value) {
        const auto& d=host.laser_diagnostics;
        cfg.laser_diagnostics.enabled=d.enabled;
        cfg.laser_diagnostics.output_directory=d.output_directory;
        cfg.laser_diagnostics.write_interval_s=d.write_interval_s;
        cfg.laser_diagnostics.theta_bins=d.theta_bins;
    }
}
} // namespace icarus
