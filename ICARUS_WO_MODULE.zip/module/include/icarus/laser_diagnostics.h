#pragma once
#include "icarus/config.h"
#include "icarus/diagnostics.h"
#include "icarus/detail/pulse_profile.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace icarus {
struct ExitPower {
    std::size_t laser_index = 0;
    bool wo = false;
    double r = 0, z = 0, ur = 0, uz = 0, p = 0, s = 0;
};

struct AngularPower {
    std::size_t laser_index = 0;
    std::vector<double> p, s;
    double unbinned = 0;
    void initialize(std::size_t n) { p.assign(n,0); s.assign(n,0); }
    void clear() { std::fill(p.begin(),p.end(),0); std::fill(s.begin(),s.end(),0); unbinned=0; }
    void add(const AngularPower& other) {
        for(std::size_t i=0;i<p.size();++i) { p[i]+=other.p[i]; s[i]+=other.s[i]; }
        unbinned+=other.unbinned;
    }
    void record(const ExitPower& e) {
        if(e.p+e.s<=0) return;
        const double norm=std::hypot(e.ur,e.uz);
        if(p.empty() || !std::isfinite(norm) || norm<=0) { unbinned+=e.p+e.s; return; }
        const double x=std::acos(std::clamp(e.uz/norm,-1.0,1.0))*p.size()/std::acos(-1.0);
        const double nearest=std::round(x);
        const double snapped=std::abs(x-nearest)<=8*std::numeric_limits<double>::epsilon()*p.size()?nearest:x;
        const std::size_t bin=static_cast<std::size_t>(std::clamp(std::ceil(snapped)-1.0,0.0,double(p.size()-1)));
        p[bin]+=e.p; s[bin]+=e.s;
    }
};

struct LaserDiagnosticState {
    AngularPower angular;
    Diagnostics power;
    bool scheduled = false, has_written = false;
    double last_written = 0, temporal_discarded_j = 0;
    std::size_t snapshot = 0;
};

class LaserDiagnosticWriter {
public:
    std::string error, run_directory;
    bool plan(double t, double dt, const RTConfig& config,
              const std::vector<PulseProfile>& pulses, const std::vector<double>& powers,
              std::vector<LaserDiagnosticState>& states);
    void write(double t,double dt,const RTConfig& config,
               const std::vector<PulseProfile>& pulses,std::vector<LaserDiagnosticState>& states);
private:
    bool observed_ = false;
    double maximum_time_ = 0;
};
} // namespace icarus
