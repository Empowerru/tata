#pragma once
#include "icarus/types.h"
#include <array>
#include <vector>

namespace icarus {

struct DerivativeStencil1D {
    std::size_t i0 = 0;
    std::size_t i1 = 0;
    std::size_t i2 = 0;
    double c0 = 0.0;
    double c1 = 0.0;
    double c2 = 0.0;
};

struct WlsCellGeometry {
    std::array<double, 9> inverse{};
    double coordinate_scale = 1.0;
    int radial_radius = 0;
    int axial_radius = 0;
    int mirrored_radial_radius = 0;
    bool valid = false;
};

struct GridRZ {
    std::size_t nr = 0;
    std::size_t nz = 0;
    std::vector<double> r_edges;
    std::vector<double> z_edges;
    std::vector<double> r_centers;
    std::vector<double> z_centers;
    std::vector<double> volume;
    std::vector<double> inverse_volume;
    std::vector<DerivativeStencil1D> derivative_r;
    std::vector<DerivativeStencil1D> derivative_z;
    std::vector<WlsCellGeometry> wls_3x3;
    std::vector<WlsCellGeometry> wls_5x5;
};

bool initialize_grid(const std::vector<double>& r_edges, const std::vector<double>& z_edges, GridRZ& grid);
int locate_cell(const GridRZ& grid, double r, double z, std::size_t& ir, std::size_t& iz);
void apply_cached_gradient_stencils(const GridRZ& grid, const std::vector<Complex>& epsilon, std::vector<double>& grad_r, std::vector<double>& grad_z);
void apply_wls_gradient_stencils(const GridRZ& grid, const Complex* epsilon, int radius, double* grad_r, double* grad_z);
void apply_scalar_limiter(const GridRZ& grid, const Complex* epsilon, const double* geometric_grad_r, const double* geometric_grad_z, double* transport_grad_r, double* transport_grad_z);
bool interpolate_geometric_gradient(const GridRZ& grid, const double* geometric_grad_r, const double* geometric_grad_z, double r, double z, double& grad_r, double& grad_z);

} // namespace icarus
