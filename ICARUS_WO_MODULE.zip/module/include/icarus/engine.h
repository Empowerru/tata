#pragma once
#include "icarus/config.h"
#include "icarus/grid_rz.h"
#include "icarus/material_fields.h"
#include "icarus/detail/pulse_profile.h"
#include "icarus/detail/ray_bundle.h"
#include "icarus/detail/workspace.h"

namespace icarus {

struct WavelengthGroupState {
    double wavelength_m = 0.0;
    MixedFields mixed;
    std::vector<double> cell_power_w;
};

class IcarusEngine {
public:
    IcarusEngine() = default;
    bool initialize(const std::vector<double>& r_edges, const std::vector<double>& z_edges, const RTConfig& config);
    Status update_source(double current_time_s, double time_step_s, const MaterialFields& materials);

    const GridRZ& grid() const { return grid_; }
    const std::vector<double>& phase_source() const { return phase_source_; }
    const std::vector<double>& total_source() const { return total_source_; }
    const std::vector<double>& last_cell_power() const { return workspace_.cell_power; }
    const Diagnostics& diagnostics() const { return diagnostics_; }
    const RayBundle& ray_bundle(std::size_t i) const { return bundles_[i]; }
    const std::vector<WavelengthGroupState>& wavelength_groups() const { return wavelength_groups_; }
    bool active_wavelength_groups(double current_time_s, double time_step_s, std::vector<unsigned char>& active_groups) const;
    std::size_t persistent_memory_bytes() const;
    double average_laser_power(std::size_t i, double t, double dt) const;
    double step_laser_energy(std::size_t i, double t, double dt) const;
    const PulseProfile& pulse(std::size_t i) const { return pulses_.at(i); }
    const std::vector<LaserDiagnosticState>& laser_diagnostics() const { return laser_diagnostics_; }
    const LaserDiagnosticWriter& diagnostic_writer() const { return diagnostic_writer_; }

private:
    bool initialize_candidate(const std::vector<double>& r_edges, const std::vector<double>& z_edges, const RTConfig& config);
    Status reject_input(std::size_t cell = static_cast<std::size_t>(-1), std::size_t group = static_cast<std::size_t>(-1));
    RTConfig config_;
    GridRZ grid_;
    std::vector<PulseProfile> pulses_;
    std::vector<RayBundle> bundles_;
    std::vector<std::size_t> laser_group_index_;
    std::vector<WavelengthGroupState> wavelength_groups_;
    TransportWorkspace workspace_;
    std::vector<double> laser_average_power_w_;
    std::vector<unsigned char> group_is_active_;
    std::vector<double> phase_source_;
    std::vector<double> total_source_;
    Diagnostics diagnostics_;
    std::vector<LaserDiagnosticState> laser_diagnostics_;
    LaserDiagnosticWriter diagnostic_writer_;
    bool initialized_ = false;
};

} // namespace icarus
