#pragma once
#include "icarus/diagnostics.h"
#include "icarus/grid_rz.h"
#include "icarus/types.h"
#include <vector>

namespace icarus {

struct MaterialFields {
    std::vector<Complex> eps0_by_wavelength;
    std::vector<Complex> eps1_by_wavelength;
    std::vector<double> f0;
};

struct MixedFields {
    std::vector<Complex> epsilon;
    std::vector<double> grad_r;
    std::vector<double> grad_z;
};

void build_mixed_fields_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index, MixedFields& mixed);
void add_partitioned_deposition_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index, const std::vector<double>& cell_power_w, std::vector<double>& phase_source, Diagnostics& diag);

} // namespace icarus
