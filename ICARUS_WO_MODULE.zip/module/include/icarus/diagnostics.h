#pragma once
#include "icarus/types.h"
#include <cstdint>

namespace icarus {

struct Diagnostics {
    double input_power_w = 0.0;
    double absorbed_go_w = 0.0;
    double absorbed_wo_w = 0.0;
    double escaped_go_w = 0.0;
    double escaped_wo_w = 0.0;
    double unresolved_power_w = 0.0;
    double energy_residual_w = 0.0;
    double go_segments = 0.0;
    double wo_events = 0.0;
    double wo_layers = 0.0;
    double axis_crossings = 0.0;
    double failed_rays = 0.0;
    double max_eikonal_error = 0.0;
    double reflected_power_generated_w = 0.0;
    double exponentials = 0.0;
    Status first_error_status = Status::OK;
    std::uint32_t failure_status_mask = 0;
    double eikonal_error_count = 0.0;
    double cutoff_power_w = 0.0;
    double wo_conservation_warning_count = 0.0;
    double max_wo_raw_residual = 0.0;
    double max_wo_final_residual = 0.0;
    double max_wo_conservation_correction = 0.0;

    double configured_power_w = 0.0;
    double injected_power_w = 0.0;
    double aperture_uninjected_power_w = 0.0;
    std::size_t total_rays = 0;
    std::size_t cutoff_rays = 0;
    std::size_t unresolved_rays = 0;
    std::size_t wo_event_count = 0;
    std::size_t phase_partition_fallback_count = 0;
    int effective_thread_count = 1;
    std::size_t invalid_input_cell = static_cast<std::size_t>(-1);
    std::size_t invalid_input_group = static_cast<std::size_t>(-1);

    void clear();
    void finish();
    void record_status(Status status);
    void add(const Diagnostics& other);
};

} // namespace icarus
