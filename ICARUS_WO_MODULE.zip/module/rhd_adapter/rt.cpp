#include "rt.h"
#include "icarus/host_config_extensions.h"

#include <algorithm>
#include <cmath>
#include <nlohmann/json.hpp>
#include <spdlog/spdlog.h>

#include "converter.h"
#include "icarus_params.h"

namespace {

bool same_coordinate(double a, double b) {
const double scale = std::max({1.0, std::abs(a), std::abs(b)});
return std::abs(a - b) <= 128.0 * 2.2204460492503131e-16 * scale;
}

} // namespace

RT::RT([[maybe_unused]] const SimulationParams &simulation_params, const AbsConfig &config) {
config_ = convert_config(config);
SPDLOG_INFO("---------- Initializing ICARUS RT Module ----------");
SPDLOG_INFO("Number of lasers: {}", config_.lasers.size());
for (const auto &laser : config_.lasers) {
SPDLOG_INFO("Laser name: {}", laser.name);
SPDLOG_INFO("Wave length: {} [m]", laser.wavelength_m);
SPDLOG_INFO("Total pulse energy: {} [J]", laser.total_energy_j);
SPDLOG_INFO("Number of rays: {}", laser.sampling.number_of_rays);
SPDLOG_INFO("Polarization fraction: {}", laser.p_polarization_fraction);
SPDLOG_INFO("Number of threads: {}", config_.parallel.number_of_threads);
// Radial profile
if (const auto &par_gaussian =
std::get_if<icarus::ParallelGaussianConfig>(&laser.geometry)) {
SPDLOG_INFO("Spot size: {} [m]", par_gaussian->launch_spot_d4sigma_m);
} else if (const auto &focused_gaussian =
std::get_if<icarus::FocusedGaussianConfig>(&laser.geometry)) {
SPDLOG_INFO("Spot size: {} [m]", focused_gaussian->focus_spot_d4sigma_m);
}
// Shape
if (std::holds_alternative<icarus::GaussianPulseConfig>(laser.pulse)) {
SPDLOG_INFO("Pulse shape: Gaussian");
const auto &conf = std::get<icarus::GaussianPulseConfig>(laser.pulse);
SPDLOG_INFO("Center time: {} [s]", conf.center_time_s);
SPDLOG_INFO("Sigma time: {} [s]", conf.sigma_s);

} else if (std::holds_alternative<icarus::TriangularPulseConfig>(laser.pulse)) {
SPDLOG_INFO("Pulse shape: Triangle");
const auto &g = std::get<icarus::TriangularPulseConfig>(laser.pulse);
SPDLOG_INFO("Start time: {} [s]", g.start_time_s);
SPDLOG_INFO("Peak time: {} [s]", g.peak_time_s);
SPDLOG_INFO("End time: {} [s]", g.end_time_s);
} else if (std::holds_alternative<icarus::TabulatedPulseConfig>(laser.pulse)) {
SPDLOG_INFO("Pulse shape: Tabulated");
const auto &g = std::get<icarus::TabulatedPulseConfig>(laser.pulse);
SPDLOG_INFO("File: {} [s]", g.file_path);
SPDLOG_INFO("Time shift: {} [s]", g.time_shift_s);
SPDLOG_INFO("Scale factor: {}", g.time_scale_to_s);
}
}
SPDLOG_INFO("----------------------------------------");
}

bool RT::grid_is_orthogonal(const SimulationParams &simulation_params, Data *const data) const {
for (std::size_t i = 0; i <= simulation_params.number_of_cells_r; ++i) {
const double r = data->x(i, 0);
for (std::size_t j = 0; j <= simulation_params.number_of_cells_z; ++j) {
if (!same_coordinate(data->x(i, j), r)) {
return false;
}
}
}
for (std::size_t j = 0; j <= simulation_params.number_of_cells_z; ++j) {
const double z = data->y(0, j);
for (std::size_t i = 0; i <= simulation_params.number_of_cells_r; ++i) {
if (!same_coordinate(data->y(i, j), z)) {
return false;
}
}
}
return true;
}

bool RT::initialize_from_data(const SimulationParams &simulation_params, Data *const data) {
if (simulation_params.number_of_cells_r == 0 || simulation_params.number_of_cells_z == 0 ||
config_.lasers.empty() || data == nullptr || !grid_is_orthogonal(simulation_params, data)) {
return false;
}

r_edges_.assign(simulation_params.number_of_cells_r + 1, 0.0);
z_edges_.assign(simulation_params.number_of_cells_z + 1, 0.0);
for (std::size_t i = 0; i < r_edges_.size(); ++i) {
r_edges_[i] = data->x(i, 0);
// TODO: some check is needed
if (r_edges_[i] < 0)
r_edges_[i] = 0.0;
}
for (std::size_t j = 0; j < z_edges_.size(); ++j) {
z_edges_[j] = data->y(0, j);
}
if (!engine_.initialize(r_edges_, z_edges_, config_)) {
return false;
}

cells_ = engine_.grid().nr * engine_.grid().nz;
const std::size_t groups = engine_.wavelength_groups().size();
materials_.f0.assign(cells_, 0.0);
materials_.eps0_by_wavelength.assign(groups * cells_, icarus::Complex(1.0, 0.0));
materials_.eps1_by_wavelength.assign(groups * cells_, icarus::Complex(1.0, 0.0));
wavelength_nm_.assign(groups, 0.0);
active_groups_.assign(groups, 0);
for (std::size_t g = 0; g < groups; ++g) {
wavelength_nm_[g] = engine_.wavelength_groups()[g].wavelength_m * 1.0e9;
}
initialized_from_data_ = true;
return true;
}

void RT::zero_host_sources(Data *const data) const {
const icarus::GridRZ &grid = engine_.grid();
for (std::size_t ir = 0; ir < grid.nr; ++ir) {
for (std::size_t iz = 0; iz < grid.nz; ++iz) {
data->qlas(ir, iz, static_cast<size_t>(0)) = 0.0;
data->qlas(ir, iz, static_cast<size_t>(1)) = 0.0;
}
}
}

void RT::fill_active_material_fields(Data *const data) {
 const icarus::GridRZ &grid = engine_.grid();
 for (std::size_t ir = 0; ir < grid.nr; ++ir) {
 for (std::size_t iz = 0; iz < grid.nz; ++iz) {
 const std::size_t idx = icarus::flatten(ir, iz, grid.nz);
 materials_.f0[idx] = data->f(ir, iz, static_cast<size_t>(0));
 }
 }

for (std::size_t g = 0; g < active_groups_.size(); ++g) {
if (active_groups_[g] == 0) {
continue;
}
const std::size_t group_offset = g * cells_;
for (std::size_t ir = 0; ir < grid.nr; ++ir) {
for (std::size_t iz = 0; iz < grid.nz; ++iz) {
const std::size_t idx = icarus::flatten(ir, iz, grid.nz);
constexpr sz_t idx0 = 0;
constexpr sz_t idx1 = 1;
std::pair<double, double> e0 = {1.0, 0.0};
if (data->is_present(ir, iz, idx0))
e0 = data->epsilon(data->rho(ir, iz, idx0), data->temp(ir, iz, idx0),
wavelength_nm_[g], idx0);
std::pair<double, double> e1 = {1.0, 0.0};
if (data->is_present(ir, iz, idx1))
e1 = data->epsilon(data->rho(ir, iz, idx1), data->temp(ir, iz, idx1),
wavelength_nm_[g], idx1);
materials_.eps0_by_wavelength[group_offset + idx] =
icarus::Complex(e0.first, e0.second);
materials_.eps1_by_wavelength[group_offset + idx] =
icarus::Complex(e1.first, e1.second);
}
}
}
}

void RT::write_phase_sources(Data *const data) const {
const icarus::GridRZ &grid = engine_.grid();
const std::vector<double> &phase = engine_.phase_source();
for (std::size_t ir = 0; ir < grid.nr; ++ir) {
for (std::size_t iz = 0; iz < grid.nz; ++iz) {
const std::size_t idx = icarus::flatten(ir, iz, grid.nz);
data->qlas(ir, iz, static_cast<size_t>(0)) = phase[idx];
data->qlas(ir, iz, static_cast<size_t>(1)) = phase[cells_ + idx];
}
}
}
using json = nlohmann::json;
using ordered_json = nlohmann::ordered_json;

void RT::save_result_json(const Data *data, const std::string &path, const std::string &name,
std::size_t t, std::size_t Nx, std::size_t Ny) {
std::filesystem::create_directories(path);

std::string filename = path + "/" + name + std::to_string(t) + ".json";

ordered_json js;
js["time"] = t;
js["Nx"] = Nx;
js["Ny"] = Ny;

js["cells"] = ordered_json::array();

for (std::size_t i = 0; i < Nx; ++i) {
for (std::size_t j = 0; j < Ny; ++j) {
const auto cell_cntr = data->cell<Geometry::RZ, 4>(i, j).geom_centroid();
const double xc = cell_cntr.r;
const double yc = cell_cntr.z;

double f0 = data->f(i, j, static_cast<sz_t>(0));
double f1 = data->f(i, j, static_cast<sz_t>(1));
double T0 = data->temp(i, j, static_cast<sz_t>(0));
double T1 = data->temp(i, j, static_cast<sz_t>(1));
double rho0 = data->rho(i, j, static_cast<sz_t>(0));
double rho1 = data->rho(i, j, static_cast<sz_t>(1));
std::pair<double, double> epsilon0{1.0, 0.0};
if (data->is_present(i, j, static_cast<sz_t>(0)))
epsilon0 = data->epsilon(rho0, T0, wavelength_nm_[0], static_cast<sz_t>(0));
double epsilon0re = epsilon0.first;
double epsilon0im = epsilon0.second;
std::pair<double, double> epsilon1{1.0, 0.0};
if (data->is_present(i, j, static_cast<sz_t>(1)))
epsilon1 = data->epsilon(rho1, T1, wavelength_nm_[0], static_cast<sz_t>(1));
double epsilon1re = epsilon1.first;
double epsilon1im = epsilon1.second;
double qlas0 = data->qlas(i, j, static_cast<sz_t>(0));
double qlas1 = data->qlas(i, j, static_cast<sz_t>(1));

js["cells"].push_back({
{"i", i},
{"j", j},
{"Nx", Nx},
{"Ny", Ny},
{"x", xc},
{"y", yc},
{"T0", T0},
{"T1", T1},
{"rho0", rho0},
{"rho1", rho1},
{"f0", f0},
{"f1", f1},
{"qlas0", qlas0},
{"qlas1", qlas1},
{"eps0re", epsilon0re},
{"eps1re", epsilon1re},
{"eps0im", epsilon0im},
{"eps1im", epsilon1im},
});
}
}

std::ofstream fout(filename);
fout << std::fixed << std::setprecision(16) << js.dump(2);
fout.close();
}

ErrorCode RT::step(SimulationState &simulation_state, const SimulationParams &simulation_params,
Data *const data) {

last_status_ = icarus::Status::OK;
if (data == nullptr) {
last_status_ = icarus::Status::InvalidInput;
return ErrorCode::NO_ERROR;
}
if (!initialized_from_data_ && !initialize_from_data(simulation_params, data)) {
last_status_ = icarus::Status::InvalidInput;
return ErrorCode::NO_ERROR;
}
const bool any_active = engine_.active_wavelength_groups(
simulation_state.current_time, simulation_state.current_step.value, active_groups_);
if (!any_active) {
last_status_ = engine_.update_source(simulation_state.current_time,
simulation_state.current_step.value, empty_materials_);
zero_host_sources(data);
return ErrorCode::NO_ERROR;
}

fill_active_material_fields(data);
const icarus::Status status = engine_.update_source(
simulation_state.current_time, simulation_state.current_step.value, materials_);
last_status_ = status;

const icarus::Diagnostics &d = engine_.diagnostics();
const double unresolved_fraction =
d.injected_power_w > 0.0 ? d.unresolved_power_w / d.injected_power_w : 0.0;

const bool accept_partial =
config_.write_partial_source_on_non_ok && std::isfinite(unresolved_fraction) &&
unresolved_fraction <= config_.max_unresolved_power_fraction_for_partial_source &&
status != icarus::Status::InvalidInput && status != icarus::Status::NegativeEpsImag &&
status != icarus::Status::NonfiniteValue;

if (status != icarus::Status::OK && !accept_partial) {
zero_host_sources(data);
return ErrorCode::NO_ERROR;
}

write_phase_sources(data);
return ErrorCode::NO_ERROR;
}

double RT::get_dt([[maybe_unused]] SimulationState &simulation_state,
[[maybe_unused]] const SimulationParams &simulation_params,
[[maybe_unused]] const Data *data) {
return 1E-9;
}

/// @brief Convert generic ABS configuration into icarus::RTConfig.
/// @param config ABS config to convert
/// @return icarus::RTConfig
icarus::RTConfig RT::convert_config([[maybe_unused]] const AbsConfig &config) {

icarus::RTConfig ret{};
try {
const auto params = dynamic_cast<const IcarusParams &>(config.get_params());
icarus::copy_diagnostic_extensions(params, ret);
for (const auto &l : params.lasers) {
icarus::LaserConfig laser{};
laser.name = l.name;
icarus::copy_laser_extensions(l, laser);
laser.wavelength_m = l.lambda_nm * 1e-9;
laser.total_energy_j = l.es_mj * 1e-3;
laser.sampling.number_of_rays = l.nr; // config.nr;
const auto source_type_str = l.type;
icarus::ParallelGaussianConfig gaussian{};
gaussian.launch_spot_d4sigma_m = l.r_sigma_um * 1e-6; // config.r_sigma_um * 1e-6 * 2;
laser.geometry = gaussian;
// Shape
if (l.shape.type == PulseShapeType::GAUSSIAN) {
icarus::GaussianPulseConfig pulse{};
pulse.center_time_s =
UnitConverter::convert(l.shape.center_time_ns, Quantity::Time, Unit::ns,
Unit::s); // 4 * 1e-9;
pulse.sigma_s = UnitConverter::convert(l.shape.sigma_ns, Quantity::Time, Unit::ns,
Unit::s); // 4 * 1e-9;
laser.pulse = pulse;
} else if (l.shape.type == PulseShapeType::TRIANGULAR) {
icarus::TriangularPulseConfig pulse{};
pulse.start_time_s = UnitConverter::convert(l.shape.start_time_ns, Quantity::Time,
Unit::ns, Unit::s);
pulse.peak_time_s =
UnitConverter::convert(l.shape.peak_time_ns, Quantity::Time, Unit::ns, Unit::s);
pulse.end_time_s =
UnitConverter::convert(l.shape.end_time_ns, Quantity::Time, Unit::ns, Unit::s);
laser.pulse = pulse;
} else if (l.shape.type == PulseShapeType::TABULATED) {
icarus::TabulatedPulseConfig pulse{};
pulse.file_path = l.shape.file_name;
pulse.time_shift_s =
UnitConverter::convert(l.shape.shift_ns, Quantity::Time, Unit::ns, Unit::s);
pulse.time_scale_to_s =
UnitConverter::convert(l.shape.scale, Quantity::Time, Unit::ns, Unit::s);
laser.pulse = pulse;
}
ret.lasers.push_back(laser);
}

ret.parallel.number_of_threads = 6;
ret.parallel.enabled = true;
ret.transport.max_wo_events_per_ray = 20;

} catch (const std::bad_cast &) {
throw std::runtime_error(
"ICARUS RT::convert_config: AbsConfig does not hold IcarusParams (model_name = '" +
config.name() + "')");
}

return ret;
}
