#pragma once // #ifndef ICARUS_HOST_API_HEADER // #define ICARUS_HOST_API_HEADER "icarus_host_api.h" // #endif // #include ICARUS_HOST_API_HEADER
#include "icarus/engine.h"
#include <cstddef>
#include <vector>
#include "abs_base.h"
class RT final : public AbsBase {
public:
// RT(const SimulationParams &simulation_params, const icarus::RTConfig &config);
RT(const SimulationParams &simulation_params, const AbsConfig &config);
void save_result_json(const Data *data, const std::string &path, const std::string &name, std::size_t t, std::size_t Nx, std::size_t Ny);
ErrorCode step(SimulationState &simulation_state, const SimulationParams &simulation_params, Data *data) override;
double get_dt(SimulationState &simulation_state, const SimulationParams &simulation_params, const Data *data) override;
[[nodiscard]] icarus::Status last_status() const { return last_status_; }
[[nodiscard]] const icarus::Diagnostics &diagnostics() const { return engine_.diagnostics(); }
[[nodiscard]] std::size_t persistent_memory_bytes() const { return engine_.persistent_memory_bytes(); }
private:
bool initialize_from_data(const SimulationParams &simulation_params, Data *data);
bool grid_is_orthogonal(const SimulationParams &simulation_params, Data *data) const;
void zero_host_sources(Data *data) const;
void fill_active_material_fields(Data *data);
void write_phase_sources(Data *data) const;
static icarus::RTConfig convert_config(const AbsConfig &config);
icarus::RTConfig config_;
icarus::IcarusEngine engine_;
icarus::MaterialFields materials_;
icarus::MaterialFields empty_materials_;
std::vector<double> r_edges_;
std::vector<double> z_edges_;
std::vector<double> wavelength_nm_;
std::vector<unsigned char> active_groups_;
std::size_t cells_ = 0;
icarus::Status last_status_ = icarus::Status::OK;
bool initialized_from_data_ = false;
};
