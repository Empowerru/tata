#include "icarus/detail/geometry_rz.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace icarus {

namespace {

struct GeometryTolerances {
    double pos_tol;
    double tau_tol;
    double accel_tol_local;
    double disc_tol;
    double corner_tol;
};

double normal_velocity(int face, double vr, double vz) {
    return (face == FaceRMin || face == FaceRMax) ? vr : vz;
}

GeometryTolerances local_geometry_tolerances(const GridRZ& grid, std::size_t ir, std::size_t iz, double vr, double vz, double grad_r, double grad_z) {
    const double dr = grid.r_edges[ir + 1] - grid.r_edges[ir];
    const double dz = grid.z_edges[iz + 1] - grid.z_edges[iz];
    const double h = std::min(std::abs(dr), std::abs(dz));
    const double tiny = std::numeric_limits<double>::min();
    const double eps = std::numeric_limits<double>::epsilon();
    const double coord_scale = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(grid.r_edges[ir]),
        std::abs(grid.r_edges[ir + 1]),
        std::abs(grid.z_edges[iz]),
        std::abs(grid.z_edges[iz + 1]),
        h,
        tiny});
    const double speed = std::hypot(vr, vz);
    const double grad_norm = std::hypot(grad_r, grad_z);
    const double pos_tol = std::max(64.0 * eps * coord_scale, 1.0e-15 * h);
    const double speed_scale = std::max({speed, std::sqrt(std::max(grad_norm * h, 0.0)), tiny});
    const double tau_ref = std::max(std::abs(h / speed_scale), tiny);
    const double tau_tol_local = std::max(64.0 * eps * tau_ref, 1.0e-14 * tau_ref);
    const double accel_scale = std::max({speed / tau_ref, grad_norm, tiny});
    const double accel_tol_local = 64.0 * eps * accel_scale;
    const double disc_scale = std::max({speed * speed, std::abs(grad_r) * h, std::abs(grad_z) * h, tiny});
    const double disc_tol = 256.0 * eps * disc_scale;
    const double corner_tol = std::max({16.0 * pos_tol, speed * tau_tol_local, 0.5 * grad_norm * tau_tol_local * tau_tol_local});
    return {pos_tol, tau_tol_local, accel_tol_local, disc_tol, corner_tol};
}

void append_root(double root, double roots[2], int& count, double tolerance) {
    if (root > tolerance && std::isfinite(root) && count < 2) {
        roots[count++] = root;
    }
}

void consider_candidate(
    const double roots[2],
    int n_roots,
    int face_mask,
    const GridRZ& grid,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double gr,
    double gz,
    int entry_face_mask,
    double pos_tol,
    double tau_tol,
    double velocity_tolerance,
    double acceleration_tolerance,
    double& best_tau,
    int& best_mask,
    double& best_r,
    double& best_z) {
    const double r_left = grid.r_edges[ir];
    const double r_right = grid.r_edges[ir + 1];
    const double z_low = grid.z_edges[iz];
    const double z_high = grid.z_edges[iz + 1];
    for (int k = 0; k < n_roots; ++k) {
        const double tau = roots[k];
        double rr = 0.0;
        double zz = 0.0;
        double vrr = 0.0;
        double vzz = 0.0;
        parabolic_position(r, z, vr, vz, gr, gz, tau, rr, zz);
        parabolic_velocity(vr, vz, gr, gz, tau, vrr, vzz);
        bool valid = false;
        if (face_mask == FaceRMin || face_mask == FaceRMax) {
            valid = z_low - pos_tol <= zz && zz <= z_high + pos_tol;
        } else {
            valid = r_left - pos_tol <= rr && rr <= r_right + pos_tol;
        }
        if (valid && !face_crossing_is_outward(face_mask, vrr, vzz, gr, gz, velocity_tolerance, acceleration_tolerance)) {
            valid = false;
        }
        if (valid && (entry_face_mask & face_mask) != 0) {
            const double v_normal = std::abs(normal_velocity(face_mask, vrr, vzz));
            const double floor = std::max(velocity_tolerance, std::numeric_limits<double>::min());
            const double root_time_tol = std::max(tau_tol, pos_tol / std::max(v_normal, floor));
            if (tau <= root_time_tol) {
                valid = false;
            }
        }
        if (!valid) {
            continue;
        }
        if (tau < best_tau - tau_tol) {
            best_tau = tau;
            best_mask = face_mask;
            best_r = std::min(std::max(rr, r_left), r_right);
            best_z = std::min(std::max(zz, z_low), z_high);
        } else if (std::abs(tau - best_tau) <= tau_tol) {
            best_mask |= face_mask;
            best_r = std::min(std::max(rr, r_left), r_right);
            best_z = std::min(std::max(zz, z_low), z_high);
        }
    }
}

void consider_current_face(
    int face_mask,
    const GridRZ& grid,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double gr,
    double gz,
    int entry_face_mask,
    double pos_tol,
    double tau_tol,
    double velocity_tolerance,
    double acceleration_tolerance,
    double& best_tau,
    int& best_mask,
    double& best_r,
    double& best_z) {
    if ((entry_face_mask & face_mask) != 0) {
        return;
    }
    const double r_left = grid.r_edges[ir];
    const double r_right = grid.r_edges[ir + 1];
    const double z_low = grid.z_edges[iz];
    const double z_high = grid.z_edges[iz + 1];
    bool on_face = false;
    if (face_mask == FaceRMin) {
        on_face = std::abs(r - r_left) <= pos_tol && z_low - pos_tol <= z && z <= z_high + pos_tol;
    } else if (face_mask == FaceRMax) {
        on_face = std::abs(r - r_right) <= pos_tol && z_low - pos_tol <= z && z <= z_high + pos_tol;
    } else if (face_mask == FaceZMin) {
        on_face = std::abs(z - z_low) <= pos_tol && r_left - pos_tol <= r && r <= r_right + pos_tol;
    } else if (face_mask == FaceZMax) {
        on_face = std::abs(z - z_high) <= pos_tol && r_left - pos_tol <= r && r <= r_right + pos_tol;
    }
    if (!on_face || !face_crossing_is_outward(face_mask, vr, vz, gr, gz, velocity_tolerance, acceleration_tolerance)) {
        return;
    }
    const double rr = std::min(std::max(r, r_left), r_right);
    const double zz = std::min(std::max(z, z_low), z_high);
    if (0.0 < best_tau - tau_tol) {
        best_tau = 0.0;
        best_mask = face_mask;
        best_r = rr;
        best_z = zz;
    } else if (std::abs(best_tau) <= tau_tol) {
        best_mask |= face_mask;
        best_r = rr;
        best_z = zz;
    }
}

} // namespace

int opposite_face_mask(int face) {
    int out = 0;
    if ((face & FaceRMin) != 0) {
        out |= FaceRMax;
    }
    if ((face & FaceRMax) != 0) {
        out |= FaceRMin;
    }
    if ((face & FaceZMin) != 0) {
        out |= FaceZMax;
    }
    if ((face & FaceZMax) != 0) {
        out |= FaceZMin;
    }
    return out;
}

int positive_quadratic_roots(double a, double b, double c, double roots[2], double root_tolerance, double acceleration_tolerance, double discriminant_tolerance) {
    int count = 0;
    if (std::abs(a) < acceleration_tolerance) {
        if (std::abs(b) < acceleration_tolerance) {
            return 0;
        }
        append_root(-c / b, roots, count, root_tolerance);
        return count;
    }
    double disc = b * b - 4.0 * a * c;
    if (disc < -discriminant_tolerance) {
        return 0;
    }
    if (disc < 0.0) {
        disc = 0.0;
    }
    const double sqrt_disc = std::sqrt(disc);
    if (sqrt_disc == 0.0) {
        append_root(-0.5 * b / a, roots, count, root_tolerance);
        return count;
    }
    // Use the q-formula so the smaller root is obtained as c/q; this avoids
    // cancellation when a GO parabola crosses a cell face at a shallow angle.
    const double q = (b >= 0.0) ? -0.5 * (b + sqrt_disc) : -0.5 * (b - sqrt_disc);
    if (q != 0.0) {
        append_root(q / a, roots, count, root_tolerance);
        append_root(c / q, roots, count, root_tolerance);
    } else {
        const double denom = 2.0 * a;
        append_root((-b - sqrt_disc) / denom, roots, count, root_tolerance);
        append_root((-b + sqrt_disc) / denom, roots, count, root_tolerance);
    }
    if (count == 2 && roots[1] < roots[0]) {
        std::swap(roots[0], roots[1]);
    }
    return count;
}

bool face_crossing_is_outward(int face, double vr, double vz, double grad_r, double grad_z, double vtol, double atol) {
    // A face event is accepted only when the ray is leaving the current cell.
    // Near a tangential contact the acceleration sign decides whether the
    // parabolic trajectory actually turns outward through the face.
    if (face == FaceRMin) {
        return vr < -vtol || (std::abs(vr) <= vtol && grad_r < -atol);
    }
    if (face == FaceRMax) {
        return vr > vtol || (std::abs(vr) <= vtol && grad_r > atol);
    }
    if (face == FaceZMin) {
        return vz < -vtol || (std::abs(vz) <= vtol && grad_z < -atol);
    }
    if (face == FaceZMax) {
        return vz > vtol || (std::abs(vz) <= vtol && grad_z > atol);
    }
    return false;
}

void parabolic_position(double r, double z, double vr, double vz, double gr, double gz, double tau, double& out_r, double& out_z) {
    // In a cell with linearly reconstructed Re(epsilon), GO motion is exact:
    // d2x/dtau2 = 0.5 grad(Re epsilon), so the path is parabolic in tau.
    out_r = r + vr * tau + 0.25 * gr * tau * tau;
    out_z = z + vz * tau + 0.25 * gz * tau * tau;
}

void parabolic_velocity(double vr, double vz, double gr, double gz, double tau, double& out_vr, double& out_vz) {
    out_vr = vr + 0.5 * gr * tau;
    out_vz = vz + 0.5 * gz * tau;
}

double reconstruct_eps_real(const GridRZ& grid, const Complex* eps, const double* grad_r, const double* grad_z, std::size_t ir, std::size_t iz, double r, double z) {
    const std::size_t idx = flatten(ir, iz, grid.nz);
    return eps[idx].real() + grad_r[idx] * (r - grid.r_centers[ir]) + grad_z[idx] * (z - grid.z_centers[iz]);
}

int locate_cell_with_direction(const GridRZ& grid, double r, double z, double ur, double uz, std::size_t& ir, std::size_t& iz) {
    const double scale = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(r),
        std::abs(z),
        std::numeric_limits<double>::min()});
    const double eps = 64.0 * std::numeric_limits<double>::epsilon() * scale;
    // Nudge from a face into the direction of travel. This makes reflected GO
    // continuation unambiguous at corners and avoids re-entering the old cell.
    return locate_cell(grid, r + eps * ur, z + eps * uz, ir, iz);
}

CellEvent next_go_cell_event(const GridRZ& grid, std::size_t ir, std::size_t iz, double r, double z, double vr, double vz, double grad_r, double grad_z, int entry_face_mask) {
    CellEvent event;
    event.r = r;
    event.z = z;
    event.vr = vr;
    event.vz = vz;
    if (ir >= grid.nr || iz >= grid.nz) {
        event.status = Status::InvalidInput;
        return event;
    }
    const GeometryTolerances tol = local_geometry_tolerances(grid, ir, iz, vr, vz, grad_r, grad_z);
    const double h = std::min(std::abs(grid.r_edges[ir + 1] - grid.r_edges[ir]), std::abs(grid.z_edges[iz + 1] - grid.z_edges[iz]));
    const double speed = std::hypot(vr, vz);
    const double grad_norm = std::hypot(grad_r, grad_z);
    const double tau_scale = h / std::max({speed, std::sqrt(std::max(grad_norm * h, 0.0)), std::numeric_limits<double>::min()});
    const double velocity_tolerance = std::max(64.0 * std::numeric_limits<double>::epsilon() * std::max(speed, h / std::max(tau_scale, std::numeric_limits<double>::min())), std::numeric_limits<double>::min());
    double best_tau = std::numeric_limits<double>::infinity();
    int best_mask = 0;
    double best_r = r;
    double best_z = z;

    // Suppress the entry face for the first event search after a crossing.
    // Without this, roundoff can make the ray immediately leave through the
    // same face it just entered.
    consider_current_face(FaceRMin, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    consider_current_face(FaceRMax, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    consider_current_face(FaceZMin, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    consider_current_face(FaceZMax, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);

    double roots[2] = {0.0, 0.0};
    int n = positive_quadratic_roots(0.25 * grad_r, vr, r - grid.r_edges[ir], roots, tol.tau_tol, tol.accel_tol_local, tol.disc_tol);
    consider_candidate(roots, n, FaceRMin, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    n = positive_quadratic_roots(0.25 * grad_r, vr, r - grid.r_edges[ir + 1], roots, tol.tau_tol, tol.accel_tol_local, tol.disc_tol);
    consider_candidate(roots, n, FaceRMax, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    n = positive_quadratic_roots(0.25 * grad_z, vz, z - grid.z_edges[iz], roots, tol.tau_tol, tol.accel_tol_local, tol.disc_tol);
    consider_candidate(roots, n, FaceZMin, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);
    n = positive_quadratic_roots(0.25 * grad_z, vz, z - grid.z_edges[iz + 1], roots, tol.tau_tol, tol.accel_tol_local, tol.disc_tol);
    consider_candidate(roots, n, FaceZMax, grid, ir, iz, r, z, vr, vz, grad_r, grad_z, entry_face_mask, tol.pos_tol, tol.corner_tol, velocity_tolerance, tol.accel_tol_local, best_tau, best_mask, best_r, best_z);

    if (best_mask == 0 || !std::isfinite(best_tau)) {
        event.status = Status::NoValidCellEvent;
        return event;
    }
    event.status = Status::OK;
    event.tau = best_tau;
    event.face_mask = best_mask;
    event.r = best_r;
    event.z = best_z;
    parabolic_velocity(vr, vz, grad_r, grad_z, best_tau, event.vr, event.vz);
    return event;
}

void advance_cell_after_event(const GridRZ& grid, std::size_t ir, std::size_t iz, int face_mask, int& out_ir, int& out_iz, bool& axis) {
    int next_ir = static_cast<int>(ir);
    int next_iz = static_cast<int>(iz);
    axis = false;
    if ((face_mask & FaceRMin) != 0) {
        if (ir == 0 && std::abs(grid.r_edges.front()) <= face_tol) {
            // r = 0 is the symmetry axis, not an escape boundary. The caller
            // reflects the radial velocity and remains in the innermost cell.
            axis = true;
        } else {
            --next_ir;
        }
    }
    if ((face_mask & FaceRMax) != 0) {
        ++next_ir;
    }
    if ((face_mask & FaceZMin) != 0) {
        --next_iz;
    }
    if ((face_mask & FaceZMax) != 0) {
        ++next_iz;
    }
    if (axis) {
        next_ir = 0;
    }
    out_ir = next_ir;
    out_iz = next_iz;
}

} // namespace icarus
