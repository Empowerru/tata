#include "icarus/laser_diagnostics.h"
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <stdexcept>
#include <ctime>

namespace icarus {
namespace fs=std::filesystem;
static std::string padded(std::size_t n,int width) {
    std::ostringstream s; s<<std::setw(width)<<std::setfill('0')<<n; return s.str();
}
static std::string safe_name(std::string name) {
    for(char& c:name) if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_')) c='_';
    if(name.empty()) name="laser";
    return name.substr(0,80);
}
static fs::path make_run(const std::string& root) {
    fs::create_directories(root);
    const auto now=std::chrono::system_clock::now();
    const auto stamp=std::chrono::system_clock::to_time_t(now);
    std::tm utc{};
#ifdef _WIN32
    gmtime_s(&utc,&stamp);
#else
    gmtime_r(&stamp,&utc);
#endif
    std::ostringstream prefix;
    prefix<<"run_"<<std::put_time(&utc,"%Y%m%dT%H%M%S")
          <<'_'<<std::chrono::duration_cast<std::chrono::microseconds>(now.time_since_epoch()).count()<<"Z_";
    std::random_device random;
    for(int i=0;i<100;++i) {
        const fs::path path=fs::path(root)/(prefix.str()+std::to_string(random())+"_"+std::to_string(i));
        if(fs::create_directory(path)) return path;
    }
    throw std::runtime_error("cannot reserve a unique run directory");
}

bool LaserDiagnosticWriter::plan(double t,double /*dt*/,const RTConfig& cfg,
    const std::vector<PulseProfile>& pulses,const std::vector<double>& powers,
    std::vector<LaserDiagnosticState>& states) {
    error.clear();
    for(auto& s:states) { s.scheduled=false; s.power.clear(); if(cfg.laser_diagnostics.enabled) s.angular.clear(); }
    if(!cfg.laser_diagnostics.enabled) return false;
    if(observed_ && t<maximum_time_) {
        error="ICARUS laser diagnostics: time rollback; no snapshot written";
        std::cerr<<error<<'\n'; return false;
    }
    bool any=false;
    for(std::size_t i=0;i<states.size();++i) {
        auto& s=states[i]; const auto& p=pulses[i];
        if(t<p.t_on || t>=p.t_off || cfg.lasers[i].total_energy_j==0) continue;
        if(!s.has_written && !(powers[i]>0)) continue;
        const double period=cfg.laser_diagnostics.write_interval_s;
        const double tol=std::min(32*std::numeric_limits<double>::epsilon()*std::max({std::abs(t),std::abs(s.last_written),period}),period*1e-10);
        if(s.has_written && (t<=s.last_written || t-s.last_written+tol<period)) continue;
        s.scheduled=true; any=true;
    }
    return any;
}

void LaserDiagnosticWriter::write(double t,double dt,const RTConfig& cfg,
    const std::vector<PulseProfile>& pulses,std::vector<LaserDiagnosticState>& states) {
    // Commit chronology only after a valid source update reaches the writer.
    if(cfg.laser_diagnostics.enabled) {
        maximum_time_=observed_?std::max(maximum_time_,t):t;
        observed_=true;
    }
    for(std::size_t i=0;i<states.size();++i) {
        auto& s=states[i]; if(!s.scheduled) continue;
        fs::path angle,angle_tmp,time;
        bool angle_published=false,time_touched=false,time_existed=false;
        std::uintmax_t old_time_size=0;
        try {
            if(run_directory.empty()) run_directory=make_run(cfg.laser_diagnostics.output_directory).string();
            const fs::path dir=fs::path(run_directory)/("laser_"+padded(i,3)+"_"+safe_name(cfg.lasers[i].name));
            fs::create_directories(dir);
            angle=dir/("power_laser_theta_"+padded(s.snapshot,8)+".csv");
            angle_tmp=angle.string()+".tmp";
            time=dir/"power_laser_time.csv";
            if(fs::exists(angle)) throw std::runtime_error("refusing to overwrite "+angle.string());
            const auto& d=s.power; const auto& p=pulses[i];
            const double escaped=d.escaped_go_w+d.escaped_wo_w;
            double away=0,toward=0;
            for(std::size_t j=0;j<s.angular.p.size();++j)
                (j<s.angular.p.size()/2?away:toward)+=s.angular.p[j]+s.angular.s[j];
            const double residual=escaped-away-toward-s.angular.unbinned;
            const bool complete=s.angular.unbinned==0 && std::abs(residual)<=1e-10*std::max(escaped,std::numeric_limits<double>::min());
            std::ostringstream meta;
            meta<<std::scientific<<std::setprecision(17)
                <<"# format_version=1 laser_index="<<i<<" laser_name="<<safe_name(cfg.lasers[i].name)<<" snapshot="<<s.snapshot<<'\n'
                <<"# power_time_basis=step_average units=W time_s="<<t<<" dt_s="<<dt<<" interval_end_s="<<t+dt<<'\n'
                <<"# t_on="<<p.t_on<<" t_off="<<p.t_off<<" q="<<p.tail_fraction
                <<" intersection_start_s="<<std::max(t,p.t_on)<<" intersection_end_s="<<std::max(std::max(t,p.t_on),std::min(t+dt,p.t_off))<<'\n'
                <<"# full_energy_j="<<cfg.lasers[i].total_energy_j<<" retained_energy_j="<<cfg.lasers[i].total_energy_j*(1-2*p.tail_fraction)<<'\n'
                <<"# basko_rescaling_enabled="<<cfg.transport.basko_rescaling_enabled<<" wo_exit_mode="<<(cfg.transport.wo_exit_mode==WoExitMode::MatchLastLayer?"MatchLastLayer":"LegacyVacuum")<<" wo_switch_offset="<<cfg.transport.wo_switch_offset<<'\n'
                <<"# theta_bins="<<s.angular.p.size()<<" optical_axis_r=0 optical_axis_z=1 bin_rule=first_closed_then_left_open_right_closed theta90=away\n"
                <<"# polarization_basis=p_in_RZ_meridional_plane_s_azimuthal power_per_bin_full_azimuth_not_W_per_sr\n"
                <<"# transport_status="<<static_cast<int>(d.first_error_status)<<" partial="<<(d.first_error_status!=Status::OK)
                <<" host_source_acceptance=not_determined_by_diagnostic_writer angular_complete="<<(complete?"true":"false")<<'\n'
                <<"# unbinned_escaped_power_w="<<s.angular.unbinned<<" angular_residual_w="<<residual
                <<" unbinned_reason="<<(s.angular.unbinned>0?"nonpropagating_or_invalid_exit_direction":"none")<<'\n'
                <<"# injected_power_w="<<d.injected_power_w<<" unresolved_power_w="<<d.unresolved_power_w<<" cutoff_power_w="<<d.cutoff_power_w
                <<" aperture_uninjected_power_w="<<d.aperture_uninjected_power_w<<" temporal_discarded_step_j="<<s.temporal_discarded_j<<'\n';
            std::ofstream a(angle_tmp); a.exceptions(std::ios::failbit|std::ios::badbit);
            a<<meta.str()<<"theta_left_deg,theta_right_deg,power_p_w,power_s_w,power_total_w\n"<<std::scientific<<std::setprecision(17);
            for(std::size_t j=0;j<s.angular.p.size();++j)
                a<<180.0*j/s.angular.p.size()<<','<<180.0*(j+1)/s.angular.p.size()<<','<<s.angular.p[j]<<','<<s.angular.s[j]<<','<<s.angular.p[j]+s.angular.s[j]<<'\n';
            a.close();
            time_existed=fs::exists(time);
            if(time_existed) old_time_size=fs::file_size(time);
            fs::rename(angle_tmp,angle); angle_published=true;
            time_touched=true;
            std::ofstream out(time,std::ios::app); out.exceptions(std::ios::failbit|std::ios::badbit);
            if(!time_existed) out<<"time_s,absorbed_power_w,escaped_power_w,toward_laser_power_w,away_from_laser_power_w\n";
            out<<meta.str()<<std::scientific<<std::setprecision(17)<<t<<','<<d.absorbed_go_w+d.absorbed_wo_w<<','<<escaped<<','<<toward<<','<<away<<'\n';
            out.close();
            s.last_written=t; s.has_written=true; ++s.snapshot;
        } catch(const std::exception& e) {
            error="ICARUS laser diagnostics I/O ["+cfg.laser_diagnostics.output_directory+"]: "+e.what();
            std::cerr<<error<<'\n';
            std::error_code ignored;
            if(angle_published) fs::remove(angle,ignored);
            if(!angle_tmp.empty()) fs::remove(angle_tmp,ignored);
            if(time_touched) {
                if(time_existed) fs::resize_file(time,old_time_size,ignored);
                else fs::remove(time,ignored);
                if(ignored) { error+="; time-file rollback failed: "+ignored.message(); std::cerr<<error<<'\n'; }
            }
        }
    }
}
} // namespace icarus
