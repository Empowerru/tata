#include "icarus/material_fields.h"
#include <cassert>
#include <cmath>

namespace icarus {

static const Complex* eps0_ptr_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index) {
    const std::size_t cells = grid.nr * grid.nz;
    if ((group_index + 1) * cells > materials.eps0_by_wavelength.size()) {
        return nullptr;
    }
    return materials.eps0_by_wavelength.data() + group_index * cells;
}

static const Complex* eps1_ptr_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index) {
    const std::size_t cells = grid.nr * grid.nz;
    if ((group_index + 1) * cells > materials.eps1_by_wavelength.size()) {
        return nullptr;
    }
    return materials.eps1_by_wavelength.data() + group_index * cells;
}

void build_mixed_fields_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index, MixedFields& mixed) {
    const std::size_t cells = grid.nr * grid.nz;
    const Complex* eps0 = eps0_ptr_for_group(grid, materials, group_index);
    const Complex* eps1 = eps1_ptr_for_group(grid, materials, group_index);
    if (eps0 == nullptr || eps1 == nullptr) {
        return;
    }
    if (mixed.epsilon.size() != cells || mixed.grad_r.size() != cells || mixed.grad_z.size() != cells ||
        materials.f0.size() != cells) {
        return;
    }
    assert(mixed.epsilon.size() == cells);
    assert(mixed.grad_r.size() == cells);
    assert(mixed.grad_z.size() == cells);
    assert(materials.f0.size() == cells);
    // For the active wavelength group, build the dielectric used by both GO
    // and WO: epsilon_mix = f0 * epsilon0 + (1 - f0) * epsilon1.
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        for (std::size_t iz = 0; iz < grid.nz; ++iz) {
            const std::size_t idx = flatten(ir, iz, grid.nz);
            const double f0 = materials.f0[idx];
            const double f1 = 1.0 - f0;
#ifndef NDEBUG
            assert(std::isfinite(f0));
            assert(f0 >= 0.0 && f0 <= 1.0);
#endif
            mixed.epsilon[idx] = f0 * eps0[idx] + f1 * eps1[idx];
        }
    }
    apply_cached_gradient_stencils(grid, mixed.epsilon, mixed.grad_r, mixed.grad_z);
}

void add_partitioned_deposition_for_group(const GridRZ& grid, const MaterialFields& materials, std::size_t group_index, const std::vector<double>& cell_power_w, std::vector<double>& phase_source, Diagnostics& diag) {
    const std::size_t cells = grid.nr * grid.nz;
    const Complex* eps0 = eps0_ptr_for_group(grid, materials, group_index);
    const Complex* eps1 = eps1_ptr_for_group(grid, materials, group_index);
    if (eps0 == nullptr || eps1 == nullptr) {
        diag.record_status(Status::InvalidInput);
        return;
    }
    assert(phase_source.size() == 2 * cells);
    assert(materials.f0.size() == cells);
    // Partition each wavelength group's deposited watts before adding to the
    // final phase source. This preserves wavelength-specific material opacity.
    for (std::size_t idx = 0; idx < cells; ++idx) {
        const double q_total = cell_power_w[idx] * grid.inverse_volume[idx];
        const double f0 = materials.f0[idx];
#ifndef NDEBUG
        assert(std::isfinite(f0));
        assert(f0 >= 0.0 && f0 <= 1.0);
#endif
        const double f1 = 1.0 - f0;
        const double a0 = f0 * std::max(0.0, eps0[idx].imag());
        const double a1 = f1 * std::max(0.0, eps1[idx].imag());
        const double asum = a0 + a1;
        double q0 = 0.0;
        if (asum > 0.0) {
            q0 = q_total * (a0 / asum);
        } else {
            q0 = f0 * q_total;
            if (std::abs(q_total) > 0.0) {
                ++diag.phase_partition_fallback_count;
            }
        }
        phase_source[idx] += q0;
        phase_source[cells + idx] += q_total - q0;
    }
}

} // namespace icarus
