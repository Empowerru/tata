#include "icarus/detail/wo_rescale.h"
#include <cmath>

namespace icarus {

Status basko_rescale_absorption_inplace(
    std::size_t layers,
    const double* q_sec,
    const double* q_osc,
    double reflected,
    double transmitted_raw,
    double* q_rescaled,
    double* result) {
    if (q_sec == nullptr || q_osc == nullptr || q_rescaled == nullptr || result == nullptr) {
        return Status::InvalidInput;
    }
    double a_sec = 0.0;
    double a_osc = 0.0;
    for (std::size_t j = 0; j < layers; ++j) {
        a_sec += q_sec[j];
        a_osc += q_osc[j];
        q_rescaled[j] = 0.0;
    }

    double transmitted_rescaled = 0.0;
    if (a_osc <= 0.0) {
        double remaining = 1.0 - reflected;
        if (remaining < -1.0e-12) {
            return Status::WoRescalingFailure;
        }
        if (remaining < 0.0) {
            remaining = 0.0;
        }
        for (std::size_t j = 0; j < layers; ++j) {
            double q = q_sec[j];
            if (q < 0.0 && q > -1.0e-14) {
                q = 0.0;
            }
            if (q < 0.0) {
                return Status::WoRescalingFailure;
            }
            if (q <= remaining) {
                q_rescaled[j] = q;
                remaining -= q;
            } else {
                q_rescaled[j] = remaining;
                remaining = 0.0;
                for (std::size_t k = j + 1; k < layers; ++k) {
                    q_rescaled[k] = 0.0;
                }
                break;
            }
        }
        transmitted_rescaled = remaining;
    } else {
        double positive_osc_sum = 0.0;
        for (std::size_t j = 0; j < layers; ++j) {
            if (q_osc[j] > 0.0) {
                positive_osc_sum += q_osc[j];
            }
        }
        if (positive_osc_sum <= 0.0) {
            return Status::WoRescalingFailure;
        }
        const double alpha_osc = a_osc / positive_osc_sum;
        for (std::size_t j = 0; j < layers; ++j) {
            double q = q_sec[j];
            if (q_osc[j] > 0.0) {
                q += alpha_osc * q_osc[j];
            }
            if (q < 0.0 && q > -1.0e-14) {
                q = 0.0;
            }
            if (q < 0.0) {
                return Status::WoRescalingFailure;
            }
            q_rescaled[j] = q;
        }
        transmitted_rescaled = transmitted_raw;
    }

    double a_rescaled = 0.0;
    for (std::size_t j = 0; j < layers; ++j) {
        a_rescaled += q_rescaled[j];
    }
    double accuracy = 1.0 - reflected - transmitted_rescaled - a_rescaled;
    if (transmitted_rescaled < -1.0e-12) {
        return Status::WoRescalingFailure;
    }
    if (transmitted_rescaled < 0.0) {
        transmitted_rescaled = 0.0;
    }
    result[RescaleResultT] = transmitted_rescaled;
    result[RescaleResultA] = a_rescaled;
    result[RescaleResultAccuracy] = accuracy;
    result[RescaleResultASec] = a_sec;
    result[RescaleResultAOsc] = a_osc;
    return Status::OK;
}

} // namespace icarus
