#include "icarus/detail/wo_solver.h"

#include <algorithm>
#include <cmath>
#include <limits>

namespace icarus {
namespace {

struct Scattering {
    Complex r_left{0.0, 0.0};
    Complex r_right{0.0, 0.0};
    Complex t_left_right{1.0, 0.0};
    Complex t_right_left{1.0, 0.0};
};

bool finite_complex(Complex value) {
    return std::isfinite(value.real()) && std::isfinite(value.imag());
}

Complex passive_epsilon(Complex epsilon) {
    if (epsilon.imag() < 0.0 && epsilon.imag() >= -negative_imag_tol) {
        return {epsilon.real(), 0.0};
    }
    return epsilon;
}

Complex passive_normal_root(Complex value) {
    Complex root = std::sqrt(value);
    if (root.imag() < 0.0 || (root.imag() == 0.0 && root.real() < 0.0)) {
        root = -root;
    }
    return root;
}

bool usable_denominator(Complex denominator, double scale) {
    return finite_complex(denominator) &&
        std::abs(denominator) > 64.0 * std::numeric_limits<double>::epsilon() *
            std::max(1.0, scale);
}

Complex complex_sinc(Complex value) {
    if (std::abs(value) < 1.0e-3) {
        const Complex value2 = value * value;
        return Complex(1.0, 0.0) - value2 / 6.0 +
            value2 * value2 / 120.0 - value2 * value2 * value2 / 5040.0 +
            value2 * value2 * value2 * value2 / 362880.0;
    }
    return std::sin(value) / value;
}

Complex complex_cos(Complex value) {
    if (std::abs(value) < 1.0e-3) {
        const Complex value2 = value * value;
        return Complex(1.0, 0.0) - value2 / 2.0 +
            value2 * value2 / 24.0 - value2 * value2 * value2 / 720.0 +
            value2 * value2 * value2 * value2 / 40320.0;
    }
    return std::cos(value);
}

Scattering interface_scattering(Complex left, Complex right, bool& ok) {
    const Complex denominator = left + right;
    if (!usable_denominator(denominator, std::abs(left) + std::abs(right))) {
        ok = false;
        return {};
    }
    Scattering result;
    result.r_left = (left - right) / denominator;
    result.r_right = -result.r_left;
    result.t_left_right = 2.0 * left / denominator;
    result.t_right_left = 2.0 * right / denominator;
    return result;
}

Scattering regular_layer_scattering(
    Complex q_squared,
    Complex g,
    double k0,
    double thickness,
    double reference_admittance,
    bool& ok) {
    const Complex q = passive_normal_root(q_squared);
    const Complex delta = k0 * thickness * q;
    const Complex c = complex_cos(delta);
    const Complex s = complex_sinc(delta);
    const Complex imaginary(0.0, 1.0);
    const Complex m11 = c;
    const Complex m22 = c;
    const Complex m12 = imaginary * g * (k0 * thickness) * s;
    const Complex m21 = imaginary * (q_squared / g) * (k0 * thickness) * s;
    const double a = reference_admittance;
    const Complex denominator = a * (m11 + m22) - m21 - a * a * m12;
    const double scale = a * (std::abs(m11) + std::abs(m22)) +
        std::abs(m21) + a * a * std::abs(m12);
    if (!usable_denominator(denominator, scale)) {
        ok = false;
        return {};
    }
    Scattering result;
    result.r_left = (m21 + a * m22 - a * m11 - a * a * m12) / denominator;
    result.r_right = (m21 - a * m22 + a * m11 - a * a * m12) / denominator;
    result.t_left_right = 2.0 * a / denominator;
    result.t_right_left = result.t_left_right;
    return result;
}

Scattering ordinary_layer_scattering(
    Complex admittance,
    Complex delta,
    double reference_admittance,
    bool& ok) {
    const Complex reference(reference_admittance, 0.0);
    const Complex interface_denominator = reference + admittance;
    if (!usable_denominator(
            interface_denominator,
            std::abs(reference) + std::abs(admittance))) {
        ok = false;
        return {};
    }
    const Complex reflection =
        (reference - admittance) / interface_denominator;
    const Complex propagation = std::exp(Complex(0.0, 1.0) * delta);
    const Complex propagation_squared = propagation * propagation;
    const Complex denominator = Complex(1.0, 0.0) -
        reflection * reflection * propagation_squared;
    if (!finite_complex(propagation) ||
        !usable_denominator(
            denominator,
            1.0 + std::abs(reflection * reflection * propagation_squared))) {
        ok = false;
        return {};
    }
    Scattering result;
    result.r_left = reflection *
        (Complex(1.0, 0.0) - propagation_squared) / denominator;
    result.r_right = result.r_left;
    result.t_left_right =
        (Complex(1.0, 0.0) - reflection * reflection) * propagation /
        denominator;
    result.t_right_left = result.t_left_right;
    return result;
}

double real_sinc(double value) {
    if (std::abs(value) < 1.0e-4) {
        const double value2 = value * value;
        return 1.0 - value2 / 6.0 + value2 * value2 / 120.0;
    }
    return std::sin(value) / value;
}

double decay_integral(double kappa, double thickness) {
    if (thickness <= 0.0) {
        return 0.0;
    }
    if (std::abs(kappa * thickness) < 1.0e-8) {
        const double value = kappa * thickness;
        return thickness * (1.0 - value + (2.0 / 3.0) * value * value);
    }
    return -std::expm1(-2.0 * kappa * thickness) / (2.0 * kappa);
}

double regular_absorption_integral(
    Complex psi_left,
    Complex chi_left,
    Complex epsilon,
    Complex q_squared,
    Complex g,
    double tangent_k_squared,
    double k0,
    double thickness,
    double incident_flux,
    int polarization) {
    static constexpr double nodes[4] = {
        0.18343464249564980494,
        0.52553240991632898582,
        0.79666647741362673959,
        0.96028985649753623168};
    static constexpr double weights[4] = {
        0.36268378337836198297,
        0.31370664587788728734,
        0.22238103445337447054,
        0.10122853629037625915};
    const Complex q = passive_normal_root(q_squared);
    const Complex imaginary(0.0, 1.0);
    double integral = 0.0;
    for (int side : {-1, 1}) {
        for (int n = 0; n < 4; ++n) {
            const double x =
                0.5 * thickness * (1.0 + side * nodes[n]);
            const Complex delta = k0 * x * q;
            const Complex c = complex_cos(delta);
            const Complex s = complex_sinc(delta);
            const Complex psi = c * psi_left +
                imaginary * g * (k0 * x) * s * chi_left;
            const Complex chi = imaginary * (q_squared / g) *
                (k0 * x) * s * psi_left + c * chi_left;
            double density = 0.0;
            if (polarization == 1) {
                density = k0 * epsilon.imag() * std::norm(psi) /
                    incident_flux;
            } else {
                density = k0 * epsilon.imag() *
                    (std::norm(chi) +
                     tangent_k_squared * std::norm(psi / epsilon)) /
                    incident_flux;
            }
            integral += weights[n] * density;
        }
    }
    return 0.5 * thickness * integral;
}

} // namespace

std::size_t required_wo_complex_workspace(std::size_t layers) {
    return 7 * layers + 16;
}

Status laser_absorption_components_inplace(
    std::size_t layers,
    const double* bounds,
    const Complex* eps,
    int polarization,
    double theta,
    double wavelength_m,
    double* q_sec,
    double* q_osc,
    double* result,
    Complex* work_complex,
    std::size_t work_complex_size) {
    if (layers == 0 || bounds == nullptr || eps == nullptr ||
        q_sec == nullptr || q_osc == nullptr || result == nullptr ||
        work_complex == nullptr || !(wavelength_m > 0.0) ||
        !std::isfinite(wavelength_m) || !std::isfinite(theta) ||
        (polarization != 1 && polarization != 2) ||
        work_complex_size < required_wo_complex_workspace(layers)) {
        return Status::InvalidInput;
    }
    const double incidence_mu = std::cos(theta);
    if (!(incidence_mu > 0.0) || incidence_mu > 1.0) {
        return Status::InvalidInput;
    }
    for (std::size_t i = 0; i < layers; ++i) {
        q_sec[i] = 0.0;
        q_osc[i] = 0.0;
        if (!std::isfinite(bounds[i + 1]) ||
            !std::isfinite(bounds[i + 2]) ||
            bounds[i + 2] < bounds[i + 1]) {
            return Status::InvalidInput;
        }
    }
    for (std::size_t i = 0; i < NumWoResult; ++i) {
        result[i] = 0.0;
    }

    const std::size_t media = layers + 2;
    const std::size_t components = layers + 2;
    for (std::size_t i = 0; i < media; ++i) {
        if (!finite_complex(eps[i])) {
            return Status::NonfiniteValue;
        }
        if (eps[i].imag() < -negative_imag_tol) {
            return Status::NegativeEpsImag;
        }
    }
    const Complex epsilon_in = passive_epsilon(eps[0]);
    if (!(epsilon_in.real() > eps_real_min) ||
        std::abs(epsilon_in.imag()) > 1.0e-12) {
        return Status::InvalidInput;
    }
    // The passive terminal medium carries only an outgoing/decaying wave.
    // Its full complex admittance determines boundary Poynting flux below.

    Complex* normal_k = work_complex;
    Complex* admittance = normal_k + media;
    Complex* r_left = admittance + media;
    Complex* r_right = r_left + components;
    Complex* t_left_right = r_right + components;
    Complex* t_right_left = t_left_right + components;
    Complex* suffix_reflection = t_right_left + components;

    const double mu2 = incidence_mu * incidence_mu;
    const Complex normal_in_squared = epsilon_in * mu2;
    const double tangent_k_squared =
        std::max(0.0, epsilon_in.real() * (1.0 - mu2));
    const double k0 = two_pi / wavelength_m;
    for (std::size_t i = 0; i < media; ++i) {
        const Complex epsilon = passive_epsilon(eps[i]);
        const Complex normal_squared =
            (epsilon - epsilon_in) + normal_in_squared;
        normal_k[i] = passive_normal_root(normal_squared);
        if (polarization == 1) {
            admittance[i] = normal_k[i];
        } else {
            if (std::abs(epsilon) <= epsilon_las) {
                return Status::WoSolverFailure;
            }
            admittance[i] = normal_k[i] / epsilon;
        }
        if (!finite_complex(normal_k[i]) ||
            !finite_complex(admittance[i])) {
            return Status::NonfiniteValue;
        }
    }
    const double incident_flux = admittance[0].real();
    if (!(incident_flux > 0.0) || !std::isfinite(incident_flux)) {
        return Status::InvalidInput;
    }

    constexpr double reference_admittance = 1.0;
    const Complex reference(reference_admittance, 0.0);
    bool ok = true;
    Scattering block = interface_scattering(admittance[0], reference, ok);
    if (!ok) {
        return Status::WoSolverFailure;
    }
    r_left[0] = block.r_left;
    r_right[0] = block.r_right;
    t_left_right[0] = block.t_left_right;
    t_right_left[0] = block.t_right_left;

    for (std::size_t i = 1; i <= layers; ++i) {
        const Complex epsilon = passive_epsilon(eps[i]);
        const Complex g =
            polarization == 1 ? Complex(1.0, 0.0) : epsilon;
        if (std::abs(g) <= epsilon_las) {
            return Status::WoSolverFailure;
        }
        const Complex q_squared = normal_k[i] * normal_k[i];
        const double thickness = bounds[i + 1] - bounds[i];
        const Complex delta = k0 * thickness * normal_k[i];
        const bool use_regular_operator = std::abs(delta) <= 0.5 ||
            (std::abs(admittance[i]) <=
                 1.0e-8 * reference_admittance &&
             std::abs(delta.imag()) < 40.0);
        block = use_regular_operator
            ? regular_layer_scattering(
                  q_squared,
                  g,
                  k0,
                  thickness,
                  reference_admittance,
                  ok)
            : ordinary_layer_scattering(
                  admittance[i], delta, reference_admittance, ok);
        if (!ok) {
            return Status::WoSolverFailure;
        }
        r_left[i] = block.r_left;
        r_right[i] = block.r_right;
        t_left_right[i] = block.t_left_right;
        t_right_left[i] = block.t_right_left;
    }

    block = interface_scattering(
        reference, admittance[layers + 1], ok);
    if (!ok) {
        return Status::WoSolverFailure;
    }
    r_left[layers + 1] = block.r_left;
    r_right[layers + 1] = block.r_right;
    t_left_right[layers + 1] = block.t_left_right;
    t_right_left[layers + 1] = block.t_right_left;

    suffix_reflection[components] = Complex(0.0, 0.0);
    for (std::size_t cc = components; cc > 0; --cc) {
        const std::size_t c = cc - 1;
        const Complex denominator = Complex(1.0, 0.0) -
            r_right[c] * suffix_reflection[c + 1];
        if (!usable_denominator(
                denominator,
                1.0 + std::abs(r_right[c] * suffix_reflection[c + 1]))) {
            return Status::WoSolverFailure;
        }
        suffix_reflection[c] = r_left[c] +
            t_right_left[c] * suffix_reflection[c + 1] *
                t_left_right[c] / denominator;
    }

    const Complex reflection_amplitude = suffix_reflection[0];
    Complex forward(1.0, 0.0);
    double a_sec = 0.0;
    double a_osc = 0.0;
    for (std::size_t c = 0; c < components; ++c) {
        const Complex backward_left = suffix_reflection[c] * forward;
        const Complex denominator = Complex(1.0, 0.0) -
            r_right[c] * suffix_reflection[c + 1];
        if (!usable_denominator(
                denominator,
                1.0 + std::abs(r_right[c] * suffix_reflection[c + 1]))) {
            return Status::WoSolverFailure;
        }
        const Complex forward_right =
            t_left_right[c] * forward / denominator;
        const Complex backward_right =
            suffix_reflection[c + 1] * forward_right;
        if (c >= 1 && c <= layers) {
            const std::size_t i = c;
            const Complex psi_left = forward + backward_left;
            const Complex chi_left =
                reference * (forward - backward_left);
            const Complex psi_right = forward_right + backward_right;
            const Complex chi_right =
                reference * (forward_right - backward_right);
            const Complex epsilon = passive_epsilon(eps[i]);
            const Complex g =
                polarization == 1 ? Complex(1.0, 0.0) : epsilon;
            const Complex q_squared = normal_k[i] * normal_k[i];
            const double thickness = bounds[i + 1] - bounds[i];
            const bool wave_basis_conditioned =
                std::abs(admittance[i]) >
                1.0e-8 * reference_admittance;
            if (wave_basis_conditioned) {
                const Complex physical_forward =
                    0.5 * (psi_left + chi_left / admittance[i]);
                const Complex physical_backward =
                    0.5 * (psi_left - chi_left / admittance[i]);
                const Complex physical_backward_right =
                    0.5 * (psi_right - chi_right / admittance[i]);
                const double kappa = k0 * normal_k[i].imag();
                const double beta = k0 * normal_k[i].real();
                const double decay = decay_integral(kappa, thickness);
                double integral_sec =
                    (std::norm(physical_forward) +
                     std::norm(physical_backward_right)) * decay;
                const double phase = beta * thickness;
                const Complex oscillatory_integral = thickness *
                    std::exp(Complex(0.0, phase)) * real_sinc(phase);
                double integral_osc = 2.0 * std::real(
                    physical_forward * std::conj(physical_backward) *
                    oscillatory_integral);
                if (polarization == 2) {
                    const double epsilon_norm = std::norm(epsilon);
                    if (epsilon_norm <= epsilon_las) {
                        return Status::WoSolverFailure;
                    }
                    const double normal_norm = std::norm(normal_k[i]);
                    integral_sec *=
                        (normal_norm + tangent_k_squared) / epsilon_norm;
                    integral_osc *=
                        (tangent_k_squared - normal_norm) / epsilon_norm;
                }
                const double scale =
                    k0 * epsilon.imag() / incident_flux;
                q_sec[i - 1] = scale * integral_sec;
                q_osc[i - 1] = scale * integral_osc;
            } else {
                q_sec[i - 1] = regular_absorption_integral(
                    psi_left,
                    chi_left,
                    epsilon,
                    q_squared,
                    g,
                    tangent_k_squared,
                    k0,
                    thickness,
                    incident_flux,
                    polarization);
                q_osc[i - 1] = 0.0;
            }
            if (!std::isfinite(q_sec[i - 1]) ||
                !std::isfinite(q_osc[i - 1])) {
                return Status::NonfiniteValue;
            }
            a_sec += q_sec[i - 1];
            a_osc += q_osc[i - 1];
        }
        forward = forward_right;
    }

    const double reflected = std::norm(reflection_amplitude);
    double transmitted = admittance[layers + 1].real() *
        std::norm(forward) / incident_flux;
    if (transmitted < 0.0 && transmitted > -1.0e-14) {
        transmitted = 0.0;
    }
    const double absorbed = a_sec + a_osc;
    const double residual =
        1.0 - reflected - transmitted - absorbed;
    if (!std::isfinite(reflected) || !std::isfinite(transmitted) ||
        !std::isfinite(absorbed) || !std::isfinite(residual)) {
        return Status::NonfiniteValue;
    }
    result[WoResultR] = reflected;
    result[WoResultTRaw] = transmitted;
    result[WoResultASec] = a_sec;
    result[WoResultAOsc] = a_osc;
    result[WoResultARaw] = absorbed;
    result[WoResultAccuracyRaw] = residual;
    result[WoResultECutoff] = static_cast<double>(layers);
    result[WoResultTruncated] = 0.0;
    return Status::OK;
}

} // namespace icarus
