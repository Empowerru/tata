#include "icarus/detail/ray_sampling.h"
#include <algorithm>
#include <cmath>

namespace icarus {

static double launch_radius(const GridRZ& grid, const LaserConfig& laser, double wavelength) {
    if (std::holds_alternative<ParallelGaussianConfig>(laser.geometry)) {
        return 0.5 * std::get<ParallelGaussianConfig>(laser.geometry).launch_spot_d4sigma_m;
    }
    const auto& focus = std::get<FocusedGaussianConfig>(laser.geometry);
    if (focus.launch_spot_mode == LaunchSpotMode::Explicit) {
        return 0.5 * focus.explicit_launch_spot_d4sigma_m;
    }
    const double w0 = 0.5 * focus.focus_spot_d4sigma_m;
    const double z = std::abs(focus.focus_z_m - grid.z_edges.front());
    const double z_rayleigh = pi * w0 * w0 / wavelength;
    return w0 * std::sqrt(1.0 + (z / z_rayleigh) * (z / z_rayleigh));
}

bool sample_ray_bundle(const GridRZ& grid, const LaserConfig& laser, RayBundle& bundle) {
    const std::size_t n = laser.sampling.number_of_rays;
    if (grid.nr == 0 || grid.nz == 0 || n == 0 || !(laser.wavelength_m > 0.0)) {
        return false;
    }
    const double w_launch = launch_radius(grid, laser, laser.wavelength_m);
    if (!(w_launch > 0.0) || !std::isfinite(w_launch)) {
        return false;
    }
    double w_focus = w_launch;
    double focus_z = 0.0;
    bool focused = false;
    if (std::holds_alternative<FocusedGaussianConfig>(laser.geometry)) {
        const auto& focus = std::get<FocusedGaussianConfig>(laser.geometry);
        w_focus = 0.5 * focus.focus_spot_d4sigma_m;
        focus_z = focus.focus_z_m;
        focused = true;
        if (!(w_focus > 0.0) || !(focus_z > grid.z_edges.front())) {
            return false;
        }
    }
    const double rmax = grid.r_edges.back();
    const double captured = 1.0 - std::exp(-2.0 * rmax * rmax / (w_launch * w_launch));
    const double effective_captured = std::max(0.0, std::min(1.0 - laser.sampling.omitted_power_fraction, captured));
    bundle.launch_r.assign(n, 0.0);
    bundle.focus_r.assign(n, 0.0);
    bundle.dimensionless_radius.assign(n, 0.0);
    bundle.direction_r.assign(n, 0.0);
    bundle.direction_z.assign(n, 1.0);
    bundle.power_weight.assign(n, 0.0);
    bundle.captured_power_fraction = effective_captured;
    bundle.aperture_uninjected_power_fraction = 1.0 - effective_captured;
    bundle.launch_z = grid.z_edges.front();
    bundle.focus_z_m = 0.0;
    bundle.focus_spot_d4sigma_m = 0.0;
    if (std::holds_alternative<FocusedGaussianConfig>(laser.geometry)) {
        const auto& f = std::get<FocusedGaussianConfig>(laser.geometry);
        bundle.focus_z_m = f.focus_z_m;
        bundle.focus_spot_d4sigma_m = f.focus_spot_d4sigma_m;
    }

    if (laser.sampling.mode == RaySamplingMode::EqualPower) {
        for (std::size_t i = 0; i < n; ++i) {
            const double f0 = effective_captured * static_cast<double>(i) / static_cast<double>(n);
            const double f1 = effective_captured * static_cast<double>(i + 1) / static_cast<double>(n);
            const double fm = 0.5 * (f0 + f1);
            bundle.dimensionless_radius[i] = std::sqrt(std::max(0.0, -0.5 * std::log(std::max(1.0e-300, 1.0 - fm))));
            bundle.launch_r[i] = w_launch * bundle.dimensionless_radius[i];
            bundle.power_weight[i] = (f1 - f0);
        }
    } else {
        const double r_cut = w_launch * std::sqrt(std::max(0.0, -0.5 * std::log(std::max(1.0e-300, 1.0 - effective_captured))));
        for (std::size_t i = 0; i < n; ++i) {
            const double r0 = r_cut * static_cast<double>(i) / static_cast<double>(n);
            const double r1 = r_cut * static_cast<double>(i + 1) / static_cast<double>(n);
            bundle.launch_r[i] = 0.5 * (r0 + r1);
            bundle.dimensionless_radius[i] = bundle.launch_r[i] / w_launch;
            bundle.power_weight[i] = std::exp(-2.0 * r0 * r0 / (w_launch * w_launch)) -
                                     std::exp(-2.0 * r1 * r1 / (w_launch * w_launch));
        }
    }

    if (focused) {
        const double dz = focus_z - grid.z_edges.front();
        for (std::size_t i = 0; i < n; ++i) {
            bundle.focus_r[i] = w_focus * bundle.dimensionless_radius[i];
            const double slope = (bundle.focus_r[i] - bundle.launch_r[i]) / dz;
            const double norm = std::sqrt(1.0 + slope * slope);
            bundle.direction_r[i] = slope / norm;
            bundle.direction_z[i] = 1.0 / norm;
        }
    } else {
        for (std::size_t i = 0; i < n; ++i) {
            bundle.focus_r[i] = bundle.launch_r[i];
        }
    }
    if (!focused) {
        for (std::size_t i = 0; i < n; ++i) {
            const double norm = std::hypot(bundle.direction_r[i], bundle.direction_z[i]);
            if (norm > 0.0) {
                bundle.direction_r[i] /= norm;
                bundle.direction_z[i] /= norm;
            }
        }
    }
    return true;
}

} // namespace icarus
