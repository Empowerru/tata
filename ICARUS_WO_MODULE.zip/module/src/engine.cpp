#include "icarus/engine.h"
#include "icarus/detail/hybrid_transport.h"
#include "icarus/detail/ray_sampling.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#ifdef ICARUS_HAS_OPENMP
#include <omp.h>
#endif

namespace icarus {

static std::size_t find_or_add_wavelength(std::vector<WavelengthGroupState>& groups, double wavelength_m) {
    for (std::size_t i = 0; i < groups.size(); ++i) {
        if (groups[i].wavelength_m == wavelength_m) {
            return i;
        }
    }
    WavelengthGroupState state;
    state.wavelength_m = wavelength_m;
    groups.push_back(state);
    return groups.size() - 1;
}

template <class T>
static std::size_t vector_memory_bytes(const std::vector<T>& values) {
    return values.capacity() * sizeof(T);
}

static bool validate_sampling_config(const RaySamplingConfig& sampling) {
    return sampling.number_of_rays > 0 &&
           std::isfinite(sampling.omitted_power_fraction) &&
           sampling.omitted_power_fraction >= 0.0 &&
           sampling.omitted_power_fraction < 1.0;
}

static bool validate_geometry_config(const GridRZ& grid, const LaserConfig& laser) {
    if (std::holds_alternative<ParallelGaussianConfig>(laser.geometry)) {
        const auto& parallel = std::get<ParallelGaussianConfig>(laser.geometry);
        return std::isfinite(parallel.launch_spot_d4sigma_m) && parallel.launch_spot_d4sigma_m > 0.0;
    }
    const auto& focused = std::get<FocusedGaussianConfig>(laser.geometry);
    if (!std::isfinite(focused.focus_z_m) || focused.focus_z_m <= grid.z_edges.front() ||
        !std::isfinite(focused.focus_spot_d4sigma_m) || focused.focus_spot_d4sigma_m <= 0.0) {
        return false;
    }
    if (focused.launch_spot_mode == LaunchSpotMode::Explicit) {
        return std::isfinite(focused.explicit_launch_spot_d4sigma_m) && focused.explicit_launch_spot_d4sigma_m > 0.0;
    }
    return true;
}

static bool validate_pulse_config(const PulseShapeConfig& pulse) {
    if (std::holds_alternative<GaussianPulseConfig>(pulse)) {
        const auto& g = std::get<GaussianPulseConfig>(pulse);
        return std::isfinite(g.center_time_s) && std::isfinite(g.sigma_s) && g.sigma_s > 0.0;
    }
    if (std::holds_alternative<TriangularPulseConfig>(pulse)) {
        const auto& t = std::get<TriangularPulseConfig>(pulse);
        return std::isfinite(t.start_time_s) && std::isfinite(t.peak_time_s) && std::isfinite(t.end_time_s) &&
               t.start_time_s < t.peak_time_s && t.peak_time_s < t.end_time_s;
    }
    const auto& tab = std::get<TabulatedPulseConfig>(pulse);
    return !tab.file_path.empty() &&
           std::isfinite(tab.time_shift_s) &&
           std::isfinite(tab.time_scale_to_s) &&
           tab.time_scale_to_s > 0.0;
}

static bool validate_config(const GridRZ& grid, const RTConfig& config) {
    const auto& dc=config.laser_diagnostics;
    if(dc.theta_bins<2 || dc.theta_bins%2 || (dc.enabled &&
        (!std::isfinite(dc.write_interval_s) || dc.write_interval_s<=0 || dc.output_directory.empty()))) return false;
    if (config.lasers.empty() ||
        !std::isfinite(config.transport.wo_switch_offset) || config.transport.wo_switch_offset < 0 ||
        (config.transport.wo_exit_mode != WoExitMode::MatchLastLayer && config.transport.wo_exit_mode != WoExitMode::LegacyVacuum) ||
        !std::isfinite(config.transport.alpha_gw) ||
        !(config.transport.alpha_gw > 0.0 && config.transport.alpha_gw < 1.0) ||
        !std::isfinite(config.transport.beta_gw) ||
        config.transport.beta_gw < 0.0 ||
        !std::isfinite(config.transport.min_relative_power) ||
        config.transport.min_relative_power < 0.0 ||
        !std::isfinite(config.transport.max_unresolved_power_fraction) ||
        config.transport.max_unresolved_power_fraction < 0.0 ||
        config.transport.max_unresolved_power_fraction > 1.0 ||
        config.transport.max_wo_events_per_ray < 0 ||
        config.transport.max_cell_crossings <= 0 ||
        config.parallel.number_of_threads < 0) {
        return false;
    }
    for (const LaserConfig& laser : config.lasers) {
        if (!std::isfinite(laser.wavelength_m) || laser.wavelength_m <= 0.0 ||
            !std::isfinite(laser.total_energy_j) || laser.total_energy_j < 0.0 ||
            !std::isfinite(laser.p_polarization_fraction) ||
            laser.p_polarization_fraction < 0.0 || laser.p_polarization_fraction > 1.0 ||
            !validate_sampling_config(laser.sampling) ||
            !validate_geometry_config(grid, laser) ||
            !validate_pulse_config(laser.pulse)) {
            return false;
        }
    }
    return true;
}

static bool validate_material_shape(const MaterialFields& materials, std::size_t groups, std::size_t cells) {
    return cells != 0 && groups <= std::numeric_limits<std::size_t>::max() / cells &&
           materials.eps0_by_wavelength.size() == groups * cells &&
           materials.eps1_by_wavelength.size() == groups * cells &&
           materials.f0.size() == cells;
}

static std::uint32_t status_bit(Status status) {
    const int value = status_value(status);
    return value > 0 && value < 32
        ? std::uint32_t{1} << static_cast<unsigned int>(value)
        : 0;
}

static bool unresolved_budget_can_accept(const Diagnostics& diagnostics) {
    constexpr std::uint32_t eligible =
        (std::uint32_t{1} << static_cast<unsigned int>(Status::NoValidCellEvent)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::MaxCellCrossings)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoEventLimit)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoProfileCapacity)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoBadEntranceEps)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoSolverFailure)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoRescalingFailure)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::GrazingWo)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoDisabledRequired)) |
        (std::uint32_t{1} << static_cast<unsigned int>(Status::WoConservationFailure));
    return diagnostics.failure_status_mask != 0 &&
        (diagnostics.failure_status_mask & ~eligible) == 0;
}

void Diagnostics::clear() {
    *this = Diagnostics{};
}

void Diagnostics::finish() {
    energy_residual_w =
        input_power_w -
        absorbed_go_w -
        absorbed_wo_w -
        escaped_go_w -
        escaped_wo_w -
        cutoff_power_w -
        unresolved_power_w;
    wo_event_count = static_cast<std::size_t>(wo_events);
}

void Diagnostics::record_status(Status status) {
    if (status != Status::OK && first_error_status == Status::OK) {
        first_error_status = status;
    }
    failure_status_mask |= status_bit(status);
}

void Diagnostics::add(const Diagnostics& o) {
    input_power_w += o.input_power_w;
    absorbed_go_w += o.absorbed_go_w;
    absorbed_wo_w += o.absorbed_wo_w;
    escaped_go_w += o.escaped_go_w;
    escaped_wo_w += o.escaped_wo_w;
    unresolved_power_w += o.unresolved_power_w;
    go_segments += o.go_segments;
    wo_events += o.wo_events;
    wo_layers += o.wo_layers;
    axis_crossings += o.axis_crossings;
    failed_rays += o.failed_rays;
    max_eikonal_error = std::max(max_eikonal_error, o.max_eikonal_error);
    reflected_power_generated_w += o.reflected_power_generated_w;
    exponentials += o.exponentials;
    if (first_error_status == Status::OK && o.first_error_status != Status::OK) {
        first_error_status = o.first_error_status;
    }
    failure_status_mask |= o.failure_status_mask;
    eikonal_error_count += o.eikonal_error_count;
    cutoff_power_w += o.cutoff_power_w;
    wo_conservation_warning_count += o.wo_conservation_warning_count;
    max_wo_raw_residual = std::max(max_wo_raw_residual, o.max_wo_raw_residual);
    max_wo_final_residual = std::max(max_wo_final_residual, o.max_wo_final_residual);
    max_wo_conservation_correction = std::max(max_wo_conservation_correction, o.max_wo_conservation_correction);
    configured_power_w += o.configured_power_w;
    injected_power_w += o.injected_power_w;
    aperture_uninjected_power_w += o.aperture_uninjected_power_w;
    total_rays += o.total_rays;
    cutoff_rays += o.cutoff_rays;
    unresolved_rays += o.unresolved_rays;
    phase_partition_fallback_count += o.phase_partition_fallback_count;
    effective_thread_count = std::max(effective_thread_count, o.effective_thread_count);
    finish();
}

bool IcarusEngine::initialize(const std::vector<double>& r_edges, const std::vector<double>& z_edges, const RTConfig& config) {
    // Publish only a fully built state, including pulses and sampled bundles.
    IcarusEngine candidate;
    try {
        if (!candidate.initialize_candidate(r_edges, z_edges, config)) return false;
    } catch (const std::bad_alloc&) {
        return false;
    } catch (const std::length_error&) {
        return false;
    }
    *this = std::move(candidate);
    return true;
}

bool IcarusEngine::initialize_candidate(const std::vector<double>& r_edges, const std::vector<double>& z_edges, const RTConfig& config) {
    if (r_edges.size() < 2 || z_edges.size() < 2 ||
        r_edges.size() - 1 > static_cast<std::size_t>(std::numeric_limits<int>::max()) / (z_edges.size() - 1)) return false;
    if (!initialize_grid(r_edges, z_edges, grid_) || !validate_config(grid_, config)) {
        return false;
    }
    config_ = config;
    pulses_.assign(config_.lasers.size(), PulseProfile{});
    bundles_.assign(config_.lasers.size(), RayBundle{});
    wavelength_groups_.clear();
    laser_group_index_.assign(config_.lasers.size(), 0);
    for (std::size_t i = 0; i < config_.lasers.size(); ++i) {
        laser_group_index_[i] = find_or_add_wavelength(wavelength_groups_, config_.lasers[i].wavelength_m);
        if (!pulses_[i].initialize(config_.lasers[i].pulse,config_.lasers[i].tail_energy_fraction_per_side)) {
            return false;
        }
        if (!sample_ray_bundle(grid_, config_.lasers[i], bundles_[i])) {
            return false;
        }
        const auto& b = bundles_[i];
        if (!std::isfinite(b.captured_power_fraction)) return false;
        for (std::size_t j = 0; j < b.launch_r.size(); ++j)
            if (!std::isfinite(b.launch_r[j]) || !std::isfinite(b.direction_r[j]) ||
                !std::isfinite(b.direction_z[j]) || !std::isfinite(b.power_weight[j]) || b.power_weight[j] < 0.0)
                return false;
    }
    const std::size_t cells = grid_.nr * grid_.nz;
    // All buffers below are persistent engine-owned storage. A production step
    // reuses them without allocating: material mixing, gradients, deposited
    // cell power, phase sources, and optional per-thread OpenMP workspaces.
    workspace_.cell_power.assign(cells, 0.0);
    workspace_.work_float.assign(required_float_workspace(grid_.nr, grid_.nz), 0.0);
    workspace_.work_complex.assign(required_complex_workspace(grid_.nr, grid_.nz), Complex(0.0, 0.0));
    workspace_.work_int.assign(required_int_workspace(grid_.nr, grid_.nz), 0);
    int thread_count = 0;
#ifdef ICARUS_HAS_OPENMP
    if (config_.parallel.enabled) {
        thread_count = config_.parallel.number_of_threads > 0 ? config_.parallel.number_of_threads : omp_get_max_threads();
        if (thread_count < 1) {
            thread_count = 1;
        }
    }
#endif
    workspace_.thread_workspace.assign(static_cast<std::size_t>(thread_count), TransportThreadWorkspace{});
    for (TransportThreadWorkspace& tw : workspace_.thread_workspace) {
        tw.cell_power.assign(cells, 0.0);
        tw.work_float.assign(required_float_workspace(grid_.nr, grid_.nz), 0.0);
        tw.work_complex.assign(required_complex_workspace(grid_.nr, grid_.nz), Complex(0.0, 0.0));
        tw.work_int.assign(required_int_workspace(grid_.nr, grid_.nz), 0);
        if(config_.laser_diagnostics.enabled) tw.angular.initialize(config_.laser_diagnostics.theta_bins);
    }
    for (WavelengthGroupState& group : wavelength_groups_) {
        group.mixed.epsilon.assign(cells, Complex(1.0, 0.0));
        group.mixed.grad_r.assign(cells, 0.0);
        group.mixed.grad_z.assign(cells, 0.0);
        group.cell_power_w.assign(cells, 0.0);
    }
    laser_average_power_w_.assign(config_.lasers.size(), 0.0);
    group_is_active_.assign(wavelength_groups_.size(), 0);
    phase_source_.assign(2 * cells, 0.0);
    total_source_.assign(cells, 0.0);
    laser_diagnostics_.resize(config_.lasers.size());
    for(std::size_t i=0;i<laser_diagnostics_.size();++i) {
        laser_diagnostics_[i].angular.laser_index=i;
        if(config_.laser_diagnostics.enabled) laser_diagnostics_[i].angular.initialize(config_.laser_diagnostics.theta_bins);
    }
    initialized_ = true;
    return true;
}

double IcarusEngine::step_laser_energy(std::size_t i, double t, double dt) const {
    if (!std::isfinite(t) || !std::isfinite(dt) || !(dt > 0.0) || !std::isfinite(t + dt))
        return std::numeric_limits<double>::quiet_NaN();
    if (i >= config_.lasers.size()) {
        return 0.0;
    }
    return config_.lasers[i].total_energy_j * pulses_[i].step_energy_fraction(t, dt);
}

double IcarusEngine::average_laser_power(std::size_t i, double t, double dt) const {
    if (!(dt > 0.0)) {
        return std::numeric_limits<double>::quiet_NaN();
    }
    return step_laser_energy(i, t, dt) / dt;
}

bool IcarusEngine::active_wavelength_groups(double current_time_s, double time_step_s, std::vector<unsigned char>& active_groups) const {
    std::fill(active_groups.begin(), active_groups.end(), 0);
    if (!initialized_ || !std::isfinite(current_time_s) || !std::isfinite(time_step_s) ||
        !(time_step_s > 0.0) || !std::isfinite(current_time_s + time_step_s) || active_groups.size() != wavelength_groups_.size()) {
        return false;
    }
    std::fill(active_groups.begin(), active_groups.end(), 0);
    bool any_active = false;
    for (std::size_t i = 0; i < config_.lasers.size(); ++i) {
        const double power = average_laser_power(i, current_time_s, time_step_s);
        if (!std::isfinite(power) || power < 0.0) {
            std::fill(active_groups.begin(), active_groups.end(), 0);
            return false;
        }
        if (power > 0.0) {
            active_groups[laser_group_index_[i]] = 1;
            any_active = true;
        }
    }
    return any_active;
}

std::size_t IcarusEngine::persistent_memory_bytes() const {
    std::size_t bytes = 0;
    bytes += vector_memory_bytes(config_.lasers);
    bytes += vector_memory_bytes(grid_.r_edges);
    bytes += vector_memory_bytes(grid_.z_edges);
    bytes += vector_memory_bytes(grid_.r_centers);
    bytes += vector_memory_bytes(grid_.z_centers);
    bytes += vector_memory_bytes(grid_.volume);
    bytes += vector_memory_bytes(grid_.inverse_volume);
    bytes += vector_memory_bytes(grid_.derivative_r);
    bytes += vector_memory_bytes(grid_.derivative_z);
    bytes += vector_memory_bytes(grid_.wls_3x3);
    bytes += vector_memory_bytes(grid_.wls_5x5);
    bytes += vector_memory_bytes(pulses_);
    for (const PulseProfile& pulse : pulses_) {
        bytes += vector_memory_bytes(pulse.table_t);
        bytes += vector_memory_bytes(pulse.table_p);
        bytes += vector_memory_bytes(pulse.table_cumulative);
    }
    bytes += vector_memory_bytes(bundles_);
    for (const RayBundle& bundle : bundles_) {
        bytes += vector_memory_bytes(bundle.launch_r);
        bytes += vector_memory_bytes(bundle.focus_r);
        bytes += vector_memory_bytes(bundle.dimensionless_radius);
        bytes += vector_memory_bytes(bundle.direction_r);
        bytes += vector_memory_bytes(bundle.direction_z);
        bytes += vector_memory_bytes(bundle.power_weight);
    }
    bytes += vector_memory_bytes(laser_group_index_);
    bytes += vector_memory_bytes(wavelength_groups_);
    for (const WavelengthGroupState& group : wavelength_groups_) {
        bytes += vector_memory_bytes(group.mixed.epsilon);
        bytes += vector_memory_bytes(group.mixed.grad_r);
        bytes += vector_memory_bytes(group.mixed.grad_z);
        bytes += vector_memory_bytes(group.cell_power_w);
    }
    bytes += vector_memory_bytes(workspace_.cell_power);
    bytes += vector_memory_bytes(workspace_.work_float);
    bytes += vector_memory_bytes(workspace_.work_complex);
    bytes += vector_memory_bytes(workspace_.work_int);
    bytes += vector_memory_bytes(workspace_.thread_workspace);
    for (const TransportThreadWorkspace& tw : workspace_.thread_workspace) {
        bytes += vector_memory_bytes(tw.cell_power);
        bytes += vector_memory_bytes(tw.work_float);
        bytes += vector_memory_bytes(tw.work_complex);
        bytes += vector_memory_bytes(tw.work_int);
        bytes += vector_memory_bytes(tw.angular.p)+vector_memory_bytes(tw.angular.s);
    }
    bytes += vector_memory_bytes(laser_average_power_w_);
    bytes += vector_memory_bytes(group_is_active_);
    bytes += vector_memory_bytes(phase_source_);
    bytes += vector_memory_bytes(total_source_);
    bytes += vector_memory_bytes(laser_diagnostics_);
    for(const auto& s:laser_diagnostics_) bytes+=vector_memory_bytes(s.angular.p)+vector_memory_bytes(s.angular.s);
    return bytes;
}

Status IcarusEngine::reject_input(std::size_t cell, std::size_t group) {
    std::fill(workspace_.cell_power.begin(), workspace_.cell_power.end(), 0.0);
    std::fill(phase_source_.begin(), phase_source_.end(), 0.0);
    std::fill(total_source_.begin(), total_source_.end(), 0.0);
    for (auto& g : wavelength_groups_) std::fill(g.cell_power_w.begin(), g.cell_power_w.end(), 0.0);
    diagnostics_.clear();
    diagnostics_.invalid_input_cell = cell;
    diagnostics_.invalid_input_group = group;
    diagnostics_.record_status(Status::InvalidInput);
    return Status::InvalidInput;
}

Status IcarusEngine::update_source(double current_time_s, double time_step_s, const MaterialFields& materials) {
    if (!initialized_ || !std::isfinite(current_time_s) || !std::isfinite(time_step_s) ||
        !(time_step_s > 0.0) || !std::isfinite(current_time_s + time_step_s)) return reject_input();
    const std::size_t cells = grid_.nr * grid_.nz;
    diagnostics_.clear();
    std::fill(group_is_active_.begin(), group_is_active_.end(), 0);

    // Pulse integration comes first so inactive steps can skip host epsilon
    // construction and all transport while still clearing visible outputs.
    for (std::size_t i = 0; i < config_.lasers.size(); ++i) {
        const double power = average_laser_power(i, current_time_s, time_step_s);
        if (!std::isfinite(power) || power < 0.0) return reject_input();
        laser_average_power_w_[i] = power;
        diagnostics_.configured_power_w += power;
        diagnostics_.aperture_uninjected_power_w += power * bundles_[i].aperture_uninjected_power_fraction;
        diagnostics_.injected_power_w += power * bundles_[i].captured_power_fraction;
        if (power > 0.0) {
            group_is_active_[laser_group_index_[i]] = 1;
        }
    }

    if (!std::isfinite(diagnostics_.configured_power_w) || !std::isfinite(diagnostics_.injected_power_w) ||
        !std::isfinite(diagnostics_.aperture_uninjected_power_w)) return reject_input();
    diagnostic_writer_.plan(current_time_s,time_step_s,config_,pulses_,laser_average_power_w_,laser_diagnostics_);
    for(std::size_t i=0;i<laser_diagnostics_.size();++i) {
        auto& s=laser_diagnostics_[i];
        s.temporal_discarded_j=std::max(0.0,config_.lasers[i].total_energy_j*pulses_[i].full_step_energy_fraction(current_time_s,time_step_s)-laser_average_power_w_[i]*time_step_s);
        s.power.configured_power_w=laser_average_power_w_[i];
        s.power.injected_power_w=laser_average_power_w_[i]*bundles_[i].captured_power_fraction;
        s.power.aperture_uninjected_power_w=laser_average_power_w_[i]*bundles_[i].aperture_uninjected_power_fraction;
    }
    for(auto& g:wavelength_groups_) std::fill(g.cell_power_w.begin(),g.cell_power_w.end(),0.0);

    bool any_active = false;
    for (unsigned char active : group_is_active_) {
        any_active = any_active || active != 0;
    }
    if (!any_active) {
        std::fill(workspace_.cell_power.begin(), workspace_.cell_power.end(), 0.0);
        std::fill(phase_source_.begin(), phase_source_.end(), 0.0);
        std::fill(total_source_.begin(), total_source_.end(), 0.0);
        diagnostics_.finish();
        diagnostics_.effective_thread_count = 1;
        diagnostic_writer_.write(current_time_s,time_step_s,config_,pulses_,laser_diagnostics_);
        return Status::OK;
    }

    if (!validate_material_shape(materials, wavelength_groups_.size(), cells)) {
        return reject_input();
    }
    for (std::size_t j = 0; j < cells; ++j)
        if (!std::isfinite(materials.f0[j]) || materials.f0[j] < 0.0 || materials.f0[j] > 1.0)
            return reject_input(j);
    // Validate every active group before any ray can deposit power.
    for (std::size_t g = 0; g < wavelength_groups_.size(); ++g) {
        if (!group_is_active_[g]) continue;
        for (std::size_t j = 0; j < cells; ++j) {
            const auto a = materials.eps0_by_wavelength[g * cells + j];
            const auto b = materials.eps1_by_wavelength[g * cells + j];
            if (!std::isfinite(a.real()) || !std::isfinite(a.imag()) || a.imag() < 0.0 ||
                !std::isfinite(b.real()) || !std::isfinite(b.imag()) || b.imag() < 0.0) return reject_input(j, g);
        }
        auto& mixed = wavelength_groups_[g].mixed;
        build_mixed_fields_for_group(grid_, materials, g, mixed);
        for (std::size_t j = 0; j < cells; ++j)
            if (!std::isfinite(mixed.epsilon[j].real()) || !std::isfinite(mixed.epsilon[j].imag()) ||
                !std::isfinite(mixed.grad_r[j]) || !std::isfinite(mixed.grad_z[j])) return reject_input(j, g);
    }
    std::fill(workspace_.cell_power.begin(), workspace_.cell_power.end(), 0.0);
    std::fill(phase_source_.begin(), phase_source_.end(), 0.0);
    std::fill(total_source_.begin(), total_source_.end(), 0.0);

    // Each active wavelength group gets its own mixed dielectric, gradients,
    // transport deposition, and phase partition before being added to totals.
    for (std::size_t group_index = 0; group_index < wavelength_groups_.size(); ++group_index) {
        if (group_is_active_[group_index] == 0) {
            continue;
        }
        WavelengthGroupState& group = wavelength_groups_[group_index];
        std::fill(group.cell_power_w.begin(), group.cell_power_w.end(), 0.0);
        for (std::size_t i = 0; i < config_.lasers.size(); ++i) {
            if (laser_group_index_[i] != group_index || !(laser_average_power_w_[i] > 0.0)) {
                continue;
            }
            Status st = trace_laser_bundle_rz_unchecked(
            grid_,
            group.mixed,
            bundles_[i],
            laser_average_power_w_[i],
            config_.lasers[i].p_polarization_fraction,
            config_.lasers[i].wavelength_m,
            config_.transport,
            group.cell_power_w,
            laser_diagnostics_[i].power,
            workspace_.work_float.data(),
            workspace_.work_float.size(),
            workspace_.work_complex.data(),
            workspace_.work_complex.size(),
            workspace_.work_int.data(),
            workspace_.work_int.size(),
            config_.parallel,
            workspace_.thread_workspace.empty() ? nullptr : &workspace_.thread_workspace,
            laser_diagnostics_[i].scheduled ? &laser_diagnostics_[i].angular : nullptr);
            // Configuration totals above are already global; add only transport fields.
            auto transport_d=laser_diagnostics_[i].power;
            transport_d.configured_power_w=transport_d.injected_power_w=transport_d.aperture_uninjected_power_w=0;
            diagnostics_.add(transport_d);
            if (st != Status::OK) {
                diagnostics_.record_status(st);
            }
        }
        add_partitioned_deposition_for_group(grid_, materials, group_index, group.cell_power_w, phase_source_, diagnostics_);
        for (std::size_t idx = 0; idx < cells; ++idx) {
            workspace_.cell_power[idx] += group.cell_power_w[idx];
        }
    }
    diagnostics_.finish();
    for (std::size_t idx = 0; idx < cells; ++idx) {
        total_source_[idx] = phase_source_[idx] + phase_source_[cells + idx];
        if (!std::isfinite(total_source_[idx]) || !std::isfinite(phase_source_[idx]) ||
            !std::isfinite(phase_source_[cells + idx]) || phase_source_[idx] < 0.0 || phase_source_[cells + idx] < 0.0)
            return reject_input(idx);
    }
    const Status raw_status = diagnostics_.first_error_status;
    diagnostic_writer_.write(current_time_s,time_step_s,config_,pulses_,laser_diagnostics_);
    if (raw_status == Status::OK || diagnostics_.injected_power_w <= 0.0 ||
        !unresolved_budget_can_accept(diagnostics_)) {
        return raw_status;
    }
    const double unresolved_fraction =
        diagnostics_.unresolved_power_w / diagnostics_.injected_power_w;
    return std::isfinite(unresolved_fraction) &&
            unresolved_fraction <=
                config_.transport.max_unresolved_power_fraction
        ? Status::OK
        : raw_status;
}

} // namespace icarus
