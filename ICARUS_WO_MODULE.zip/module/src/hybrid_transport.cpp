#include "icarus/detail/hybrid_transport.h"
#include "icarus/detail/geometry_rz.h"
#include "icarus/detail/wo_rescale.h"
#include "icarus/detail/wo_solver.h"
#include <algorithm>
#include <cmath>
#include <limits>
#ifdef ICARUS_HAS_OPENMP
#include <omp.h>
#endif

namespace icarus {

namespace {

struct WorkspaceSlices {
    double* roots = nullptr;
    double* wo_len = nullptr;
    double* bounds = nullptr;
    double* q_sec = nullptr;
    double* q_osc = nullptr;
    double* q_rescaled = nullptr;
    double* q_profile_s = nullptr;
    double* q_profile_p = nullptr;
    double* wo_result = nullptr;
    double* rescale_result = nullptr;
    Complex* eps_wo = nullptr;
    Complex* solver_work = nullptr;
    std::size_t solver_work_size = 0;
    int* wo_ir = nullptr;
    int* wo_iz = nullptr;
};

WorkspaceSlices workspace_slices(
    std::size_t cells,
    std::size_t cap,
    double* wf,
    Complex* wc,
    int* wi) {
    // The caller owns one contiguous numerical workspace for the lifetime of a
    // step. These slices give GO and WO routines scratch arrays without heap
    // allocation inside ray updates.
    WorkspaceSlices s;
    std::size_t p = 2 * cells;
    s.roots = wf + p; p += 2;
    s.wo_len = wf + p; p += cap;
    s.bounds = wf + p; p += cap + 3;
    s.q_sec = wf + p; p += cap;
    s.q_osc = wf + p; p += cap;
    s.q_rescaled = wf + p; p += cap;
    s.q_profile_s = wf + p; p += cap;
    s.q_profile_p = wf + p; p += cap;
    s.wo_result = wf + p; p += NumWoResult;
    s.rescale_result = wf + p;
    s.eps_wo = wc;
    s.solver_work = wc + cap + 2;
    s.solver_work_size = required_wo_complex_workspace(cap);
    s.wo_ir = wi;
    s.wo_iz = wi + cap;
    return s;
}

void set_batch_status(Diagnostics& d, Status status) {
    d.record_status(status);
}

void launch_entry_normal(const GridRZ& grid, double r, double z, double ur, double uz, double& nr, double& nz) {
    const double domain = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(r),
        std::abs(z),
        std::numeric_limits<double>::min()});
    const double tol = 128.0 * std::numeric_limits<double>::epsilon() * domain;
    nr = 0.0;
    nz = 0.0;
    if (std::abs(z - grid.z_edges.front()) <= tol && uz > 0.0) {
        nz = 1.0;
    } else if (std::abs(z - grid.z_edges.back()) <= tol && uz < 0.0) {
        nz = -1.0;
    } else if (std::abs(r - grid.r_edges.back()) <= tol && ur < 0.0) {
        nr = -1.0;
    }
}

int launch_entry_face_mask(const GridRZ& grid, double r, double z, double ur, double uz) {
    // Marks faces already used for entry so the next event search ignores the
    // same face. The mask is local to the current cell transition.
    const double domain = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(r),
        std::abs(z),
        std::numeric_limits<double>::min()});
    const double tol = 128.0 * std::numeric_limits<double>::epsilon() * domain;
    int mask = 0;
    if (std::abs(z - grid.z_edges.front()) <= tol && uz > 0.0) {
        mask |= FaceZMin;
    }
    if (std::abs(z - grid.z_edges.back()) <= tol && uz < 0.0) {
        mask |= FaceZMax;
    }
    if (std::abs(r - grid.r_edges.back()) <= tol && ur < 0.0) {
        mask |= FaceRMax;
    }
    if (std::abs(r - grid.r_edges.front()) <= tol && ur > 0.0) {
        mask |= FaceRMin;
    }
    return mask;
}

void entry_normal_from_face(int face_mask, double& nr, double& nz) {
    nr = 0.0;
    nz = 0.0;
    if ((face_mask & FaceRMax) != 0) {
        nr += 1.0;
    }
    if ((face_mask & FaceRMin) != 0) {
        nr -= 1.0;
    }
    if ((face_mask & FaceZMax) != 0) {
        nz += 1.0;
    }
    if ((face_mask & FaceZMin) != 0) {
        nz -= 1.0;
    }
    const double n = std::hypot(nr, nz);
    if (n > 0.0) {
        nr /= n;
        nz /= n;
    }
}

int entry_face_mask_for_cell(
    const GridRZ& grid,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double ur,
    double uz) {
    const double dr = grid.r_edges[ir + 1] - grid.r_edges[ir];
    const double dz = grid.z_edges[iz + 1] - grid.z_edges[iz];
    const double scale = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(dr),
        std::abs(dz),
        std::numeric_limits<double>::min()});
    const double tolerance =
        128.0 * std::numeric_limits<double>::epsilon() * scale;
    int mask = 0;
    if (ur > 0.0 && std::abs(r - grid.r_edges[ir]) <= tolerance) {
        mask |= FaceRMin;
    }
    if (ur < 0.0 && std::abs(r - grid.r_edges[ir + 1]) <= tolerance) {
        mask |= FaceRMax;
    }
    if (uz > 0.0 && std::abs(z - grid.z_edges[iz]) <= tolerance) {
        mask |= FaceZMin;
    }
    if (uz < 0.0 && std::abs(z - grid.z_edges[iz + 1]) <= tolerance) {
        mask |= FaceZMax;
    }
    return mask;
}

struct SwitchState {
    Status status = Status::OK;
    double eps_reconstructed = 0.0;
    double eps_for_test = 0.0;
    double grad_r = 0.0;
    double grad_z = 0.0;
    double grad_norm = 0.0;
    double normal_r = 0.0;
    double normal_z = 0.0;
    double mu = 0.0;
    double mu_round = 0.0;
    double criterion = -1.0;
    bool used_incident_epsilon = false;
    bool normal_reliable = false;
    bool required = false;
    bool do_switch = false;
};

double minimum_reconstructed_eps_on_segment(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double dtau) {
    const std::size_t idx = flatten(ir, iz, grid.nz);
    const double gr = transport_grad_r[idx];
    const double gz = transport_grad_z[idx];
    const double eps_start = reconstruct_eps_real(
        grid, eps, transport_grad_r, transport_grad_z, ir, iz, r, z);
    const double linear = gr * vr + gz * vz;
    const double quadratic = 0.25 * (gr * gr + gz * gz);
    const auto value_at = [&](double tau) {
        return eps_start + linear * tau + quadratic * tau * tau;
    };
    double minimum = std::min(eps_start, value_at(dtau));
    if (quadratic > 0.0) {
        const double vertex = -linear / (2.0 * quadratic);
        if (vertex > 0.0 && vertex < dtau) {
            minimum = std::min(minimum, value_at(vertex));
        }
    }
    return minimum;
}

bool face_enters_nonpropagating_cell(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    std::size_t ir,
    std::size_t iz,
    const CellEvent& event) {
    int next_ir = 0;
    int next_iz = 0;
    bool axis = false;
    advance_cell_after_event(
        grid, ir, iz, event.face_mask, next_ir, next_iz, axis);
    if (axis || next_ir < 0 || next_ir >= static_cast<int>(grid.nr) ||
        next_iz < 0 || next_iz >= static_cast<int>(grid.nz)) {
        return false;
    }
    const double next_eps = reconstruct_eps_real(
        grid,
        eps,
        transport_grad_r,
        transport_grad_z,
        static_cast<std::size_t>(next_ir),
        static_cast<std::size_t>(next_iz),
        event.r,
        event.z);
    return !std::isfinite(next_eps) || next_eps <= eps_real_min;
}

SwitchState evaluate_switch_state(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double wavelength_m,
    const TransportConfig& cfg,
    double entry_nr,
    double entry_nz,
    double incident_eps_r) {
    SwitchState state;
    state.eps_reconstructed = reconstruct_eps_real(
        grid, eps, transport_grad_r, transport_grad_z, ir, iz, r, z);
    state.eps_for_test = state.eps_reconstructed;
    if (state.eps_reconstructed <= eps_real_min) {
        if (incident_eps_r > eps_switch_floor && std::hypot(entry_nr, entry_nz) > 0.0) {
            state.eps_for_test = incident_eps_r;
            state.used_incident_epsilon = true;
        } else {
            state.status = Status::WoBadEntranceEps;
            return state;
        }
    }

    const std::size_t idx = flatten(ir, iz, grid.nz);
    state.grad_r = transport_grad_r[idx];
    state.grad_z = transport_grad_z[idx];
    state.grad_norm = std::hypot(state.grad_r, state.grad_z);
    const double h = std::min(grid.r_edges[ir + 1] - grid.r_edges[ir], grid.z_edges[iz + 1] - grid.z_edges[iz]);
    const double geometric_measure = state.grad_norm * h /
        std::max(1.0, std::abs(state.eps_for_test));
    if (std::isfinite(state.grad_norm) && geometric_measure >= gradient_direction_threshold) {
        state.normal_r = -state.grad_r / state.grad_norm;
        state.normal_z = -state.grad_z / state.grad_norm;
        state.normal_reliable = true;
    } else if (state.used_incident_epsilon) {
        const double entry_norm = std::hypot(entry_nr, entry_nz);
        if (entry_norm > 0.0) {
            state.normal_r = entry_nr / entry_norm;
            state.normal_z = entry_nz / entry_norm;
            state.normal_reliable = true;
        }
    }
    (void)geometric_grad_r;
    (void)geometric_grad_z;

    const double speed = std::hypot(vr, vz);
    if (speed <= 0.0) {
        state.status = Status::InvalidLaunch;
        return state;
    }
    const double u_r = vr / speed;
    const double u_z = vz / speed;
    if (state.normal_reliable) {
        state.mu = u_r * state.normal_r + u_z * state.normal_z;
        state.mu_round = 128.0 * std::numeric_limits<double>::epsilon() *
            (1.0 + std::abs(u_r * state.normal_r) +
             std::abs(u_z * state.normal_z));
    }
    state.criterion = 1.0 - state.eps_for_test +
        cfg.beta_gw * wavelength_m * state.grad_norm -
        cfg.alpha_gw * state.mu * state.mu - cfg.wo_switch_offset;
    if (!state.normal_reliable && !state.used_incident_epsilon) {
        const double lhs = 1.0 - state.eps_for_test +
            cfg.beta_gw * wavelength_m * state.grad_norm - cfg.wo_switch_offset;
        const double roundoff = 128.0 * std::numeric_limits<double>::epsilon() *
            (1.0 + std::abs(state.eps_for_test) +
             std::abs(cfg.beta_gw * wavelength_m * state.grad_norm));
        if (lhs <= roundoff || state.eps_reconstructed > eps_real_min) {
            return state;
        }
    }
    state.required = state.used_incident_epsilon || state.criterion >= 0.0;
    if (!state.required) {
        return state;
    }
    if (!state.normal_reliable) {
        state.status = Status::GrazingWo;
        return state;
    }
    if (state.mu > state.mu_round) {
        state.do_switch = true;
        return state;
    }
    if (state.mu < -state.mu_round) {
        return state;
    }
    // A roundoff-level tangent in a positive-epsilon cell is a geometric
    // contact, not a physical 90-degree WO incidence. GO may advance to the
    // next positive-length event. If the selected cell itself is nonpropagating,
    // there is no admissible GO continuation and the power remains unresolved.
    if (state.eps_reconstructed <= eps_real_min) {
        state.status = Status::GrazingWo;
    }
    return state;
}

struct TransitionAhead {
    bool found = false;
    double normal_r = 0.0;
    double normal_z = 0.0;
};

bool nonpropagating_cell_within_event_horizon(
    const GridRZ& grid,
    const Complex* eps,
    std::size_t ir,
    std::size_t iz,
    double vr,
    double vz,
    int maximum_events) {
    const int radial_direction = vr > direction_floor ? 1 :
        (vr < -direction_floor ? -1 : 0);
    const int axial_direction = vz > direction_floor ? 1 :
        (vz < -direction_floor ? -1 : 0);
    int ir_first = static_cast<int>(ir);
    int ir_last = static_cast<int>(ir);
    int iz_first = static_cast<int>(iz);
    int iz_last = static_cast<int>(iz);
    if (radial_direction > 0 ||
        (radial_direction < 0 && ir == 0)) {
        ir_last += maximum_events;
    } else if (radial_direction < 0) {
        ir_first -= maximum_events;
    }
    if (axial_direction > 0) {
        iz_last += maximum_events;
    } else if (axial_direction < 0) {
        iz_first -= maximum_events;
    }
    ir_first = std::max(0, ir_first);
    iz_first = std::max(0, iz_first);
    ir_last = std::min(static_cast<int>(grid.nr) - 1, ir_last);
    iz_last = std::min(static_cast<int>(grid.nz) - 1, iz_last);
    for (int scan_ir = ir_first; scan_ir <= ir_last; ++scan_ir) {
        for (int scan_iz = iz_first; scan_iz <= iz_last; ++scan_iz) {
            const double eps_center = eps[flatten(
                static_cast<std::size_t>(scan_ir),
                static_cast<std::size_t>(scan_iz),
                grid.nz)].real();
            if (!std::isfinite(eps_center) || eps_center <= eps_real_min) {
                return true;
            }
        }
    }
    return false;
}

TransitionAhead find_nonpropagating_transition_ahead(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    std::size_t start_ir,
    std::size_t start_iz,
    double start_r,
    double start_z,
    double start_vr,
    double start_vz,
    int start_entry_face_mask,
    double wavelength_m,
    const TransportConfig& cfg,
    int maximum_events) {
    TransitionAhead result;
    std::size_t ir = start_ir;
    std::size_t iz = start_iz;
    double r = start_r;
    double z = start_z;
    double vr = start_vr;
    double vz = start_vz;
    int entry_face_mask = start_entry_face_mask;
    for (int step = 0; step < maximum_events; ++step) {
        const std::size_t idx = flatten(ir, iz, grid.nz);
        const double gr = transport_grad_r[idx];
        const double gz = transport_grad_z[idx];
        const double eps_start = reconstruct_eps_real(
            grid, eps, transport_grad_r, transport_grad_z, ir, iz, r, z);
        if (!std::isfinite(eps_start) || eps_start <= eps_real_min) {
            return result;
        }
        const CellEvent event = next_go_cell_event(
            grid, ir, iz, r, z, vr, vz, gr, gz, entry_face_mask);
        if (event.status != Status::OK) {
            return result;
        }
        int next_ir = 0;
        int next_iz = 0;
        bool axis = false;
        advance_cell_after_event(
            grid, ir, iz, event.face_mask, next_ir, next_iz, axis);
        if (!axis && next_ir >= 0 && next_ir < static_cast<int>(grid.nr) &&
            next_iz >= 0 && next_iz < static_cast<int>(grid.nz) &&
            face_enters_nonpropagating_cell(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                ir,
                iz,
                event)) {
            double face_nr = 0.0;
            double face_nz = 0.0;
            entry_normal_from_face(event.face_mask, face_nr, face_nz);
            const SwitchState transition = evaluate_switch_state(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                geometric_grad_r,
                geometric_grad_z,
                static_cast<std::size_t>(next_ir),
                static_cast<std::size_t>(next_iz),
                event.r,
                event.z,
                event.vr,
                event.vz,
                wavelength_m,
                cfg,
                face_nr,
                face_nz,
                reconstruct_eps_real(
                    grid,
                    eps,
                    transport_grad_r,
                    transport_grad_z,
                    ir,
                    iz,
                    event.r,
                    event.z));
            if (transition.status == Status::OK &&
                transition.normal_reliable &&
                transition.mu > transition.mu_round) {
                result.found = true;
                result.normal_r = transition.normal_r;
                result.normal_z = transition.normal_z;
            }
            return result;
        }
        r = event.r;
        z = event.z;
        vr = event.vr;
        vz = event.vz;
        if (axis) {
            vr = -vr;
            ir = 0;
            entry_face_mask =
                (opposite_face_mask(event.face_mask) | FaceRMin) &
                (FaceRMin | FaceZMin | FaceZMax);
            if ((event.face_mask & (FaceZMin | FaceZMax)) == 0) continue;
            next_ir = 0;
        }
        if (next_ir < 0 || next_ir >= static_cast<int>(grid.nr) ||
            next_iz < 0 || next_iz >= static_cast<int>(grid.nz)) {
            return result;
        }
        ir = static_cast<std::size_t>(next_ir);
        iz = static_cast<std::size_t>(next_iz);
        entry_face_mask = opposite_face_mask(event.face_mask);
    }
    return result;
}

Status trace_wo_path(
    const GridRZ& grid,
    int start_ir,
    int start_iz,
    double r0,
    double z0,
    double dir_r0,
    double dir_z0,
    std::size_t cap,
    double* wo_len,
    int* wo_ir,
    int* wo_iz,
    std::size_t& count,
    int& axis_count) {
    int ir = start_ir;
    int iz = start_iz;
    double r = r0;
    double z = z0;
    double dir_r = dir_r0;
    double dir_z = dir_z0;
    count = 0;
    axis_count = 0;
    const int nr = static_cast<int>(grid.nr);
    const int nz = static_cast<int>(grid.nz);
    const double domain = std::max({
        std::abs(grid.r_edges.back() - grid.r_edges.front()),
        std::abs(grid.z_edges.back() - grid.z_edges.front()),
        std::abs(r),
        std::abs(z),
        std::numeric_limits<double>::min()});
    const double tol = std::max(128.0 * std::numeric_limits<double>::epsilon() * domain, 1.0e-14 * domain);
    if (ir < 0 || iz < 0 || ir >= nr || iz >= nz) {
        return Status::InvalidInput;
    }
    if (std::abs(r - grid.r_edges.front()) <= tol && dir_r < 0.0) {
        // The 1D WO construction also respects axisymmetry: a ray heading
        // through r = 0 is mirrored instead of leaving the computational domain.
        dir_r = -dir_r;
        ++axis_count;
    }
    while (true) {
        if (count >= cap) {
            return Status::WoProfileCapacity;
        }
        if (ir < 0 || iz < 0 || ir >= nr || iz >= nz) return Status::InvalidInput;
        const double r_lo = grid.r_edges[ir];
        const double r_hi = grid.r_edges[ir + 1];
        const double z_lo = grid.z_edges[iz];
        const double z_hi = grid.z_edges[iz + 1];
        if (!std::isfinite(r) || !std::isfinite(z) ||
            r < r_lo - tol || r > r_hi + tol ||
            z < z_lo - tol || z > z_hi + tol) return Status::InvalidInput;
        r = std::clamp(r, r_lo, r_hi);
        z = std::clamp(z, z_lo, z_hi);
        const double dr = (dir_r > 0.0) ? (grid.r_edges[ir + 1] - r) / dir_r :
                          (dir_r < 0.0) ? (grid.r_edges[ir] - r) / dir_r :
                          std::numeric_limits<double>::infinity();
        const double dz = (dir_z > 0.0) ? (grid.z_edges[iz + 1] - z) / dir_z :
                          (dir_z < 0.0) ? (grid.z_edges[iz] - z) / dir_z :
                          std::numeric_limits<double>::infinity();
        double dist = std::min(dr, dz);
        if (!std::isfinite(dist)) {
            return Status::InvalidInput;
        }
        if (dist < 0.0 && dist > -tol) {
            dist = 0.0;
        }
        if (dist < -tol) {
            return Status::InvalidInput;
        }
        const bool hit_r = dr <= dist + tol;
        const bool hit_z = dz <= dist + tol;
        if (dist > tol) {
            wo_ir[count] = ir;
            wo_iz[count] = iz;
            wo_len[count] = dist;
            ++count;
            r += dist * dir_r;
            z += dist * dir_z;
        }
        bool escaped = false;
        bool axis = false;
        if (hit_r) {
            if (dir_r < 0.0 && ir == 0 && std::abs(grid.r_edges.front()) <= tol) {
                dir_r = -dir_r;
                r = grid.r_edges.front();
                axis = true;
                ++axis_count;
            } else if (dir_r > 0.0 && ir == nr - 1) {
                escaped = true;
            } else if (dir_r > 0.0) {
                ++ir;
            } else {
                --ir;
            }
        }
        if (hit_z) {
            if (dir_z < 0.0 && iz == 0) {
                escaped = true;
            } else if (dir_z > 0.0 && iz == nz - 1) {
                escaped = true;
            } else if (dir_z > 0.0) {
                ++iz;
            } else {
                --iz;
            }
        }
        if (escaped) {
            return Status::OK;
        }
        if (axis) {
            continue;
        }
        if (ir < 0 || ir >= nr || iz < 0 || iz >= nz) {
            return Status::OK;
        }
    }
}

Status construct_wo_arrays(
    std::size_t layers,
    double eps_r_at_switch,
    const GridRZ& grid,
    const Complex* eps,
    const int* wo_ir,
    const int* wo_iz,
    const double* wo_len,
    double* bounds,
    Complex* eps_wo,
    WoExitMode exit_mode = WoExitMode::MatchLastLayer) {
    if (layers == 0) {
        return Status::WoProfileCapacity;
    }
    if (eps_r_at_switch <= eps_real_min) {
        return Status::WoBadEntranceEps;
    }
    bounds[0] = 0.0;
    bounds[1] = 0.0;
    eps_wo[0] = Complex(eps_r_at_switch, 0.0);
    for (std::size_t j = 0; j < layers; ++j) {
        bounds[j + 2] = bounds[j + 1] + wo_len[j];
        eps_wo[j + 1] = eps[flatten(static_cast<std::size_t>(wo_ir[j]), static_cast<std::size_t>(wo_iz[j]), grid.nz)];
    }
    bounds[layers + 2] = bounds[layers + 1];
    eps_wo[layers + 1] = exit_mode == WoExitMode::MatchLastLayer ? eps_wo[layers] : Complex(1.0, 0.0);
    return Status::OK;
}

Status compute_one_pol_profile(
    int polarization,
    double power_in,
    std::size_t layers,
    double* bounds,
    Complex* eps_wo,
    double theta,
    double wavelength_m,
    double* q_sec,
    double* q_osc,
    double* q_rescaled,
    double* q_profile,
    double* wo_result,
    double* rescale_result,
    Complex* solver_work,
    std::size_t solver_work_size,
    Diagnostics& diagnostics,
    double& reflected,
    double& escaped,
    double& absorbed,
    bool exact_interface_profile = false) {
    reflected = 0.0;
    escaped = 0.0;
    absorbed = 0.0;
    if (power_in <= 0.0) {
        return Status::OK;
    }
    for (std::size_t j = 0; j < layers + 2; ++j) {
        if (!std::isfinite(eps_wo[j].real()) || !std::isfinite(eps_wo[j].imag())) {
            return Status::WoSolverFailure;
        }
    }
    Status status = laser_absorption_components_inplace(layers, bounds, eps_wo, polarization, theta, wavelength_m, q_sec, q_osc, wo_result, solver_work, solver_work_size);
    if (status != Status::OK) {
        return Status::WoSolverFailure;
    }
    const double R = wo_result[WoResultR];
    const double T_raw = wo_result[WoResultTRaw];
    const double A_raw = wo_result[WoResultARaw];
    const double raw_accuracy = wo_result[WoResultAccuracyRaw];
    if (!std::isfinite(R) || !std::isfinite(T_raw) || !std::isfinite(A_raw)) {
        return Status::WoConservationFailure;
    }
    if (R < -wo_bounds_tol || R > 1.0 + wo_bounds_tol || T_raw < -wo_bounds_tol || T_raw > 1.0 + wo_bounds_tol ||
        A_raw < -wo_bounds_tol || A_raw > 1.0 + wo_bounds_tol) {
        return Status::WoConservationFailure;
    }
    double q_raw_sum = 0.0;
    for (std::size_t j = 0; j < layers; ++j) {
        const double q_raw = q_sec[j] + q_osc[j];
        if (!std::isfinite(q_raw)) {
            return Status::WoConservationFailure;
        }
        q_raw_sum += q_raw;
    }
    const double raw_residual = 1.0 - R - T_raw - q_raw_sum;
    const double raw_abs = std::max(std::abs(raw_residual), std::abs(raw_accuracy));
    diagnostics.max_wo_raw_residual = std::max(diagnostics.max_wo_raw_residual, raw_abs);
    if (raw_abs > wo_raw_warn_tol) {
        diagnostics.wo_conservation_warning_count += 1.0;
    }
    if (raw_abs > wo_raw_fail_tol) {
        return Status::WoConservationFailure;
    }
    if (exact_interface_profile) {
        // The discrete interface is a finite wave stack, not a secular hybrid
        // heating profile. Retain the full cell integral, including interference.
        // In particular, cancelling near-critical terms must not be discarded.
        if (raw_abs>1e-10 || R<0.0 || T_raw<0.0) return Status::WoConservationFailure;
        double committed_sum=0.0;
        for(std::size_t j=0;j<layers;++j) {
            q_profile[j]=q_sec[j]+q_osc[j];
            const double roundoff=64*std::numeric_limits<double>::epsilon()*std::max({1.0,std::abs(q_sec[j]),std::abs(q_osc[j])});
            if(q_profile[j]<-roundoff) return Status::WoConservationFailure;
            q_profile[j]=std::max(0.0,q_profile[j]);
            committed_sum+=q_profile[j];
        }
        const double final_error=std::abs(1-R-T_raw-committed_sum);
        if(final_error>1e-10) return Status::WoConservationFailure;
        diagnostics.max_wo_final_residual=std::max(diagnostics.max_wo_final_residual,std::max(raw_abs,final_error));
        diagnostics.max_wo_conservation_correction=std::max(diagnostics.max_wo_conservation_correction,std::abs(committed_sum-q_raw_sum));
        reflected=power_in*R; escaped=power_in*T_raw; absorbed=power_in*committed_sum;
        return Status::OK;
    }
    // The transfer matrix returns raw secular and oscillatory absorption.
    // Basko rescaling preserves the profile shape while enforcing R + T + A = 1
    // before any power is committed to the 2D grid.
    status = basko_rescale_absorption_inplace(layers, q_sec, q_osc, R, T_raw, q_rescaled, rescale_result);
    if (status != Status::OK) {
        return Status::WoRescalingFailure;
    }
    double A = 0.0;
    for (std::size_t j = 0; j < layers; ++j) {
        double q = q_rescaled[j];
        if (!std::isfinite(q) || q < -1.0e-12) {
            return Status::WoRescalingFailure;
        }
        if (q < 0.0) {
            q = 0.0;
        }
        q_profile[j] = q;
        A += q;
    }
    double escaped_fraction = rescale_result[RescaleResultT];
    const double rescaled_accuracy = rescale_result[RescaleResultAccuracy];
    if (!std::isfinite(escaped_fraction) || !std::isfinite(rescaled_accuracy) || escaped_fraction < -wo_bounds_tol) {
        return Status::WoConservationFailure;
    }
    if (escaped_fraction < 0.0) {
        escaped_fraction = 0.0;
    }
    const double final_residual = 1.0 - R - escaped_fraction - A;
    const double final_abs = std::max(std::abs(final_residual), std::abs(rescaled_accuracy));
    diagnostics.max_wo_final_residual = std::max(diagnostics.max_wo_final_residual, final_abs);
    if (final_abs > wo_final_fail_tol) {
        return Status::WoConservationFailure;
    }
    const double correction = final_residual;
    if (correction != 0.0) {
        const double corrected_escaped = escaped_fraction + correction;
        double applied = 0.0;
        if (corrected_escaped >= -wo_bounds_tol) {
            const double new_escaped = std::max(0.0, corrected_escaped);
            applied = new_escaped - escaped_fraction;
            escaped_fraction = new_escaped;
        } else {
            double remaining = correction + escaped_fraction;
            applied = -escaped_fraction;
            escaped_fraction = 0.0;
            if (remaining >= 0.0) {
                return Status::WoConservationFailure;
            }
            double need = -remaining;
            bool fixed = false;
            for (std::size_t jj = layers; jj > 0; --jj) {
                const std::size_t j = jj - 1;
                double q = q_profile[j];
                if (q >= need - wo_bounds_tol) {
                    double q_new = q - need;
                    if (q_new < 0.0) {
                        q_new = 0.0;
                    }
                    q_profile[j] = q_new;
                    A -= q - q_new;
                    applied += q_new - q;
                    fixed = true;
                    break;
                }
            }
            if (!fixed) {
                return Status::WoConservationFailure;
            }
        }
        diagnostics.max_wo_conservation_correction = std::max(diagnostics.max_wo_conservation_correction, std::abs(applied));
    }
    reflected = power_in * R;
    escaped = power_in * escaped_fraction;
    absorbed = power_in * A;
    return Status::OK;
}

double commit_wo_profiles(std::size_t layers, double power_s, double power_p, const double* q_s, const double* q_p, const int* wo_ir, const int* wo_iz, const GridRZ& grid, std::vector<double>& cell_power) {
    // Transactional WO commit: profiles for both polarizations are solved and
    // rescaled first. Only after every check succeeds is deposited power added
    // to the shared cell-power array in watts.
    double absorbed = 0.0;
    for (std::size_t j = 0; j < layers; ++j) {
        const double deposited = power_s * q_s[j] + power_p * q_p[j];
        if (deposited != 0.0) {
            const std::size_t idx = flatten(static_cast<std::size_t>(wo_ir[j]), static_cast<std::size_t>(wo_iz[j]), grid.nz);
            cell_power[idx] += deposited;
            absorbed += deposited;
        }
    }
    return absorbed;
}

double switch_function_at_state(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double wavelength_m,
    const TransportConfig& cfg,
    double entry_nr,
    double entry_nz,
    double incident_eps_r,
    double& eps_r) {
    const SwitchState state = evaluate_switch_state(
        grid,
        eps,
        transport_grad_r,
        transport_grad_z,
        geometric_grad_r,
        geometric_grad_z,
        ir,
        iz,
        r,
        z,
        vr,
        vz,
        wavelength_m,
        cfg,
        entry_nr,
        entry_nz,
        incident_eps_r);
    eps_r = state.eps_reconstructed;
    return state.criterion;
}

int find_internal_switch_tau(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    std::size_t ir,
    std::size_t iz,
    double r,
    double z,
    double vr,
    double vz,
    double gr,
    double gz,
    double dtau,
    double wavelength_m,
    const TransportConfig& cfg,
    double entry_nr,
    double entry_nz,
    double incident_eps_r,
    double roots[2],
    bool suppress_processed_event,
    double& switch_tau) {
    switch_tau = dtau;
    if (dtau <= 0.0) {
        return 0;
    }
    // A GO segment can cross the Basko criterion before it reaches a cell face.
    // First try the quadratic critical-density root, then bisect the full
    // switch function when gradient/angle terms control the crossing.
    const double eps_start = reconstruct_eps_real(
        grid, eps, transport_grad_r, transport_grad_z, ir, iz, r, z);
    double r_end = 0.0;
    double z_end = 0.0;
    double vr_end = 0.0;
    double vz_end = 0.0;
    parabolic_position(r, z, vr, vz, gr, gz, dtau, r_end, z_end);
    parabolic_velocity(vr, vz, gr, gz, dtau, vr_end, vz_end);
    const double eps_end = reconstruct_eps_real(
        grid, eps, transport_grad_r, transport_grad_z, ir, iz, r_end, z_end);
    const double target = std::max(eps_switch_floor, 128.0 * std::numeric_limits<double>::epsilon() * std::max(1.0, std::abs(eps_start)));

    const double eps_a = 0.25 * (gr * gr + gz * gz);
    const double eps_b = gr * vr + gz * vz;
    const double eps_c = eps_start - target;
    const int n_roots = positive_quadratic_roots(eps_a, eps_b, eps_c, roots, 0.0, 1.0e-300, 1.0e-14);
    double candidate = dtau;
    for (int k = 0; k < n_roots; ++k) {
        if (roots[k] > 0.0 && roots[k] < candidate) {
            candidate = roots[k];
        }
    }
    const int critical_kind = candidate < dtau ? 1 : 0;
    switch_tau = candidate;
    // For n=-g/|g| the incoming projection p decreases linearly. Before
    // p=0, epsilon decreases and mu^2 decreases, so physical F increases.
    // Search only this monotone interval; the outgoing part is not a new WO.
    const auto start = evaluate_switch_state(grid, eps, transport_grad_r, transport_grad_z,
        geometric_grad_r, geometric_grad_z, ir, iz, r, z, vr, vz, wavelength_m,
        cfg, entry_nr, entry_nz, incident_eps_r);
    if (start.status != Status::OK) return -1;
    if (suppress_processed_event || !start.normal_reliable || start.mu <= start.mu_round || start.grad_norm <= 0.0)
        return critical_kind;
    if (start.criterion >= 0.0) { switch_tau = 0.0; return 2; }
    const double turning_tau = -2.0 * (gr * vr + gz * vz) / (gr * gr + gz * gz);
    double lo = 0.0;
    double hi = std::min(candidate, turning_tau);
    auto physical_f = [&](double tau) {
        double rr, zz, vrr, vzz, dummy;
        parabolic_position(r,z,vr,vz,gr,gz,tau,rr,zz);
        parabolic_velocity(vr,vz,gr,gz,tau,vrr,vzz);
        return switch_function_at_state(grid,eps,transport_grad_r,transport_grad_z,
            geometric_grad_r,geometric_grad_z,ir,iz,rr,zz,vrr,vzz,wavelength_m,cfg,
            entry_nr,entry_nz,incident_eps_r,dummy);
    };
    const double fhi = physical_f(hi);
    if (!std::isfinite(fhi)) return -1;
    if (!(hi > 0.0) || fhi < 0.0) return critical_kind;
    for (int k = 0; k < 80; ++k) {
        const double mid = 0.5 * (lo + hi);
        const double fm = physical_f(mid);
        if (!std::isfinite(fm)) return -1;
        if (fm >= 0.0) {
            hi = mid;
        } else {
            lo = mid;
        }
        if (hi - lo <= 1.0e-12 * std::max(std::abs(dtau), std::numeric_limits<double>::min())) {
            break;
        }
    }
    switch_tau = hi;
    (void)eps_end;
    return 2;
}

Status trace_single_ray_rz_impl(
    const GridRZ& grid,
    const Complex* eps,
    const double* transport_grad_r,
    const double* transport_grad_z,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    double r0,
    double z0,
    double ur0,
    double uz0,
    double power_s0,
    double power_p0,
    double initial_power,
    double wavelength_m,
    const TransportConfig& cfg,
    std::vector<double>& cell_power,
    Diagnostics& diagnostics,
    WorkspaceSlices& w,
    std::size_t ray_index,
    const TransportTraceObserver* observer,
    AngularPower* angular = nullptr) {
    if (!angular && observer) angular = observer->angular;
    const std::size_t cap = max_wo_layers_for_mesh(grid.nr, grid.nz);
    const double norm = std::hypot(ur0, uz0);
    if (norm <= direction_floor || wavelength_m <= 0.0) {
        diagnostics.unresolved_power_w += initial_power;
        diagnostics.failed_rays += 1.0;
        return Status::InvalidLaunch;
    }
    const double ur = ur0 / norm;
    const double uz = uz0 / norm;
    std::size_t ir = 0;
    std::size_t iz = 0;
    if (!locate_cell_with_direction(grid, r0, z0, ur, uz, ir, iz)) {
        diagnostics.unresolved_power_w += initial_power;
        diagnostics.failed_rays += 1.0;
        return Status::InvalidLaunch;
    }
    const double eps_launch = reconstruct_eps_real(
        grid, eps, transport_grad_r, transport_grad_z, ir, iz, r0, z0);
    if (eps_launch <= eps_real_min) {
        diagnostics.unresolved_power_w += initial_power;
        diagnostics.failed_rays += 1.0;
        return Status::InvalidLaunch;
    }
    double r = r0;
    double z = z0;
    double speed = std::sqrt(eps_launch);
    // vr/vz are GO canonical velocities in ray parameter tau. Their squared
    // magnitude tracks Re(epsilon), which is checked after each parabolic step.
    double vr = speed * ur;
    double vz = speed * uz;
    double power_s = power_s0;
    double power_p = power_p0;
    const double k0 = two_pi / wavelength_m;
    int crossings = 0;
    int zero_transitions = 0;
    int wo_events = 0;
    bool check_switch = true;
    bool suppress_processed_event = false;
    bool force_transition_wo = false;
    bool exact_face_wo = false;
    bool force_normal_override = false;
    double forced_normal_r = 0.0;
    double forced_normal_z = 0.0;
    double entry_nr = 0.0;
    double entry_nz = 0.0;
    launch_entry_normal(grid, r, z, ur, uz, entry_nr, entry_nz);
    int entry_face_mask = launch_entry_face_mask(grid, r, z, ur, uz);
    double incident_eps_for_switch = eps_launch;
    Status status_result = Status::OK;
    double previous_r = r, previous_z = z;
    int active_normal_source = 0;
    bool active_exact_profile = false;
    std::size_t active_wo_layers = 0;
    double pending_face_eps_plus = 0.0;
    auto emit_trace = [&](const TransportTraceObserver* target, TransportTraceEvent e) {
        if (!target || !target->callback) return;
        e.power_s_w=power_s; e.power_p_w=power_p;
        const auto j = flatten(e.ir,e.iz,grid.nz);
        e.transport_grad_r = transport_grad_r[j]; e.transport_grad_z = transport_grad_z[j];
        e.geometric_grad_r = geometric_grad_r[j]; e.geometric_grad_z = geometric_grad_z[j];
        e.canonical_speed_squared = vr*vr+vz*vz;
        const double gn=std::hypot(transport_grad_r[j],transport_grad_z[j]);
        if(std::hypot(e.normal_r,e.normal_z)==0 && gn>0) {
            e.normal_r=-transport_grad_r[j]/gn; e.normal_z=-transport_grad_z[j]/gn;
        }
        if(std::hypot(vr,vz)>0) e.mu=(vr*e.normal_r+vz*e.normal_z)/std::hypot(vr,vz);
        e.criterion = 1-e.eps_reconstructed + cfg.beta_gw*wavelength_m*std::hypot(transport_grad_r[j],transport_grad_z[j])-cfg.alpha_gw*e.mu*e.mu-cfg.wo_switch_offset;
        e.eps_minus = incident_eps_for_switch;
        e.eps_plus = reconstruct_eps_real(grid,eps,transport_grad_r,transport_grad_z,e.ir,e.iz,e.r,e.z);
        e.processed_event_suppressed = suppress_processed_event;
        e.normal_source = std::hypot(e.normal_r,e.normal_z)==0 ? 0 : (force_normal_override ? 2 : 1);
        if(e.kind==TransportTraceEventKind::WoComplete || e.kind==TransportTraceEventKind::ReflectedGo) {
            e.normal_source=active_normal_source;
            e.exact_interface_profile=active_exact_profile;
            e.wo_layer_count=active_wo_layers;
            if(active_exact_profile) e.eps_plus=pending_face_eps_plus;
            e.eps_wo_first_real=w.eps_wo[1].real(); e.eps_wo_first_imag=w.eps_wo[1].imag();
        }
        if(e.kind==TransportTraceEventKind::GoSegmentEnd) {
            e.segment_distance=std::hypot(e.r-previous_r,e.z-previous_z);
            previous_r=e.r; previous_z=e.z;
        }
        target->callback(e,target->user_data);
    };
    emit_trace(observer, {
        TransportTraceEventKind::Launch,
        ray_index,
        ir,
        iz,
        r,
        z,
        ur,
        uz,
        initial_power,
        eps_launch,
        eps[flatten(ir, iz, grid.nz)].real(),
        0.0,
        0.0,
        0.0,
        0.0,
        wo_events,
        Status::OK});

    while (true) {
        double total_power = power_s + power_p;
        if (total_power <= 0.0) {
            return status_result;
        }
        if (cfg.min_relative_power > 0.0 && total_power <= initial_power * cfg.min_relative_power) {
            diagnostics.cutoff_power_w += total_power;
            return status_result;
        }
        if (crossings >= cfg.max_cell_crossings) {
            diagnostics.unresolved_power_w += total_power;
            diagnostics.failed_rays += 1.0;
            return Status::MaxCellCrossings;
        }
        const std::size_t idx = flatten(ir, iz, grid.nz);
        double eps_i = eps[idx].imag();
        if (eps_i < -negative_imag_tol) {
            diagnostics.unresolved_power_w += total_power;
            diagnostics.failed_rays += 1.0;
            return Status::NegativeEpsImag;
        }
        if (eps_i < 0.0) {
            eps_i = 0.0;
        }

        // On a sharp cell-centred interface the limiter intentionally makes
        // the incident plateau constant. Inspect a bounded local path before
        // committing it and carry the normal of the actual blocked transition
        // back to the earliest uncommitted admissible point. Smooth profiles
        // retain their ordinary Basko switch/root handling.
        constexpr int transition_event_horizon = 4;
        if (check_switch && !force_transition_wo &&
            std::hypot(transport_grad_r[idx], transport_grad_z[idx]) <=
                grad_min &&
            nonpropagating_cell_within_event_horizon(
                grid,
                eps,
                ir,
                iz,
                vr,
                vz,
                transition_event_horizon)) {
            const TransitionAhead transition =
                find_nonpropagating_transition_ahead(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                geometric_grad_r,
                geometric_grad_z,
                ir,
                iz,
                r,
                z,
                vr,
                vz,
                entry_face_mask,
                wavelength_m,
                cfg,
                transition_event_horizon);
            if (transition.found) {
                force_transition_wo = true;
                force_normal_override = true;
                forced_normal_r = transition.normal_r;
                forced_normal_z = transition.normal_z;
            }
        }

        if (check_switch || force_transition_wo) {
            SwitchState switch_state = evaluate_switch_state(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                geometric_grad_r,
                geometric_grad_z,
                ir,
                iz,
                r,
                z,
                vr,
                vz,
                wavelength_m,
                cfg,
                entry_nr,
                entry_nz,
                incident_eps_for_switch);
            if (force_transition_wo && switch_state.status == Status::OK) {
                if (force_normal_override) {
                    switch_state.normal_r = forced_normal_r;
                    switch_state.normal_z = forced_normal_z;
                    switch_state.normal_reliable = true;
                    const double speed_now = std::hypot(vr, vz);
                    const double u_r_now = vr / speed_now;
                    const double u_z_now = vz / speed_now;
                    switch_state.mu =
                        u_r_now * forced_normal_r + u_z_now * forced_normal_z;
                    switch_state.mu_round =
                        128.0 * std::numeric_limits<double>::epsilon() *
                        (1.0 + std::abs(u_r_now * forced_normal_r) +
                         std::abs(u_z_now * forced_normal_z));
                }
                switch_state.required = true;
                if (switch_state.eps_reconstructed <= eps_real_min) {
                    switch_state.status = Status::WoBadEntranceEps;
                } else if (!switch_state.normal_reliable ||
                           switch_state.mu <= switch_state.mu_round) {
                    switch_state.status = Status::GrazingWo;
                } else {
                    switch_state.eps_for_test =
                        switch_state.eps_reconstructed;
                    switch_state.used_incident_epsilon = false;
                    switch_state.do_switch = true;
                }
            }
            Status st = switch_state.status;
            if (switch_state.required || st != Status::OK) {
                emit_trace(observer, {
                    TransportTraceEventKind::WoSwitch,
                    ray_index,
                    ir,
                    iz,
                    r,
                    z,
                    vr / std::max(std::hypot(vr, vz), direction_floor),
                    vz / std::max(std::hypot(vr, vz), direction_floor),
                    total_power,
                    switch_state.eps_reconstructed,
                    eps[idx].real(),
                    switch_state.normal_r,
                    switch_state.normal_z,
                    switch_state.mu,
                    0.0,
                    wo_events,
                    st});
            }
            if (st != Status::OK) {
                diagnostics.unresolved_power_w += total_power;
                diagnostics.failed_rays += 1.0;
                emit_trace(observer, {
                    TransportTraceEventKind::Failure,
                    ray_index,
                    ir,
                    iz,
                    r,
                    z,
                    0.0,
                    0.0,
                    total_power,
                    switch_state.eps_reconstructed,
                    eps[idx].real(),
                    switch_state.normal_r,
                    switch_state.normal_z,
                    switch_state.mu,
                    0.0,
                    wo_events,
                    st});
                return st;
            }
            if (switch_state.do_switch) {
                const bool exact_profile = exact_face_wo || !cfg.basko_rescaling_enabled;
                active_exact_profile=exact_face_wo;
                exact_face_wo = false;
                active_normal_source=force_normal_override ? 2 : 1;
                force_transition_wo = false;
                force_normal_override = false;
                const double n_r = switch_state.normal_r;
                const double n_z = switch_state.normal_z;
                const double cos_theta = switch_state.mu;
                const double eps_r_switch = switch_state.eps_for_test;
                if (cfg.max_wo_events_per_ray == 0) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return Status::WoDisabledRequired;
                }
                if (wo_events >= cfg.max_wo_events_per_ray) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return Status::WoEventLimit;
                }
                // From the switch point, launch the WO auxiliary ray along the
                // constructed normal until it leaves the computational domain.
                // The resulting cell sequence is the 1D multilayer stack.
                std::size_t layers = 0;
                int axis_count = 0;
                st = trace_wo_path(grid, static_cast<int>(ir), static_cast<int>(iz), r, z, n_r, n_z, cap, w.wo_len, w.wo_ir, w.wo_iz, layers, axis_count);
                if (st != Status::OK) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return st;
                }
                st = construct_wo_arrays(layers, eps_r_switch, grid, eps, w.wo_ir, w.wo_iz, w.wo_len, w.bounds, w.eps_wo, cfg.wo_exit_mode);
                active_wo_layers=layers;
                if (st != Status::OK) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return st;
                }
                const double theta = std::acos(std::max(-1.0, std::min(1.0, cos_theta)));
                for (std::size_t j = 0; j < layers; ++j) {
                    w.q_profile_s[j] = 0.0;
                    w.q_profile_p[j] = 0.0;
                }
                double ref_s = 0.0, esc_s = 0.0, abs_s = 0.0;
                double ref_p = 0.0, esc_p = 0.0, abs_p = 0.0;
                st = compute_one_pol_profile(1, power_s, layers, w.bounds, w.eps_wo, theta, wavelength_m, w.q_sec, w.q_osc, w.q_rescaled, w.q_profile_s, w.wo_result, w.rescale_result, w.solver_work, w.solver_work_size, diagnostics, ref_s, esc_s, abs_s, exact_profile);
                if (st != Status::OK) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return st;
                }
                st = compute_one_pol_profile(2, power_p, layers, w.bounds, w.eps_wo, theta, wavelength_m, w.q_sec, w.q_osc, w.q_rescaled, w.q_profile_p, w.wo_result, w.rescale_result, w.solver_work, w.solver_work_size, diagnostics, ref_p, esc_p, abs_p, exact_profile);
                if (st != Status::OK) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return st;
                }
                const double absorbed_commit = commit_wo_profiles(layers, power_s, power_p, w.q_profile_s, w.q_profile_p, w.wo_ir, w.wo_iz, grid, cell_power);
                diagnostics.absorbed_wo_w += absorbed_commit;
                diagnostics.escaped_wo_w += esc_s + esc_p;
                if (angular && esc_s+esc_p>0) {
                    const double vin=std::hypot(vr,vz);
                    const double kr=std::sqrt(w.eps_wo[0].real())*(vr/vin-cos_theta*n_r);
                    const double kz=std::sqrt(w.eps_wo[0].real())*(vz/vin-cos_theta*n_z);
                    const Complex exit_eps(w.eps_wo[layers+1].real(),std::max(0.0,w.eps_wo[layers+1].imag()));
                    Complex qn=std::sqrt(exit_eps-Complex(kr*kr+kz*kz,0));
                    if(qn.imag()<0 || (qn.imag()==0 && qn.real()<0)) qn=-qn;
                    double length=0;
                    for(std::size_t j=0;j<layers;++j) length+=w.wo_len[j];
                    // TE: S parallel Re(k); TM: S parallel Re(k/epsilon).
                    // The two polarizations can have different energy-flow angles.
                    for(int pol=1;pol<=2;++pol) {
                        double normal_flux=0,tangent_factor=0;
                        if(pol==1) { normal_flux=qn.real(); tangent_factor=1; }
                        else if(std::abs(exit_eps)>0) { normal_flux=(qn/exit_eps).real(); tangent_factor=(1.0/exit_eps).real(); }
                        double out_r=0,out_z=0;
                        if(normal_flux>0) { out_r=tangent_factor*kr+normal_flux*n_r;out_z=tangent_factor*kz+normal_flux*n_z; }
                        if(axis_count%2) out_r=-out_r;
                        angular->record({angular->laser_index,true,std::abs(r+n_r*length),z+n_z*length,out_r,out_z,pol==2?esc_p:0,pol==1?esc_s:0});
                    }
                }
                diagnostics.wo_events += 1.0;
                diagnostics.wo_layers += static_cast<double>(layers);
                diagnostics.axis_crossings += static_cast<double>(axis_count);
                diagnostics.reflected_power_generated_w += ref_s + ref_p;
                ++wo_events;
                double wo_path_length = 0.0;
                for (std::size_t j = 0; j < layers; ++j) {
                    wo_path_length += w.wo_len[j];
                }
                emit_trace(observer, {
                    TransportTraceEventKind::WoComplete,
                    ray_index,
                    ir,
                    iz,
                    r,
                    z,
                    n_r,
                    n_z,
                    total_power,
                    eps_r_switch,
                    eps[idx].real(),
                    n_r,
                    n_z,
                    cos_theta,
                    wo_path_length,
                    wo_events,
                    Status::OK});
                power_s = ref_s;
                power_p = ref_p;
                total_power = power_s + power_p;
                if (total_power <= 0.0) {
                    return status_result;
                }
                // Reflected WO power returns to GO. Continue from the same
                // point with specular reflection about the WO normal.
                const double speed_in = std::hypot(vr, vz);
                const double u_r = vr / speed_in;
                const double u_z = vz / speed_in;
                const double dot = u_r * n_r + u_z * n_z;
                double u_ref_r = u_r - 2.0 * dot * n_r;
                double u_ref_z = u_z - 2.0 * dot * n_z;
                const double ref_norm = std::hypot(u_ref_r, u_ref_z);
                if (ref_norm <= 0.0) {
                    diagnostics.unresolved_power_w += total_power;
                    diagnostics.failed_rays += 1.0;
                    return Status::NonfiniteValue;
                }
                u_ref_r /= ref_norm;
                u_ref_z /= ref_norm;
                const double speed_ref = std::sqrt(eps_r_switch);
                vr = speed_ref * u_ref_r;
                vz = speed_ref * u_ref_z;
                emit_trace(observer, {
                    TransportTraceEventKind::ReflectedGo,
                    ray_index,
                    ir,
                    iz,
                    r,
                    z,
                    u_ref_r,
                    u_ref_z,
                    total_power,
                    eps_r_switch,
                    eps[idx].real(),
                    n_r,
                    n_z,
                    cos_theta,
                    0.0,
                    wo_events,
                    Status::OK});
                const std::size_t wo_ir = ir, wo_iz = iz;
                if (!locate_cell_with_direction(grid, r, z, u_ref_r, u_ref_z, ir, iz)) {
                    diagnostics.escaped_go_w += total_power;
                    if(angular) angular->record({angular->laser_index,false,r,z,vr,vz,power_p,power_s});
                    emit_trace(observer, {
                        TransportTraceEventKind::Escape,
                        ray_index,
                        ir,
                        iz,
                        r,
                        z,
                        u_ref_r,
                        u_ref_z,
                        total_power,
                        eps_r_switch,
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        0.0,
                        wo_events,
                        Status::OK});
                    return status_result;
                }
                // A WO point may lie exactly on a numerical cell face. Its
                // reflected momentum belongs to the WO incident medium, not
                // automatically to the direction-selected neighbouring cell.
                if (ir != wo_ir || iz != wo_iz) {
                    const std::size_t dest_ir = ir, dest_iz = iz;
                    ir = wo_ir; iz = wo_iz;
                    auto enter_reflected_cell = [&](bool radial, std::size_t ri, std::size_t zi) {
                        const double ep = reconstruct_eps_real(grid,eps,transport_grad_r,transport_grad_z,ri,zi,r,z);
                        const double tangent = radial ? vz : vr;
                        const double normal2 = ep - tangent*tangent;
                        if (!std::isfinite(ep) || ep <= eps_real_min || normal2 < 0.0) return false;
                        double& normal = radial ? vr : vz;
                        normal = std::copysign(std::sqrt(normal2),normal);
                        ir=ri; iz=zi;
                        return true;
                    };
                    if ((dest_ir != ir && !enter_reflected_cell(true,dest_ir,iz)) ||
                        (dest_iz != iz && !enter_reflected_cell(false,ir,dest_iz))) {
                        diagnostics.unresolved_power_w += total_power;
                        diagnostics.failed_rays += 1.0;
                        return Status::WoBadEntranceEps;
                    }
                    u_ref_r = vr/std::hypot(vr,vz);
                    u_ref_z = vz/std::hypot(vr,vz);
                    emit_trace(observer,{TransportTraceEventKind::FaceCoupling,ray_index,ir,iz,r,z,
                        u_ref_r,u_ref_z,total_power,
                        reconstruct_eps_real(grid,eps,transport_grad_r,transport_grad_z,ir,iz,r,z),
                        eps[flatten(ir,iz,grid.nz)].real(),0,0,0,0,wo_events,Status::OK});
                }
                // The reflected ray has already consumed the WO event at O.
                // A duplicate switch test is suppressed at this exact point,
                // but the independent GO-admissibility guard below still runs
                // before any positive-length segment can deposit power.
                check_switch = false;
                suppress_processed_event = true;
                entry_nr = n_r;
                entry_nz = n_z;
                entry_face_mask = entry_face_mask_for_cell(
                    grid, ir, iz, r, z, u_ref_r, u_ref_z);
                incident_eps_for_switch = eps_r_switch;
                continue;
            }
        }

        check_switch = false;
        const std::size_t idx_now = flatten(ir, iz, grid.nz);
        const double gr = transport_grad_r[idx_now];
        const double gz = transport_grad_z[idx_now];
        CellEvent event = next_go_cell_event(grid, ir, iz, r, z, vr, vz, gr, gz, entry_face_mask);
        if (event.status != Status::OK) {
            diagnostics.unresolved_power_w += total_power;
            diagnostics.failed_rays += 1.0;
            return event.status;
        }
        double dtau = event.tau;
        int face_mask = event.face_mask;
        double r_new = event.r;
        double z_new = event.z;
        double vr_new = event.vr;
        double vz_new = event.vz;

        double switch_dtau = dtau;
        const int root_kind = find_internal_switch_tau(
            grid,
            eps,
            transport_grad_r,
            transport_grad_z,
            geometric_grad_r,
            geometric_grad_z,
            ir,
            iz,
            r,
            z,
            vr,
            vz,
            gr,
            gz,
            dtau,
            wavelength_m,
            cfg,
            entry_nr,
            entry_nz,
            incident_eps_for_switch,
            w.roots,
            suppress_processed_event,
            switch_dtau);
        if (root_kind < 0) {
            diagnostics.unresolved_power_w += total_power;
            diagnostics.failed_rays += 1.0;
            return Status::NonfiniteValue;
        }
        const bool internal_switch = root_kind != 0 && switch_dtau < dtau;
        if (!internal_switch && face_enters_nonpropagating_cell(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                ir,
                iz,
                event)) {
            const double eps_start = reconstruct_eps_real(
                grid,
                eps,
                transport_grad_r,
                transport_grad_z,
                ir,
                iz,
                r,
                z);
            if (!std::isfinite(eps_start) || eps_start <= eps_real_min) {
                diagnostics.unresolved_power_w += total_power;
                diagnostics.failed_rays += 1.0;
                emit_trace(observer, {
                    TransportTraceEventKind::Failure,
                    ray_index,
                    ir,
                    iz,
                    r,
                    z,
                    vr / std::max(std::hypot(vr, vz), direction_floor),
                    vz / std::max(std::hypot(vr, vz), direction_floor),
                    total_power,
                    eps_start,
                    eps[idx_now].real(),
                    0.0,
                    0.0,
                    0.0,
                    0.0,
                    wo_events,
                    Status::WoBadEntranceEps});
                return Status::WoBadEntranceEps;
            }
            // Replace the as-yet uncommitted final admissible GO segment by
            // the incident part of the ordinary WO stack. This keeps O on the
            // incoming real branch and makes the reflected branch return to
            // that same side instead of starting inside an opaque cell.
            force_transition_wo = true;
            force_normal_override = false;
            check_switch = true;
            incident_eps_for_switch = eps_start;
            continue;
        }
        if (internal_switch) {
            dtau = switch_dtau;
            parabolic_position(r, z, vr, vz, gr, gz, dtau, r_new, z_new);
            parabolic_velocity(vr, vz, gr, gz, dtau, vr_new, vz_new);
            face_mask = 0;
        }

        const double minimum_eps = minimum_reconstructed_eps_on_segment(
            grid,
            eps,
            transport_grad_r,
            transport_grad_z,
            ir,
            iz,
            r,
            z,
            vr,
            vz,
            dtau);
        if (!std::isfinite(minimum_eps) || minimum_eps <= eps_real_min) {
            diagnostics.unresolved_power_w += total_power;
            diagnostics.failed_rays += 1.0;
            emit_trace(observer, {
                TransportTraceEventKind::Failure,
                ray_index,
                ir,
                iz,
                r,
                z,
                vr / std::max(std::hypot(vr, vz), direction_floor),
                vz / std::max(std::hypot(vr, vz), direction_floor),
                total_power,
                minimum_eps,
                eps[idx_now].real(),
                0.0,
                0.0,
                0.0,
                0.0,
                wo_events,
                Status::WoBadEntranceEps});
            return Status::WoBadEntranceEps;
        }

        const double progress_scale=std::max({std::abs(r),std::abs(z),
            grid.r_edges[ir+1]-grid.r_edges[ir],grid.z_edges[iz+1]-grid.z_edges[iz]});
        const double displacement=std::hypot(r_new-r,z_new-z);
        if(displacement<=128*std::numeric_limits<double>::epsilon()*progress_scale) {
            if(++zero_transitions>8) {
                diagnostics.unresolved_power_w+=total_power;
                diagnostics.failed_rays+=1;
                return Status::NoValidCellEvent;
            }
        } else zero_transitions=0;

        // GO collisional absorption is integrated exactly over the tau segment:
        // dP/dtau = -k0 Im(epsilon) P, deposited power is in watts per cell.
        const double optical_depth = k0 * eps_i * dtau;
        if (optical_depth != 0.0) {
            const double attenuation = std::exp(-optical_depth);
            const double deposited = -total_power * std::expm1(-optical_depth);
            power_s *= attenuation;
            power_p *= attenuation;
            cell_power[idx_now] += deposited;
            diagnostics.absorbed_go_w += deposited;
            diagnostics.exponentials += 1.0;
        }
        diagnostics.go_segments += 1.0;

        const double eps_r_end = reconstruct_eps_real(
            grid, eps, transport_grad_r, transport_grad_z, ir, iz, r_new, z_new);
        const double eikonal_rel = std::abs((vr_new * vr_new + vz_new * vz_new) - eps_r_end) / std::max(std::abs(eps_r_end), eps_switch_floor);
        diagnostics.max_eikonal_error = std::max(diagnostics.max_eikonal_error, eikonal_rel);
        if (eikonal_rel > eikonal_rel_warn) {
            diagnostics.eikonal_error_count += 1.0;
        }
        r = r_new;
        z = z_new;
        vr = vr_new;
        vz = vz_new;
        ++crossings;
        emit_trace(observer, {
            TransportTraceEventKind::GoSegmentEnd,
            ray_index,
            ir,
            iz,
            r,
            z,
            vr / std::max(std::hypot(vr, vz), direction_floor),
            vz / std::max(std::hypot(vr, vz), direction_floor),
            power_s + power_p,
            eps_r_end,
            eps[idx_now].real(),
            0.0,
            0.0,
            0.0,
            0.0,
            wo_events,
            Status::OK});

        if (internal_switch) {
            check_switch = true;
            entry_face_mask = 0;
            incident_eps_for_switch = reconstruct_eps_real(
                grid, eps, transport_grad_r, transport_grad_z, ir, iz, r, z);
            continue;
        }

        const std::size_t old_ir = ir;
        const std::size_t old_iz = iz;
        entry_normal_from_face(face_mask, entry_nr, entry_nz);
        incident_eps_for_switch = eps_r_end;
        int next_ir = 0;
        int next_iz = 0;
        bool axis = false;
        advance_cell_after_event(grid, ir, iz, face_mask, next_ir, next_iz, axis);
        const int next_entry_face_mask = opposite_face_mask(face_mask);

        if (axis) {
            // r = 0 reflection keeps the ray in the physical half-plane while
            // preserving the axisymmetric trajectory.
            r = grid.r_edges.front();
            vr = -vr;
            ir = 0;
            diagnostics.axis_crossings += 1.0;
            check_switch = false;
            entry_face_mask = (next_entry_face_mask | FaceRMin) & (FaceRMin | FaceZMin | FaceZMax);
            if ((face_mask & FaceZMin) != 0 && old_iz == 0) {
                diagnostics.escaped_go_w += power_s + power_p;
                if(angular) angular->record({angular->laser_index,false,r,z,vr,vz,power_p,power_s});
                return status_result;
            }
            if ((face_mask & FaceZMax) != 0 && old_iz + 1 == grid.nz) {
                diagnostics.escaped_go_w += power_s + power_p;
                if(angular) angular->record({angular->laser_index,false,r,z,vr,vz,power_p,power_s});
                return status_result;
            }
            if ((face_mask & (FaceZMin | FaceZMax)) == 0) continue;
            next_ir = 0;
        }

        if (next_ir < 0 || next_ir >= static_cast<int>(grid.nr) || next_iz < 0 || next_iz >= static_cast<int>(grid.nz)) {
            diagnostics.escaped_go_w += power_s + power_p;
            if(angular) angular->record({angular->laser_index,false,r,z,vr,vz,power_p,power_s});
            return status_result;
        }
        // Piecewise linear optical cells: tangential canonical momentum is
        // continuous, normal momentum obeys dispersion on the destination side.
        // A numerical reconstruction jump does not add Fresnel power splitting.
        // Simultaneous corners use the fixed radial-then-axial limit.
        bool interface_wo = false;
        auto couple_face = [&](bool radial, std::size_t dest_ir, std::size_t dest_iz) {
            const double eps_plus = reconstruct_eps_real(grid,eps,transport_grad_r,
                transport_grad_z,dest_ir,dest_iz,r,z);
            if (!std::isfinite(eps_plus) || eps_plus <= eps_real_min) return false;
            const double tangent = radial ? vz : vr;
            double& normal = radial ? vr : vz;
            const double normal_squared = eps_plus - tangent*tangent;
            const auto from = flatten(ir,iz,grid.nz);
            const auto to = flatten(dest_ir,dest_iz,grid.nz);
            const double eps_minus = reconstruct_eps_real(grid,eps,transport_grad_r,
                transport_grad_z,ir,iz,r,z);
            const double roundoff = 128.0*std::numeric_limits<double>::epsilon()*
                std::max({std::abs(eps_plus),tangent*tangent,std::abs(eps_minus)});
            // A P0 step with an already-required transmitted Basko state is
            // handled by the same wave problem on both sides of q_n=0. Smooth
            // reconstruction jumps with an admissible GO branch keep Snell
            // matching; they do not acquire automatic Fresnel splitting.
            const bool constant_step = eps_plus != eps_minus &&
                std::hypot(transport_grad_r[from],transport_grad_z[from])<=grad_min &&
                std::hypot(transport_grad_r[to],transport_grad_z[to])<=grad_min;
            const double transmitted_F = 1.0-eps_plus-cfg.alpha_gw*normal_squared/eps_plus-cfg.wo_switch_offset;
            if (normal_squared<=roundoff || (constant_step && transmitted_F>=0.0)) {
                interface_wo = true;
                exact_face_wo = true;
                force_transition_wo = true;
                force_normal_override = true;
                forced_normal_r = radial ? std::copysign(1.0,normal) : 0.0;
                forced_normal_z = radial ? 0.0 : std::copysign(1.0,normal);
                incident_eps_for_switch = eps_minus;
                pending_face_eps_plus = eps_plus;
                check_switch = true;
                return true;
            }
            normal = std::copysign(std::sqrt(normal_squared),normal);
            ir = dest_ir;
            iz = dest_iz;
            return true;
        };
        bool face_ok = true;
        if (!axis && next_ir != static_cast<int>(ir))
            face_ok = couple_face(true,static_cast<std::size_t>(next_ir),iz);
        if (face_ok && !interface_wo && next_iz != static_cast<int>(iz))
            face_ok = couple_face(false,ir,static_cast<std::size_t>(next_iz));
        if (!face_ok) {
            diagnostics.unresolved_power_w += power_s+power_p;
            diagnostics.failed_rays += 1.0;
            return Status::WoBadEntranceEps;
        }
        if (interface_wo) continue;
        entry_face_mask = entry_face_mask_for_cell(grid,ir,iz,r,z,vr,vz);
        // Only a resolved material-cell exit rearms the processed event.
        const double position_scale = std::max({std::abs(r),std::abs(z),
            grid.r_edges[old_ir+1]-grid.r_edges[old_ir],grid.z_edges[old_iz+1]-grid.z_edges[old_iz]});
        if (dtau * std::hypot(vr,vz) > 128.0 * std::numeric_limits<double>::epsilon() * position_scale)
            suppress_processed_event = false;
        check_switch = !suppress_processed_event;
        emit_trace(observer,{TransportTraceEventKind::FaceCoupling,ray_index,ir,iz,r,z,
            vr/std::hypot(vr,vz),vz/std::hypot(vr,vz),power_s+power_p,
            reconstruct_eps_real(grid,eps,transport_grad_r,transport_grad_z,ir,iz,r,z),
            eps[flatten(ir,iz,grid.nz)].real(),0,0,0,0,wo_events,Status::OK});
        (void)old_ir;
    }
}

Status trace_single_ray_rz_inplace(
    const GridRZ& grid, const Complex* eps, const double* tgr, const double* tgz,
    const double* ggr, const double* ggz, double r, double z, double ur, double uz,
    double ps, double pp, double initial, double wavelength, const TransportConfig& cfg,
    std::vector<double>& deposition, Diagnostics& d, WorkspaceSlices& w,
    std::size_t ray_index, const TransportTraceObserver* observer, AngularPower* angular = nullptr) {
    if(!angular && observer) angular=observer->angular;
    struct Forward {
        const TransportTraceObserver* target;
        TransportTraceEvent last;
        static void callback(const TransportTraceEvent& e, void* p) {
            auto& self=*static_cast<Forward*>(p); self.last=e;
            self.target->callback(e,self.target->user_data);
        }
    } forward{observer,{}};
    TransportTraceObserver proxy{Forward::callback,&forward};
    const double unresolved_before=d.unresolved_power_w,cutoff_before=d.cutoff_power_w;
    const Status st=trace_single_ray_rz_impl(grid,eps,tgr,tgz,ggr,ggz,r,z,ur,uz,ps,pp,initial,
        wavelength,cfg,deposition,d,w,ray_index,observer && observer->callback ? &proxy : nullptr,angular);
    const double unresolved=d.unresolved_power_w-unresolved_before;
    const double cutoff=d.cutoff_power_w-cutoff_before;
    if(unresolved>0) ++d.unresolved_rays;
    if(cutoff>0) ++d.cutoff_rays;
    if(observer && observer->callback) {
        auto terminal=forward.last; terminal.kind=TransportTraceEventKind::Terminal;
        terminal.ray_index=ray_index; terminal.status=st;
        terminal.power_w=unresolved+cutoff;
        observer->callback(terminal,observer->user_data);
    }
    return st;
}

bool finite_arrays(
    const Complex* epsilon,
    const double* grad_r,
    const double* grad_z,
    const double* r0,
    const double* z0,
    const double* ur0,
    const double* uz0,
    const double* power,
    const double* pfrac,
    std::size_t cells,
    std::size_t rays) {
    for (std::size_t i = 0; i < cells; ++i) {
        if (!std::isfinite(epsilon[i].real()) || !std::isfinite(epsilon[i].imag()) ||
            !std::isfinite(grad_r[i]) || !std::isfinite(grad_z[i])) {
            return false;
        }
    }
    for (std::size_t i = 0; i < rays; ++i) {
        if (!std::isfinite(r0[i]) || !std::isfinite(z0[i]) || !std::isfinite(ur0[i]) ||
            !std::isfinite(uz0[i]) || !std::isfinite(power[i]) || !std::isfinite(pfrac[i])) {
            return false;
        }
    }
    return true;
}

} // namespace

std::size_t max_wo_layers_for_mesh(std::size_t nr, std::size_t nz) {
    return 2 * (nr + nz) + 8;
}

std::size_t required_float_workspace(std::size_t nr, std::size_t nz) {
    const std::size_t cap = max_wo_layers_for_mesh(nr, nz);
    return 2 * nr * nz + 2 + cap + (cap + 3) + 5 * cap +
        NumWoResult + NumRescaleResult;
}

std::size_t required_complex_workspace(std::size_t nr, std::size_t nz) {
    const std::size_t cap = max_wo_layers_for_mesh(nr, nz);
    return cap + 2 + required_wo_complex_workspace(cap);
}

std::size_t required_int_workspace(std::size_t nr, std::size_t nz) {
    const std::size_t cap = max_wo_layers_for_mesh(nr, nz);
    return 2 * cap;
}

static Status trace_laser_batch_rz_inplace_impl(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* grad_eps_r,
    const double* grad_eps_z,
    const double* ray_r0,
    const double* ray_z0,
    const double* ray_ur0,
    const double* ray_uz0,
    const double* ray_power0,
    const double* ray_p_fraction,
    std::size_t n_rays,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    int* ray_status,
    int* ray_wo_events,
    double* ray_unresolved_power,
    double* ray_cutoff_power,
    bool reset_diagnostics,
    RayTransportOutcome* ray_outcomes,
    const TransportTraceObserver* observer) {
    if (reset_diagnostics) {
        diagnostics.clear();
    }
    const std::size_t cells = grid.nr * grid.nz;
    if (grid.nr == 0 || grid.nz == 0 || epsilon == nullptr || grad_eps_r == nullptr || grad_eps_z == nullptr ||
        ray_r0 == nullptr || ray_z0 == nullptr || ray_ur0 == nullptr || ray_uz0 == nullptr || ray_power0 == nullptr ||
        ray_p_fraction == nullptr || work_float == nullptr || work_complex == nullptr || work_int == nullptr ||
        cell_power_w.size() != cells || work_float_size < required_float_workspace(grid.nr, grid.nz) ||
        work_complex_size < required_complex_workspace(grid.nr, grid.nz) || work_int_size < required_int_workspace(grid.nr, grid.nz) ||
        !(wavelength_m > 0.0) || !(config.alpha_gw > 0.0 && config.alpha_gw < 1.0) ||
        !std::isfinite(config.wo_switch_offset) || config.wo_switch_offset<0 ||
        (config.wo_exit_mode!=WoExitMode::LegacyVacuum && config.wo_exit_mode!=WoExitMode::MatchLastLayer) ||
        config.beta_gw < 0.0 || config.max_wo_events_per_ray < 0 || config.min_relative_power < 0.0 ||
        config.min_relative_power >= 1.0 || config.max_cell_crossings <= 0) {
        diagnostics.record_status(Status::InvalidInput);
        return Status::InvalidInput;
    }
    if (!finite_arrays(epsilon, grad_eps_r, grad_eps_z, ray_r0, ray_z0, ray_ur0, ray_uz0, ray_power0, ray_p_fraction, cells, n_rays)) {
        diagnostics.record_status(Status::InvalidInput);
        return Status::InvalidInput;
    }
    for (std::size_t idx = 0; idx < cells; ++idx) {
        if (epsilon[idx].imag() < -negative_imag_tol) {
            diagnostics.record_status(Status::InvalidInput);
            return Status::InvalidInput;
        }
        if (!std::isfinite(cell_power_w[idx])) {
            diagnostics.record_status(Status::InvalidInput);
            return Status::InvalidInput;
        }
    }

    double* transport_grad_r = work_float;
    double* transport_grad_z = work_float + cells;
    apply_scalar_limiter(
        grid,
        epsilon,
        grad_eps_r,
        grad_eps_z,
        transport_grad_r,
        transport_grad_z);
    WorkspaceSlices slices = workspace_slices(
        cells,
        max_wo_layers_for_mesh(grid.nr, grid.nz),
        work_float,
        work_complex,
        work_int);
    Status batch_status = Status::OK;
    for (std::size_t m = 0; m < n_rays; ++m) {
        if (ray_outcomes != nullptr) {
            ray_outcomes[m] = RayTransportOutcome{};
        }
        if (ray_status != nullptr) {
            ray_status[m] = status_value(Status::OK);
        }
        if (ray_wo_events != nullptr) {
            ray_wo_events[m] = 0;
        }
        if (ray_unresolved_power != nullptr) {
            ray_unresolved_power[m] = 0.0;
        }
        if (ray_cutoff_power != nullptr) {
            ray_cutoff_power[m] = 0.0;
        }
        const double power0 = ray_power0[m];
        const double pfrac = ray_p_fraction[m];
        if (power0 < 0.0) {
            diagnostics.failed_rays += 1.0;
            set_batch_status(diagnostics, Status::InvalidInput);
            if (batch_status == Status::OK) {
                batch_status = Status::InvalidInput;
            }
            if (ray_status != nullptr) {
                ray_status[m] = status_value(Status::InvalidInput);
            }
            if (ray_outcomes != nullptr) {
                ray_outcomes[m].status = status_value(Status::InvalidInput);
            }
            continue;
        }
        if (power0 == 0.0) {
            continue;
        }
        diagnostics.input_power_w += power0;
        diagnostics.total_rays += 1;
        if (pfrac < 0.0 || pfrac > 1.0) {
            diagnostics.failed_rays += 1.0;
            diagnostics.unresolved_power_w += power0;
            ++diagnostics.unresolved_rays;
            set_batch_status(diagnostics, Status::InvalidInput);
            if (batch_status == Status::OK) {
                batch_status = Status::InvalidInput;
            }
            if (ray_status != nullptr) {
                ray_status[m] = status_value(Status::InvalidInput);
            }
            if (ray_unresolved_power != nullptr) {
                ray_unresolved_power[m] = power0;
            }
            if (ray_outcomes != nullptr) {
                ray_outcomes[m].status = status_value(Status::InvalidInput);
                ray_outcomes[m].unresolved_w = power0;
            }
            continue;
        }
        const double power_p = power0 * pfrac;
        const double power_s = power0 - power_p;
        const double wo_before = diagnostics.wo_events;
        const double unresolved_before = diagnostics.unresolved_power_w;
        const double cutoff_before = diagnostics.cutoff_power_w;
        const double absorbed_go_before = diagnostics.absorbed_go_w;
        const double absorbed_wo_before = diagnostics.absorbed_wo_w;
        const double escaped_go_before = diagnostics.escaped_go_w;
        const double escaped_wo_before = diagnostics.escaped_wo_w;
        Status st = trace_single_ray_rz_inplace(
            grid,
            epsilon,
            transport_grad_r,
            transport_grad_z,
            grad_eps_r,
            grad_eps_z,
            ray_r0[m],
            ray_z0[m],
            ray_ur0[m],
            ray_uz0[m],
            power_s,
            power_p,
            power0,
            wavelength_m,
            config,
            cell_power_w,
            diagnostics,
            slices,
            m,
            observer);
        if (st != Status::OK) {
            if (batch_status == Status::OK) {
                batch_status = st;
            }
            set_batch_status(diagnostics, st);
        }
        if (ray_status != nullptr) {
            ray_status[m] = status_value(st);
        }
        if (ray_wo_events != nullptr) {
            ray_wo_events[m] = static_cast<int>(diagnostics.wo_events - wo_before);
        }
        if (ray_unresolved_power != nullptr) {
            ray_unresolved_power[m] = diagnostics.unresolved_power_w - unresolved_before;
        }
        if (ray_cutoff_power != nullptr) {
            ray_cutoff_power[m] = diagnostics.cutoff_power_w - cutoff_before;
        }
        if (ray_outcomes != nullptr) {
            RayTransportOutcome& outcome = ray_outcomes[m];
            outcome.status = status_value(st);
            outcome.wo_events = static_cast<int>(
                diagnostics.wo_events - wo_before);
            outcome.absorbed_go_w =
                diagnostics.absorbed_go_w - absorbed_go_before;
            outcome.absorbed_wo_w =
                diagnostics.absorbed_wo_w - absorbed_wo_before;
            outcome.escaped_go_w =
                diagnostics.escaped_go_w - escaped_go_before;
            outcome.escaped_wo_w =
                diagnostics.escaped_wo_w - escaped_wo_before;
            outcome.unresolved_w =
                diagnostics.unresolved_power_w - unresolved_before;
            outcome.cutoff_w = diagnostics.cutoff_power_w - cutoff_before;
        }
    }
    diagnostics.finish();
    return batch_status;
}

Status trace_laser_batch_rz_inplace(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* grad_eps_r,
    const double* grad_eps_z,
    const double* ray_r0,
    const double* ray_z0,
    const double* ray_ur0,
    const double* ray_uz0,
    const double* ray_power0,
    const double* ray_p_fraction,
    std::size_t n_rays,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    int* ray_status,
    int* ray_wo_events,
    double* ray_unresolved_power,
    double* ray_cutoff_power,
    bool reset_diagnostics) {
    return trace_laser_batch_rz_inplace_impl(
        grid,
        epsilon,
        grad_eps_r,
        grad_eps_z,
        ray_r0,
        ray_z0,
        ray_ur0,
        ray_uz0,
        ray_power0,
        ray_p_fraction,
        n_rays,
        wavelength_m,
        config,
        cell_power_w,
        diagnostics,
        work_float,
        work_float_size,
        work_complex,
        work_complex_size,
        work_int,
        work_int_size,
        ray_status,
        ray_wo_events,
        ray_unresolved_power,
        ray_cutoff_power,
        reset_diagnostics,
        nullptr,
        nullptr);
}

Status trace_laser_batch_rz_inplace_debug(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* grad_eps_r,
    const double* grad_eps_z,
    const double* ray_r0,
    const double* ray_z0,
    const double* ray_ur0,
    const double* ray_uz0,
    const double* ray_power0,
    const double* ray_p_fraction,
    std::size_t n_rays,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    RayTransportOutcome* ray_outcomes,
    const TransportTraceObserver* observer,
    bool reset_diagnostics) {
    return trace_laser_batch_rz_inplace_impl(
        grid,
        epsilon,
        grad_eps_r,
        grad_eps_z,
        ray_r0,
        ray_z0,
        ray_ur0,
        ray_uz0,
        ray_power0,
        ray_p_fraction,
        n_rays,
        wavelength_m,
        config,
        cell_power_w,
        diagnostics,
        work_float,
        work_float_size,
        work_complex,
        work_complex_size,
        work_int,
        work_int_size,
        nullptr,
        nullptr,
        nullptr,
        nullptr,
        reset_diagnostics,
        ray_outcomes,
        observer);
}

Status trace_laser_batch_rz(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    double* ray_z0,
    double* ray_power,
    double* ray_p_fraction,
    int* ray_status,
    int* ray_wo_events,
    double* ray_unresolved_power,
    double* ray_cutoff_power,
    bool reset_diagnostics) {
    const std::size_t n = rays.launch_r.size();
    for (std::size_t i = 0; i < n; ++i) {
        ray_z0[i] = rays.launch_z;
        ray_power[i] = total_power_w * rays.power_weight[i];
        ray_p_fraction[i] = p_fraction;
    }
    return trace_laser_batch_rz_inplace(
        grid,
        fields.epsilon.data(),
        fields.grad_r.data(),
        fields.grad_z.data(),
        rays.launch_r.data(),
        ray_z0,
        rays.direction_r.data(),
        rays.direction_z.data(),
        ray_power,
        ray_p_fraction,
        n,
        wavelength_m,
        config,
        cell_power_w,
        diagnostics,
        work_float,
        work_float_size,
        work_complex,
        work_complex_size,
        work_int,
        work_int_size,
        ray_status,
        ray_wo_events,
        ray_unresolved_power,
        ray_cutoff_power,
        reset_diagnostics);
}

static Status trace_laser_bundle_rz_impl(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    const ParallelConfig& parallel,
    std::vector<TransportThreadWorkspace>* thread_workspace,
    bool validate_inputs,
    AngularPower* angular) {
    const std::size_t cells = grid.nr * grid.nz;
    if (validate_inputs && (cell_power_w.size() != cells || fields.epsilon.size() != cells ||
        fields.grad_r.size() != cells || fields.grad_z.size() != cells ||
        work_float_size < required_float_workspace(grid.nr, grid.nz) ||
        work_complex_size < required_complex_workspace(grid.nr, grid.nz) ||
        work_int_size < required_int_workspace(grid.nr, grid.nz) ||
        !(wavelength_m > 0.0) || p_fraction < 0.0 || p_fraction > 1.0 ||
        !std::isfinite(config.wo_switch_offset) || config.wo_switch_offset < 0.0 ||
        (config.wo_exit_mode != WoExitMode::LegacyVacuum && config.wo_exit_mode != WoExitMode::MatchLastLayer))) {
        diagnostics.record_status(Status::InvalidInput);
        return Status::InvalidInput;
    }

    const std::size_t n_rays = rays.launch_r.size();
    double* transport_grad_r = work_float;
    double* transport_grad_z = work_float + cells;
    apply_scalar_limiter(
        grid,
        fields.epsilon.data(),
        fields.grad_r.data(),
        fields.grad_z.data(),
        transport_grad_r,
        transport_grad_z);
#ifdef ICARUS_HAS_OPENMP
    int thread_count = 1;
    if (parallel.enabled) {
        thread_count = parallel.number_of_threads > 0 ? parallel.number_of_threads : omp_get_max_threads();
        if (thread_count < 1) {
            thread_count = 1;
        }
    }
    if (parallel.enabled && thread_workspace != nullptr && thread_workspace->size() >= static_cast<std::size_t>(thread_count)) {
        for (int t = 0; t < thread_count; ++t) {
            TransportThreadWorkspace& tw = (*thread_workspace)[static_cast<std::size_t>(t)];
            std::fill(tw.cell_power.begin(), tw.cell_power.end(), 0.0);
            tw.diagnostics.clear();
            if(angular) { tw.angular.clear(); tw.angular.laser_index=angular->laser_index; }
        }
        #pragma omp parallel num_threads(thread_count)
        {
            const int tid = omp_get_thread_num();
            TransportThreadWorkspace& tw = (*thread_workspace)[static_cast<std::size_t>(tid)];
            WorkspaceSlices local = workspace_slices(
                cells,
                max_wo_layers_for_mesh(grid.nr, grid.nz),
                tw.work_float.data(),
                tw.work_complex.data(),
                tw.work_int.data());
            #pragma omp for schedule(static)
            for (std::ptrdiff_t mm = 0; mm < static_cast<std::ptrdiff_t>(n_rays); ++mm) {
                const std::size_t m = static_cast<std::size_t>(mm);
                const double power0 = total_power_w * rays.power_weight[m];
                if (!(power0 > 0.0)) {
                    continue;
                }
                tw.diagnostics.input_power_w += power0;
                tw.diagnostics.total_rays += 1;
                const double power_p = power0 * p_fraction;
                const double power_s = power0 - power_p;
                const Status st = trace_single_ray_rz_inplace(
                    grid,
                    fields.epsilon.data(),
                    transport_grad_r,
                    transport_grad_z,
                    fields.grad_r.data(),
                    fields.grad_z.data(),
                    rays.launch_r[m],
                    rays.launch_z,
                    rays.direction_r[m],
                    rays.direction_z[m],
                    power_s,
                    power_p,
                    power0,
                    wavelength_m,
                    config,
                    tw.cell_power,
                    tw.diagnostics,
                    local,
                    m,
                    nullptr,
                    angular ? &tw.angular : nullptr);
                if (st != Status::OK) {
                    set_batch_status(tw.diagnostics, st);
                }
            }
        }
        // Deterministic OpenMP reduction: no atomics in the ray loop. Each
        // thread owns a full cell-power buffer and diagnostics object; the
        // final sum is always performed in increasing thread index order.
        Status batch_status = Status::OK;
        for (int t = 0; t < thread_count; ++t) {
            const TransportThreadWorkspace& tw = (*thread_workspace)[static_cast<std::size_t>(t)];
            for (std::size_t idx = 0; idx < cells; ++idx) {
                cell_power_w[idx] += tw.cell_power[idx];
            }
            if (batch_status == Status::OK && tw.diagnostics.first_error_status != Status::OK) {
                batch_status = tw.diagnostics.first_error_status;
            }
            diagnostics.add(tw.diagnostics);
            if(angular) angular->add(tw.angular);
        }
        diagnostics.effective_thread_count = thread_count;
        diagnostics.finish();
        return batch_status;
    }
#else
    (void)parallel;
    (void)thread_workspace;
#endif

    WorkspaceSlices slices = workspace_slices(
        cells,
        max_wo_layers_for_mesh(grid.nr, grid.nz),
        work_float,
        work_complex,
        work_int);
    Status batch_status = Status::OK;
    for (std::size_t m = 0; m < n_rays; ++m) {
        const double power0 = total_power_w * rays.power_weight[m];
        if (!(power0 > 0.0)) {
            continue;
        }
        diagnostics.input_power_w += power0;
        diagnostics.total_rays += 1;
        const double power_p = power0 * p_fraction;
        const double power_s = power0 - power_p;
        const Status st = trace_single_ray_rz_inplace(
            grid,
            fields.epsilon.data(),
            transport_grad_r,
            transport_grad_z,
            fields.grad_r.data(),
            fields.grad_z.data(),
            rays.launch_r[m],
            rays.launch_z,
            rays.direction_r[m],
            rays.direction_z[m],
            power_s,
            power_p,
            power0,
            wavelength_m,
            config,
            cell_power_w,
            diagnostics,
            slices,
            m,
            nullptr,
            angular);
        if (st != Status::OK) {
            if (batch_status == Status::OK) {
                batch_status = st;
            }
            set_batch_status(diagnostics, st);
        }
    }
    diagnostics.finish();
    diagnostics.effective_thread_count = std::max(diagnostics.effective_thread_count, 1);
    return batch_status;
}

Status trace_laser_bundle_rz_production(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    const ParallelConfig& parallel,
    std::vector<TransportThreadWorkspace>* thread_workspace,
    AngularPower* angular) {
    return trace_laser_bundle_rz_impl(
        grid,
        fields,
        rays,
        total_power_w,
        p_fraction,
        wavelength_m,
        config,
        cell_power_w,
        diagnostics,
        work_float,
        work_float_size,
        work_complex,
        work_complex_size,
        work_int,
        work_int_size,
        parallel,
        thread_workspace,
        true, angular);
}

Status trace_laser_bundle_rz_unchecked(
    const GridRZ& grid,
    const MixedFields& fields,
    const RayBundle& rays,
    double total_power_w,
    double p_fraction,
    double wavelength_m,
    const TransportConfig& config,
    std::vector<double>& cell_power_w,
    Diagnostics& diagnostics,
    double* work_float,
    std::size_t work_float_size,
    Complex* work_complex,
    std::size_t work_complex_size,
    int* work_int,
    std::size_t work_int_size,
    const ParallelConfig& parallel,
    std::vector<TransportThreadWorkspace>* thread_workspace,
    AngularPower* angular) {
    return trace_laser_bundle_rz_impl(
        grid,
        fields,
        rays,
        total_power_w,
        p_fraction,
        wavelength_m,
        config,
        cell_power_w,
        diagnostics,
        work_float,
        work_float_size,
        work_complex,
        work_complex_size,
        work_int,
        work_int_size,
        parallel,
        thread_workspace,
        false, angular);
}

} // namespace icarus
