#include "icarus/grid_rz.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace icarus {

namespace {

template <class Function>
void for_each_wls_point(
    const GridRZ& grid,
    std::size_t ir,
    std::size_t iz,
    const WlsCellGeometry& geometry,
    Function&& function) {
    const double hr = grid.r_edges[ir + 1] - grid.r_edges[ir];
    const double hz = grid.z_edges[iz + 1] - grid.z_edges[iz];
    const bool axis = std::abs(grid.r_edges.front()) <=
        128.0 * std::numeric_limits<double>::epsilon() *
        std::max(std::abs(grid.r_edges.back()), std::numeric_limits<double>::min());
    const int radial_radius = grid.nr > 1 ? geometry.radial_radius : 0;
    const int axial_radius = grid.nz > 1 ? geometry.axial_radius : 0;
    for (int di = -radial_radius; di <= radial_radius; ++di) {
        const int raw_ir = static_cast<int>(ir) + di;
        std::size_t sample_ir = 0;
        double sample_r = 0.0;
        bool mirrored = false;
        if (raw_ir < 0) {
            const int mirror_index = -raw_ir - 1;
            if (!axis || mirror_index >= static_cast<int>(grid.nr)) {
                continue;
            }
            sample_ir = static_cast<std::size_t>(mirror_index);
            sample_r = -grid.r_centers[sample_ir];
            mirrored = true;
        } else if (raw_ir >= static_cast<int>(grid.nr)) {
            continue;
        } else {
            sample_ir = static_cast<std::size_t>(raw_ir);
            sample_r = grid.r_centers[sample_ir];
        }
        for (int dj = -axial_radius; dj <= axial_radius; ++dj) {
            const int raw_iz = static_cast<int>(iz) + dj;
            if (raw_iz < 0 || raw_iz >= static_cast<int>(grid.nz)) {
                continue;
            }
            const std::size_t sample_iz = static_cast<std::size_t>(raw_iz);
            const double xi =
                (sample_r - grid.r_centers[ir]) /
                geometry.coordinate_scale;
            const double eta =
                (grid.z_centers[sample_iz] - grid.z_centers[iz]) /
                geometry.coordinate_scale;
            const double sample_hr =
                grid.r_edges[sample_ir + 1] - grid.r_edges[sample_ir];
            const double sample_hz =
                grid.z_edges[sample_iz + 1] - grid.z_edges[sample_iz];
            // This estimates a meridional gradient, so use dr*dz quadrature
            // rather than the cylindrical 2*pi*r volume measure.
            const double quadrature_weight =
                (sample_hr * sample_hz) / (hr * hz);
            const double weight = quadrature_weight /
                (1.0 + xi * xi + eta * eta);
            function(sample_ir, sample_iz, xi, eta, weight, mirrored);
        }
    }
}

int physical_index_radius(double support, double cell_width, int minimum) {
    constexpr int maximum_index_radius = 8;
    const double ratio = support / cell_width;
    const double roundoff = 128.0 * std::numeric_limits<double>::epsilon() *
        std::max(1.0, std::abs(ratio));
    const int requested = static_cast<int>(std::ceil(ratio - roundoff));
    return std::min(
        maximum_index_radius,
        std::max(minimum, requested));
}

bool invert_active_matrix(
    const std::array<double, 9>& matrix,
    const std::array<int, 3>& active,
    int count,
    std::array<double, 9>& inverse) {
    double augmented[3][6]{};
    double scale = 0.0;
    for (int row = 0; row < count; ++row) {
        for (int column = 0; column < count; ++column) {
            augmented[row][column] =
                matrix[static_cast<std::size_t>(3 * active[row] + active[column])];
            scale = std::max(scale, std::abs(augmented[row][column]));
        }
        augmented[row][count + row] = 1.0;
    }
    const double tolerance = 512.0 * std::numeric_limits<double>::epsilon() *
        std::max(scale, std::numeric_limits<double>::min());
    for (int column = 0; column < count; ++column) {
        int pivot = column;
        for (int row = column + 1; row < count; ++row) {
            if (std::abs(augmented[row][column]) >
                std::abs(augmented[pivot][column])) {
                pivot = row;
            }
        }
        if (std::abs(augmented[pivot][column]) <= tolerance) {
            return false;
        }
        if (pivot != column) {
            for (int entry = 0; entry < 2 * count; ++entry) {
                std::swap(augmented[pivot][entry], augmented[column][entry]);
            }
        }
        const double diagonal = augmented[column][column];
        for (int entry = 0; entry < 2 * count; ++entry) {
            augmented[column][entry] /= diagonal;
        }
        for (int row = 0; row < count; ++row) {
            if (row == column) {
                continue;
            }
            const double factor = augmented[row][column];
            for (int entry = 0; entry < 2 * count; ++entry) {
                augmented[row][entry] -= factor * augmented[column][entry];
            }
        }
    }
    inverse.fill(0.0);
    for (int row = 0; row < count; ++row) {
        for (int column = 0; column < count; ++column) {
            inverse[static_cast<std::size_t>(3 * active[row] + active[column])] =
                augmented[row][count + column];
        }
    }
    return true;
}

void build_wls_geometry(
    const GridRZ& grid,
    int radius,
    std::vector<WlsCellGeometry>& geometry) {
    geometry.assign(grid.nr * grid.nz, WlsCellGeometry{});
    std::array<int, 3> active{0, 1, 2};
    int active_count = 1;
    if (grid.nr > 1) {
        active[active_count++] = 1;
    }
    if (grid.nz > 1) {
        active[active_count++] = 2;
    }
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        for (std::size_t iz = 0; iz < grid.nz; ++iz) {
            WlsCellGeometry& cell = geometry[flatten(ir, iz, grid.nz)];
            const double hr = grid.r_edges[ir + 1] - grid.r_edges[ir];
            const double hz = grid.z_edges[iz + 1] - grid.z_edges[iz];
            cell.coordinate_scale = grid.nr > 1 && grid.nz > 1
                ? std::max(hr, hz)
                : (grid.nr > 1 ? hr : hz);
            const double aspect_ratio = grid.nr > 1 && grid.nz > 1
                ? cell.coordinate_scale / std::min(hr, hz)
                : 1.0;
            const double physical_radius = aspect_ratio > 1.0 +
                    128.0 * std::numeric_limits<double>::epsilon()
                ? 0.875 * static_cast<double>(radius)
                : static_cast<double>(radius);
            const double support =
                physical_radius * cell.coordinate_scale;
            cell.radial_radius = grid.nr > 1
                ? physical_index_radius(support, hr, radius) : 0;
            cell.axial_radius = grid.nz > 1
                ? physical_index_radius(support, hz, radius) : 0;
            cell.mirrored_radial_radius = grid.nr > 1 ? radius : 0;
            std::array<double, 9> matrix{};
            for_each_wls_point(
                grid,
                ir,
                iz,
                cell,
                [&](std::size_t, std::size_t, double xi, double eta,
                    double weight, bool) {
                    const double basis[3] = {1.0, xi, eta};
                    for (int row = 0; row < 3; ++row) {
                        for (int column = 0; column < 3; ++column) {
                            matrix[static_cast<std::size_t>(3 * row + column)] +=
                                weight * basis[row] * basis[column];
                        }
                    }
                });
            cell.valid = invert_active_matrix(
                matrix, active, active_count, cell.inverse);
        }
    }
}

struct CenterBracket {
    std::size_t low = 0;
    std::size_t high = 0;
    double fraction = 0.0;
    bool mirrored_low = false;
};

CenterBracket bracket_z(const std::vector<double>& centers, double value) {
    CenterBracket result;
    if (centers.size() <= 1 || value <= centers.front()) {
        return result;
    }
    if (value >= centers.back()) {
        result.low = result.high = centers.size() - 1;
        return result;
    }
    const auto upper = std::upper_bound(centers.begin(), centers.end(), value);
    result.high = static_cast<std::size_t>(upper - centers.begin());
    result.low = result.high - 1;
    result.fraction = (value - centers[result.low]) /
        (centers[result.high] - centers[result.low]);
    return result;
}

CenterBracket bracket_r(const GridRZ& grid, double value) {
    CenterBracket result;
    if (grid.r_centers.size() <= 1) {
        return result;
    }
    if (value < grid.r_centers.front()) {
        result.low = 0;
        result.high = 0;
        result.mirrored_low = true;
        const double left = -grid.r_centers.front();
        const double right = grid.r_centers.front();
        result.fraction = std::min(1.0, std::max(0.0,
            (value - left) / (right - left)));
        return result;
    }
    if (value >= grid.r_centers.back()) {
        result.low = result.high = grid.r_centers.size() - 1;
        return result;
    }
    const auto upper = std::upper_bound(
        grid.r_centers.begin(), grid.r_centers.end(), value);
    result.high = static_cast<std::size_t>(upper - grid.r_centers.begin());
    result.low = result.high - 1;
    result.fraction = (value - grid.r_centers[result.low]) /
        (grid.r_centers[result.high] - grid.r_centers[result.low]);
    return result;
}

} // namespace

static DerivativeStencil1D first_order_stencil(std::size_t i, const std::vector<double>& x) {
    DerivativeStencil1D s;
    if (x.size() == 1) {
        s.i0 = s.i1 = s.i2 = i;
        return s;
    }
    if (i == 0) {
        const double dx = x[1] - x[0];
        s.i0 = 0;
        s.i1 = 1;
        s.i2 = 1;
        s.c0 = -1.0 / dx;
        s.c1 = 1.0 / dx;
        return s;
    }
    const double dx = x[i] - x[i - 1];
    s.i0 = i - 1;
    s.i1 = i;
    s.i2 = i;
    s.c0 = -1.0 / dx;
    s.c1 = 1.0 / dx;
    return s;
}

static DerivativeStencil1D three_point_stencil(std::size_t target, std::size_t i0, std::size_t i1, std::size_t i2, const std::vector<double>& x) {
    const double xt = x[target];
    const double x0 = x[i0];
    const double x1 = x[i1];
    const double x2 = x[i2];
    DerivativeStencil1D s;
    s.i0 = i0;
    s.i1 = i1;
    s.i2 = i2;
    s.c0 = ((xt - x1) + (xt - x2)) / ((x0 - x1) * (x0 - x2));
    s.c1 = ((xt - x0) + (xt - x2)) / ((x1 - x0) * (x1 - x2));
    s.c2 = ((xt - x0) + (xt - x1)) / ((x2 - x0) * (x2 - x1));
    return s;
}

static void build_derivative_stencils(const std::vector<double>& centers, std::vector<DerivativeStencil1D>& stencils) {
    // Stencils are cached once at grid initialization. Each step only applies
    // coefficients to Re(epsilon), which keeps nonuniform-gradient evaluation
    // allocation-free and independent of host-provided gradients.
    const std::size_t n = centers.size();
    stencils.assign(n, DerivativeStencil1D{});
    if (n == 0) {
        return;
    }
    if (n == 1) {
        stencils[0].i0 = stencils[0].i1 = stencils[0].i2 = 0;
        return;
    }
    if (n == 2) {
        stencils[0] = first_order_stencil(0, centers);
        stencils[1] = first_order_stencil(1, centers);
        return;
    }
    for (std::size_t i = 0; i < n; ++i) {
        if (i == 0) {
            stencils[i] = three_point_stencil(i, 0, 1, 2, centers);
        } else if (i + 1 == n) {
            stencils[i] = three_point_stencil(i, n - 3, n - 2, n - 1, centers);
        } else {
            stencils[i] = three_point_stencil(i, i - 1, i, i + 1, centers);
        }
    }
}

static bool strictly_increasing(const std::vector<double>& x) {
    if (x.size() < 2) {
        return false;
    }
    for (std::size_t i = 0; i + 1 < x.size(); ++i) {
        if (!std::isfinite(x[i]) || !std::isfinite(x[i + 1]) || !(x[i + 1] > x[i])) {
            return false;
        }
    }
    return true;
}

bool initialize_grid(const std::vector<double>& r_edges, const std::vector<double>& z_edges, GridRZ& grid) {
    if (!strictly_increasing(r_edges) || !strictly_increasing(z_edges)) {
        return false;
    }
    if (r_edges.size() - 1 > static_cast<std::size_t>(std::numeric_limits<int>::max()) / (z_edges.size() - 1)) return false;
    const double scale = std::max(std::abs(r_edges.back() - r_edges.front()), std::numeric_limits<double>::min());
    if (std::abs(r_edges.front()) > 128.0 * std::numeric_limits<double>::epsilon() * scale) {
        return false;
    }
    grid.r_edges = r_edges;
    grid.z_edges = z_edges;
    grid.nr = r_edges.size() - 1;
    grid.nz = z_edges.size() - 1;
    grid.r_centers.assign(grid.nr, 0.0);
    grid.z_centers.assign(grid.nz, 0.0);
    grid.volume.assign(grid.nr * grid.nz, 0.0);
    grid.inverse_volume.assign(grid.nr * grid.nz, 0.0);
    // Flattened RZ arrays use idx = ir * nz + iz; z is contiguous so axial
    // sweeps and per-cell phase-source writes are cache-friendly.
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        grid.r_centers[ir] = 0.5 * (r_edges[ir] + r_edges[ir + 1]);
    }
    for (std::size_t iz = 0; iz < grid.nz; ++iz) {
        grid.z_centers[iz] = 0.5 * (z_edges[iz] + z_edges[iz + 1]);
    }
    build_derivative_stencils(grid.r_centers, grid.derivative_r);
    build_derivative_stencils(grid.z_centers, grid.derivative_z);
    build_wls_geometry(grid, 1, grid.wls_3x3);
    build_wls_geometry(grid, 2, grid.wls_5x5);
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        const double r0 = r_edges[ir];
        const double r1 = r_edges[ir + 1];
        for (std::size_t iz = 0; iz < grid.nz; ++iz) {
            const double dz = z_edges[iz + 1] - z_edges[iz];
            const double vol = pi * (r1 * r1 - r0 * r0) * dz;
            if (!(vol > 0.0) || !std::isfinite(vol)) {
                return false;
            }
            const std::size_t idx = flatten(ir, iz, grid.nz);
            grid.volume[idx] = vol;
            grid.inverse_volume[idx] = 1.0 / vol;
            if (!std::isfinite(grid.inverse_volume[idx])) return false;
        }
    }
    return true;
}

int locate_cell(const GridRZ& grid, double r, double z, std::size_t& ir, std::size_t& iz) {
    if (grid.nr == 0 || grid.nz == 0 || r < grid.r_edges.front() || r > grid.r_edges.back() ||
        z < grid.z_edges.front() || z > grid.z_edges.back()) {
        return 0;
    }
    auto ri = std::upper_bound(grid.r_edges.begin(), grid.r_edges.end(), r);
    auto zi = std::upper_bound(grid.z_edges.begin(), grid.z_edges.end(), z);
    if (ri == grid.r_edges.begin() || zi == grid.z_edges.begin()) {
        return 0;
    }
    ir = static_cast<std::size_t>((ri - grid.r_edges.begin()) - 1);
    iz = static_cast<std::size_t>((zi - grid.z_edges.begin()) - 1);
    if (ir == grid.nr) {
        ir = grid.nr - 1;
    }
    if (iz == grid.nz) {
        iz = grid.nz - 1;
    }
    return 1;
}

void apply_cached_gradient_stencils(const GridRZ& grid, const std::vector<Complex>& epsilon, std::vector<double>& grad_r, std::vector<double>& grad_z) {
    const std::size_t cells = grid.nr * grid.nz;
    if (grad_r.size() != cells) {
        grad_r.resize(cells);
    }
    if (grad_z.size() != cells) {
        grad_z.resize(cells);
    }
    apply_wls_gradient_stencils(
        grid, epsilon.data(), 2, grad_r.data(), grad_z.data());
}

void apply_wls_gradient_stencils(
    const GridRZ& grid,
    const Complex* epsilon,
    int radius,
    double* grad_r,
    double* grad_z) {
    const std::vector<WlsCellGeometry>& geometry =
        radius == 1 ? grid.wls_3x3 : grid.wls_5x5;
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        for (std::size_t iz = 0; iz < grid.nz; ++iz) {
            const std::size_t idx = flatten(ir, iz, grid.nz);
            const WlsCellGeometry& cell = geometry[idx];
            if (!cell.valid) {
                grad_r[idx] = 0.0;
                grad_z[idx] = 0.0;
                continue;
            }
            const double center = epsilon[idx].real();
            double rhs[3] = {0.0, 0.0, 0.0};
            for_each_wls_point(
                grid,
                ir,
                iz,
                cell,
                [&](std::size_t sample_ir, std::size_t sample_iz,
                    double xi, double eta, double weight, bool) {
                    const double difference =
                        epsilon[flatten(sample_ir, sample_iz, grid.nz)].real() -
                        center;
                    rhs[0] += weight * difference;
                    rhs[1] += weight * xi * difference;
                    rhs[2] += weight * eta * difference;
                });
            double coefficient[3] = {0.0, 0.0, 0.0};
            for (int row = 0; row < 3; ++row) {
                for (int column = 0; column < 3; ++column) {
                    coefficient[row] +=
                        cell.inverse[static_cast<std::size_t>(3 * row + column)] *
                        rhs[column];
                }
            }
            grad_r[idx] = grid.nr > 1
                ? coefficient[1] / cell.coordinate_scale : 0.0;
            grad_z[idx] = grid.nz > 1
                ? coefficient[2] / cell.coordinate_scale : 0.0;
        }
    }
}

void apply_scalar_limiter(
    const GridRZ& grid,
    const Complex* epsilon,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    double* transport_grad_r,
    double* transport_grad_z) {
    const double machine_epsilon = std::numeric_limits<double>::epsilon();
    for (std::size_t ir = 0; ir < grid.nr; ++ir) {
        for (std::size_t iz = 0; iz < grid.nz; ++iz) {
            const std::size_t idx = flatten(ir, iz, grid.nz);
            const double center = epsilon[idx].real();
            double minimum = center;
            double maximum = center;
            const WlsCellGeometry& geometry =
                grid.wls_5x5[flatten(ir, iz, grid.nz)];
            for_each_wls_point(
                grid,
                ir,
                iz,
                geometry,
                [&](std::size_t sample_ir, std::size_t sample_iz,
                    double, double, double, bool) {
                    const double value =
                        epsilon[flatten(sample_ir, sample_iz, grid.nz)].real();
                    minimum = std::min(minimum, value);
                    maximum = std::max(maximum, value);
                });
            const double gr = geometric_grad_r[idx];
            const double gz = geometric_grad_z[idx];
            const double scale = std::max({
                1.0, std::abs(center), std::abs(minimum), std::abs(maximum)});
            const double tolerance = 64.0 * machine_epsilon * scale;
            double phi = 1.0;
            for (int ri = 0; ri < 2; ++ri) {
                const double r_vertex = grid.r_edges[ir + static_cast<std::size_t>(ri)];
                for (int zi = 0; zi < 2; ++zi) {
                    const double z_vertex =
                        grid.z_edges[iz + static_cast<std::size_t>(zi)];
                    const double increment =
                        gr * (r_vertex - grid.r_centers[ir]) +
                        gz * (z_vertex - grid.z_centers[iz]);
                    if (increment > tolerance) {
                        phi = std::min(phi, (maximum - center) / increment);
                    } else if (increment < -tolerance) {
                        phi = std::min(phi, (minimum - center) / increment);
                    }
                }
            }
            phi = std::max(0.0, std::min(1.0, phi));
            transport_grad_r[idx] = phi * gr;
            transport_grad_z[idx] = phi * gz;
        }
    }
}

bool interpolate_geometric_gradient(
    const GridRZ& grid,
    const double* geometric_grad_r,
    const double* geometric_grad_z,
    double r,
    double z,
    double& grad_r,
    double& grad_z) {
    const CenterBracket radial = bracket_r(grid, r);
    const CenterBracket axial = bracket_z(grid.z_centers, z);
    grad_r = 0.0;
    grad_z = 0.0;
    for (int ri = 0; ri < 2; ++ri) {
        const std::size_t ir = ri == 0 ? radial.low : radial.high;
        const double radial_weight = ri == 0
            ? 1.0 - radial.fraction : radial.fraction;
        const double radial_sign =
            ri == 0 && radial.mirrored_low ? -1.0 : 1.0;
        for (int zi = 0; zi < 2; ++zi) {
            const std::size_t iz = zi == 0 ? axial.low : axial.high;
            const double axial_weight = zi == 0
                ? 1.0 - axial.fraction : axial.fraction;
            const double weight = radial_weight * axial_weight;
            const std::size_t idx = flatten(ir, iz, grid.nz);
            grad_r += weight * radial_sign * geometric_grad_r[idx];
            grad_z += weight * geometric_grad_z[idx];
        }
    }
    return std::isfinite(grad_r) && std::isfinite(grad_z) &&
        std::hypot(grad_r, grad_z) > grad_min;
}

} // namespace icarus
