#include "icarus/detail/pulse_profile.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <limits>

namespace icarus {

static double gaussian_cdf(double t, double center, double sigma) {
    return 0.5 * (1.0 + std::erf((t - center) / (std::sqrt(2.0) * sigma)));
}

static double triangular_integral_raw(double t, const TriangularPulseConfig& p) {
    if (t <= p.start_time_s || p.end_time_s <= p.start_time_s || p.peak_time_s <= p.start_time_s || p.end_time_s <= p.peak_time_s) {
        return 0.0;
    }
    if (t < p.peak_time_s) {
        const double x = t - p.start_time_s;
        return 0.5 * x * x / (p.peak_time_s - p.start_time_s);
    }
    const double left = 0.5 * (p.peak_time_s - p.start_time_s);
    if (t < p.end_time_s) {
        const double x = t - p.peak_time_s;
        return left + x - 0.5 * x * x / (p.end_time_s - p.peak_time_s);
    }
    return left + 0.5 * (p.end_time_s - p.peak_time_s);
}

static double interp_cumulative(const PulseProfile& pulse, double t) {
    if (pulse.table_t.empty()) {
        return 0.0;
    }
    if (t <= pulse.table_t.front()) {
        return 0.0;
    }
    if (t >= pulse.table_t.back()) {
        return pulse.table_cumulative.back();
    }
    const auto it = std::upper_bound(pulse.table_t.begin(), pulse.table_t.end(), t);
    const std::size_t i = static_cast<std::size_t>(it - pulse.table_t.begin() - 1);
    const double t0 = pulse.table_t[i];
    const double t1 = pulse.table_t[i + 1];
    const double p0 = pulse.table_p[i];
    const double p1 = pulse.table_p[i + 1];
    const double u = (t - t0) / (t1 - t0);
    const double pt = p0 + u * (p1 - p0);
    return pulse.table_cumulative[i] + 0.5 * (p0 + pt) * (t - t0);
}

bool PulseProfile::initialize_profile(const PulseShapeConfig& cfg) {
    config = cfg;
    table_t.clear();
    table_p.clear();
    table_cumulative.clear();
    table_integral = 0.0;
    if (std::holds_alternative<GaussianPulseConfig>(config)) {
        const auto& g = std::get<GaussianPulseConfig>(config);
        return std::isfinite(g.center_time_s) && std::isfinite(g.sigma_s) && g.sigma_s > 0.0;
    }
    if (std::holds_alternative<TriangularPulseConfig>(config)) {
        const auto& p = std::get<TriangularPulseConfig>(config);
        return std::isfinite(p.start_time_s) && std::isfinite(p.peak_time_s) &&
            std::isfinite(p.end_time_s) && p.start_time_s < p.peak_time_s && p.peak_time_s < p.end_time_s;
    }
    const auto& tab = std::get<TabulatedPulseConfig>(config);
    if (!std::isfinite(tab.time_shift_s) || !std::isfinite(tab.time_scale_to_s) || tab.time_scale_to_s <= 0) return false;
    std::ifstream in(tab.file_path);
    if (!in) {
        return false;
    }
    double t = 0.0;
    double p = 0.0;
    while (in >> t) {
        if (!(in >> p)) return false;
        t = tab.time_shift_s + tab.time_scale_to_s * t;
        if (!std::isfinite(t) || !std::isfinite(p) || p < 0.0) {
            return false;
        }
        if (!table_t.empty() && !(t > table_t.back())) {
            return false;
        }
        table_t.push_back(t);
        table_p.push_back(p);
    }
    if (!in.eof() || table_t.size() < 2) {
        return false;
    }
    table_cumulative.assign(table_t.size(), 0.0);
    for (std::size_t i = 1; i < table_t.size(); ++i) {
        const double dt = table_t[i] - table_t[i - 1];
        table_cumulative[i] = table_cumulative[i - 1] + 0.5 * (table_p[i - 1] + table_p[i]) * dt;
    }
    table_integral = table_cumulative.back();
    return std::isfinite(table_integral) && table_integral > 0.0;
}

double PulseProfile::full_step_energy_fraction(double t0, double dt) const {
    if (!(dt > 0.0)) {
        return 0.0;
    }
    const double t1 = t0 + dt;
    if (std::holds_alternative<GaussianPulseConfig>(config)) {
        const auto& g = std::get<GaussianPulseConfig>(config);
        const double a = (t0-g.center_time_s)/(std::sqrt(2.0)*g.sigma_s);
        const double b = (t1-g.center_time_s)/(std::sqrt(2.0)*g.sigma_s);
        if (a >= 0) return std::max(0.0, 0.5*(std::erfc(a)-std::erfc(b)));
        if (b <= 0) return std::max(0.0, 0.5*(std::erfc(-b)-std::erfc(-a)));
        return std::max(0.0, gaussian_cdf(t1, g.center_time_s, g.sigma_s) - gaussian_cdf(t0, g.center_time_s, g.sigma_s));
    }
    if (std::holds_alternative<TriangularPulseConfig>(config)) {
        const auto& p = std::get<TriangularPulseConfig>(config);
        const double norm = triangular_integral_raw(p.end_time_s, p);
        if (!(norm > 0.0)) {
            return 0.0;
        }
        return std::max(0.0, (triangular_integral_raw(t1, p) - triangular_integral_raw(t0, p)) / norm);
    }
    if (!(table_integral > 0.0)) {
        return 0.0;
    }
    return std::max(0.0, (interp_cumulative(*this, t1) - interp_cumulative(*this, t0)) / table_integral);
}

double PulseProfile::quantile(double f) const {
    if (std::holds_alternative<TriangularPulseConfig>(config)) {
        const auto& p = std::get<TriangularPulseConfig>(config);
        const double width = p.end_time_s-p.start_time_s;
        const double left = p.peak_time_s-p.start_time_s;
        if (f <= left/width) return p.start_time_s+std::sqrt(f*width*left);
        return p.end_time_s-std::sqrt((1-f)*width*(p.end_time_s-p.peak_time_s));
    }
    if (f <= 0) return table_t.front();
    if (f >= 1) return table_t.back();
    const double target=f*table_integral;
    auto it=std::lower_bound(table_cumulative.begin(),table_cumulative.end(),target);
    const std::size_t hi=static_cast<std::size_t>(it-table_cumulative.begin());
    if (hi==0) return table_t.front();
    const std::size_t i=hi-1;
    // Invert the actual quadratic integral, not a line through CDF nodes.
    double a=table_t[i], b=table_t[hi];
    for(int k=0;k<80;++k) {
        const double mid=a+(b-a)*0.5;
        if(interp_cumulative(*this,mid)<target) a=mid; else b=mid;
    }
    return a+(b-a)*0.5;
}

bool PulseProfile::initialize(const PulseShapeConfig& cfg, double q) {
    if (!std::isfinite(q) || q<0 || q>=0.5 || !initialize_profile(cfg)) return false;
    tail_fraction=q;
    if (std::holds_alternative<GaussianPulseConfig>(config)) {
        const auto& g=std::get<GaussianPulseConfig>(config);
        if(q==0) { t_on=-std::numeric_limits<double>::infinity(); t_off=-t_on; return true; }
        double a=0,b=40;
        for(int i=0;i<100;++i) {
            const double mid=(a+b)*0.5;
            if(std::erfc(mid/std::sqrt(2.0))>2*q) a=mid; else b=mid;
        }
        const double k=(a+b)*0.5;
        t_on=g.center_time_s-k*g.sigma_s; t_off=g.center_time_s+k*g.sigma_s;
    } else { t_on=quantile(q); t_off=quantile(1-q); }
    return std::isfinite(t_on) && std::isfinite(t_off) && t_off>t_on;
}

double PulseProfile::step_energy_fraction(double t, double dt) const {
    const double a=std::max(t,t_on), b=std::min(t+dt,t_off);
    return b>a ? full_step_energy_fraction(a,b-a) : 0.0;
}

} // namespace icarus
